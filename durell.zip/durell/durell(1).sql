-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 12 déc. 2025 à 08:37
-- Version du serveur :  5.7.36
-- Version de PHP : 7.0.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `durell`
--

-- --------------------------------------------------------

--
-- Structure de la table `approvisionnement`
--

DROP TABLE IF EXISTS `approvisionnement`;
CREATE TABLE IF NOT EXISTS `approvisionnement` (
  `id_app` int(11) NOT NULL AUTO_INCREMENT,
  `dateApp` date NOT NULL,
  `auteurApp` varchar(30) NOT NULL,
  `id_fournisseur` int(11) NOT NULL,
  `blApp` varchar(50) NOT NULL DEFAULT '0',
  `id_article` int(11) NOT NULL,
  `referenceApp` varchar(255) NOT NULL,
  `prixApp` int(11) NOT NULL,
  `qtiteApp` int(11) NOT NULL,
  PRIMARY KEY (`id_app`),
  KEY `id_article` (`id_article`),
  KEY `id_fournisseur` (`id_fournisseur`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `approvisionnement`
--

INSERT INTO `approvisionnement` (`id_app`, `dateApp`, `auteurApp`, `id_fournisseur`, `blApp`, `id_article`, `referenceApp`, `prixApp`, `qtiteApp`) VALUES
(1, '2025-11-13', 'Durell', 11, 'CMF00001', 8, ' 64Go / Batt 95%', 110000, 5),
(2, '2025-11-13', 'Durell', 11, 'CMF00001', 4, ' 64Go / Batt 90%', 75000, 5),
(3, '2025-11-13', 'Durell', 11, 'CMF00001', 6, ' 64Go / Batt 86%', 85000, 5);

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE IF NOT EXISTS `article` (
  `id_article` int(11) NOT NULL AUTO_INCREMENT,
  `numeroArticle` varchar(10) NOT NULL,
  `id_categorie` int(11) NOT NULL,
  `id_fournisseur` int(11) NOT NULL,
  `dateArticle` date NOT NULL,
  `nomArticle` varchar(255) NOT NULL,
  `montantArticle` int(11) NOT NULL,
  `prixVente` int(11) NOT NULL,
  `referenceArticle` varchar(255) NOT NULL,
  `commentaireArticle` varchar(20) NOT NULL,
  `statusArticle` varchar(20) NOT NULL,
  PRIMARY KEY (`id_article`),
  KEY `id_categorie` (`id_categorie`),
  KEY `id_fournisseur` (`id_fournisseur`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`id_article`, `numeroArticle`, `id_categorie`, `id_fournisseur`, `dateArticle`, `nomArticle`, `montantArticle`, `prixVente`, `referenceArticle`, `commentaireArticle`, `statusArticle`) VALUES
(1, 'ART00001', 1, 11, '2025-11-13', 'IPHONE 6S', 25000, 30000, '32Go / Batt 76%', 'OCCASION', 'OUI'),
(2, 'ART00002', 1, 11, '2025-11-13', 'IPHONE 7', 45000, 55000, '128Go / Batt 90%', 'OCCASION', 'OUI'),
(3, 'ART00003', 1, 11, '2025-11-13', 'IPHONE 8', 55000, 60000, '256Go / Batt 82%', 'NEUF', 'OUI'),
(4, 'ART00004', 1, 11, '2025-11-13', 'IPHONE X', 75000, 85000, '64Go / Batt 90%', 'NEUF', 'OUI'),
(5, 'ART00005', 1, 11, '2025-11-13', 'IPHONE Xr', 90000, 95000, '32Go / Batt 88%', 'OCCASION', 'OUI'),
(6, 'ART00006', 1, 11, '2025-11-13', 'IPHONE Xs', 85000, 95000, '64Go / Batt 86%', 'OCCASION', 'OUI'),
(7, 'ART00007', 1, 11, '2025-11-13', 'IPHONE XsMax', 100000, 110000, '256Go / Batt 91%', 'OCCASION', 'OUI'),
(8, 'ART00008', 1, 11, '2025-11-13', 'IPHONE 11', 110000, 150000, '64Go / Batt 95%', 'OCCASION', 'OUI');

-- --------------------------------------------------------

--
-- Structure de la table `auto_article`
--

DROP TABLE IF EXISTS `auto_article`;
CREATE TABLE IF NOT EXISTS `auto_article` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `id_profile` int(11) NOT NULL,
  `ajout` varchar(10) NOT NULL,
  `voir` varchar(10) NOT NULL,
  `suppression` varchar(20) NOT NULL,
  `modification` varchar(20) NOT NULL,
  PRIMARY KEY (`id_auto`),
  KEY `id_profile` (`id_profile`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `auto_article`
--

INSERT INTO `auto_article` (`id_auto`, `id_profile`, `ajout`, `voir`, `suppression`, `modification`) VALUES
(1, 1, 'true', 'true', 'true', 'true'),
(10, 50, 'true', 'true', 'false', 'true'),
(11, 51, 'true', 'true', 'false', 'true'),
(12, 52, 'true', 'true', 'false', 'false'),
(13, 53, 'true', 'true', 'true', 'true');

-- --------------------------------------------------------

--
-- Structure de la table `auto_client`
--

DROP TABLE IF EXISTS `auto_client`;
CREATE TABLE IF NOT EXISTS `auto_client` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `id_profile` int(11) NOT NULL,
  `ajout` varchar(10) NOT NULL,
  `voir` varchar(10) NOT NULL,
  `suppression` varchar(20) NOT NULL,
  `modification` varchar(20) NOT NULL,
  PRIMARY KEY (`id_auto`),
  KEY `id_profile` (`id_profile`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `auto_client`
--

INSERT INTO `auto_client` (`id_auto`, `id_profile`, `ajout`, `voir`, `suppression`, `modification`) VALUES
(1, 1, 'true', 'true', 'true', 'true'),
(11, 50, 'true', 'true', 'false', 'false'),
(12, 51, 'true', 'true', 'false', 'true'),
(13, 52, 'true', 'true', 'false', 'false'),
(14, 53, 'true', 'true', 'true', 'true');

-- --------------------------------------------------------

--
-- Structure de la table `auto_employe`
--

DROP TABLE IF EXISTS `auto_employe`;
CREATE TABLE IF NOT EXISTS `auto_employe` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `id_profile` int(11) NOT NULL,
  `ajout` varchar(10) NOT NULL,
  `voir` varchar(10) NOT NULL,
  `suppression` varchar(20) NOT NULL,
  `modification` varchar(20) NOT NULL,
  PRIMARY KEY (`id_auto`),
  KEY `id_profile` (`id_profile`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `auto_employe`
--

INSERT INTO `auto_employe` (`id_auto`, `id_profile`, `ajout`, `voir`, `suppression`, `modification`) VALUES
(1, 1, 'true', 'true', 'true', 'true');

-- --------------------------------------------------------

--
-- Structure de la table `auto_fournisseur`
--

DROP TABLE IF EXISTS `auto_fournisseur`;
CREATE TABLE IF NOT EXISTS `auto_fournisseur` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `id_profile` int(11) NOT NULL,
  `ajout` varchar(10) NOT NULL,
  `voir` varchar(10) NOT NULL,
  `suppression` varchar(20) NOT NULL,
  `modification` varchar(20) NOT NULL,
  PRIMARY KEY (`id_auto`),
  KEY `id_profile` (`id_profile`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `auto_fournisseur`
--

INSERT INTO `auto_fournisseur` (`id_auto`, `id_profile`, `ajout`, `voir`, `suppression`, `modification`) VALUES
(1, 1, 'true', 'true', 'true', 'true'),
(12, 50, 'true', 'true', 'false', 'true'),
(13, 52, 'true', 'true', 'false', 'false'),
(14, 53, 'true', 'true', 'true', 'true');

-- --------------------------------------------------------

--
-- Structure de la table `auto_stock`
--

DROP TABLE IF EXISTS `auto_stock`;
CREATE TABLE IF NOT EXISTS `auto_stock` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `id_profile` int(11) NOT NULL,
  `ajout` varchar(10) NOT NULL,
  `voir` varchar(10) NOT NULL,
  `suppression` varchar(20) NOT NULL,
  `modification` varchar(20) NOT NULL,
  PRIMARY KEY (`id_auto`),
  KEY `id_profile` (`id_profile`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `auto_stock`
--

INSERT INTO `auto_stock` (`id_auto`, `id_profile`, `ajout`, `voir`, `suppression`, `modification`) VALUES
(1, 1, 'true', 'true', 'true', 'true'),
(10, 50, 'true', 'true', 'false', 'true'),
(11, 51, 'true', 'true', 'false', 'true'),
(12, 52, 'true', 'true', 'false', 'false'),
(13, 53, 'true', 'true', 'true', 'true');

-- --------------------------------------------------------

--
-- Structure de la table `auto_users`
--

DROP TABLE IF EXISTS `auto_users`;
CREATE TABLE IF NOT EXISTS `auto_users` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `id_profile` int(11) NOT NULL,
  `ajout` varchar(10) NOT NULL,
  `voir` varchar(10) NOT NULL,
  `suppression` varchar(20) NOT NULL,
  `modification` varchar(20) NOT NULL,
  PRIMARY KEY (`id_auto`),
  KEY `id_profile` (`id_profile`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `auto_users`
--

INSERT INTO `auto_users` (`id_auto`, `id_profile`, `ajout`, `voir`, `suppression`, `modification`) VALUES
(1, 1, 'true', 'true', 'true', 'true');

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
CREATE TABLE IF NOT EXISTS `categorie` (
  `id_categorie` int(11) NOT NULL AUTO_INCREMENT,
  `codeCatego` varchar(30) NOT NULL,
  `nomCatego` varchar(30) NOT NULL,
  `commentaireCatego` varchar(100) NOT NULL,
  `dateCatego` date NOT NULL DEFAULT '2025-02-14',
  `actifCatego` varchar(3) NOT NULL,
  PRIMARY KEY (`id_categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id_categorie`, `codeCatego`, `nomCatego`, `commentaireCatego`, `dateCatego`, `actifCatego`) VALUES
(1, 'CAT00001', 'SMART PHONE', 'TELEPHONE', '2025-11-13', 'OUI');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id_client` int(11) NOT NULL AUTO_INCREMENT,
  `codeClient` varchar(30) NOT NULL,
  `dateClient` date NOT NULL DEFAULT '2025-02-14',
  `nomClient` varchar(30) NOT NULL,
  `adresseClient` varchar(30) NOT NULL,
  `telClient` int(20) NOT NULL,
  `soldeClient` int(15) NOT NULL,
  `commentaireClient` varchar(100) NOT NULL,
  `actifClient` varchar(3) NOT NULL,
  PRIMARY KEY (`id_client`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id_client`, `codeClient`, `dateClient`, `nomClient`, `adresseClient`, `telClient`, `soldeClient`, `commentaireClient`, `actifClient`) VALUES
(6, 'CL00002', '2025-09-10', 'DOUMO', 'BEPANDA', 69551248, 500, 'RAS', 'OUI'),
(7, 'CL00003', '2025-09-10', 'MFAMBO', 'BEPANDA', 658744968, 70000, 'RAS', 'OUI'),
(8, 'CL00004', '2025-09-11', 'NANA', 'NYALA', 697845621, 50000, 'RAS', 'OUI'),
(10, 'CL00006', '2025-09-11', 'SANDRA', 'BEEDI', 697955172, 20000, 'RAS', 'OUI'),
(12, 'CL00008', '2025-09-10', 'NANOU', 'SADI', 2147483647, 25000, 'RAS', 'OUI'),
(13, 'CL00009', '2025-09-10', 'JOYCE', 'CITER PALMIER', 677844596, 0, 'RAS', 'OUI'),
(14, 'CL00010', '2025-09-11', 'ANNETTE', 'NSAPE', 66554987, 0, 'RAS', 'OUI'),
(15, 'CL00011', '2025-11-17', 'SHERIFA', 'BEPENDA', 65987412, 0, 'RAS', 'OUI'),
(16, 'CL00012', '2025-12-10', 'RAHP', 'KOTTO', 659481723, 0, 'RAS', 'OUI');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

DROP TABLE IF EXISTS `commande`;
CREATE TABLE IF NOT EXISTS `commande` (
  `id_commande` int(11) NOT NULL AUTO_INCREMENT,
  `codeCom` varchar(20) NOT NULL,
  `id_fournisseur` int(9) NOT NULL,
  `dateCrea` date NOT NULL,
  `dateCom` date NOT NULL,
  `id_article` int(9) NOT NULL,
  `referenceCom` varchar(255) NOT NULL,
  `montantCom` int(11) NOT NULL,
  `qtiteCom` int(9) NOT NULL,
  `typeCom` varchar(3) NOT NULL,
  `valideCom` varchar(3) NOT NULL DEFAULT 'oui',
  `codeFour` varchar(255) NOT NULL,
  `adresseFour` varchar(255) NOT NULL,
  `telFour` int(20) NOT NULL,
  PRIMARY KEY (`id_commande`),
  KEY `id_fournisseur` (`id_fournisseur`),
  KEY `id_article` (`id_article`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`id_commande`, `codeCom`, `id_fournisseur`, `dateCrea`, `dateCom`, `id_article`, `referenceCom`, `montantCom`, `qtiteCom`, `typeCom`, `valideCom`, `codeFour`, `adresseFour`, `telFour`) VALUES
(10, 'CMF00002', 16, '2025-11-19', '2025-11-19', 8, ' 64Go / Batt 95%  ', 110000, 1, 'oui', 'oui', ' FOUR00005', ' BEPANDA', 694827551),
(11, 'CMF00002', 16, '2025-11-19', '2025-11-19', 2, ' 128Go / Batt 90%  ', 45000, 2, 'oui', 'oui', ' FOUR00005', ' BEPANDA', 694827551),
(12, 'CMF00002', 16, '2025-11-19', '2025-11-19', 3, ' 256Go / Batt 82%  ', 55000, 5, 'oui', 'oui', ' FOUR00005', ' BEPANDA', 694827551),
(13, 'CMF00002', 16, '2025-11-19', '2025-11-19', 7, ' 256Go / Batt 91%  ', 100000, 1, 'oui', 'oui', ' FOUR00005', ' BEPANDA', 694827551),
(14, 'CMF00002', 16, '2025-11-19', '2025-11-19', 4, ' 64Go / Batt 90%  ', 75000, 8, 'oui', 'oui', ' FOUR00005', ' BEPANDA', 694827551);

-- --------------------------------------------------------

--
-- Structure de la table `commande_client`
--

DROP TABLE IF EXISTS `commande_client`;
CREATE TABLE IF NOT EXISTS `commande_client` (
  `id_commandeClient` int(11) NOT NULL AUTO_INCREMENT,
  `codeCom` varchar(20) NOT NULL,
  `id_client` int(9) NOT NULL,
  `dateCrea` date NOT NULL,
  `dateCom` date NOT NULL,
  `id_article` int(9) NOT NULL,
  `referenceCom` varchar(255) NOT NULL,
  `prixVenteCom` int(11) NOT NULL,
  `qtiteCom` int(9) NOT NULL,
  `typeCom` varchar(3) NOT NULL,
  `valideCom` varchar(3) NOT NULL DEFAULT 'oui',
  `codeClient` varchar(255) NOT NULL,
  `adresseClient` varchar(255) NOT NULL,
  `telClient` int(20) NOT NULL,
  PRIMARY KEY (`id_commandeClient`),
  KEY `id_client` (`id_client`),
  KEY `id_article` (`id_article`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `commande_client`
--

INSERT INTO `commande_client` (`id_commandeClient`, `codeCom`, `id_client`, `dateCrea`, `dateCom`, `id_article`, `referenceCom`, `prixVenteCom`, `qtiteCom`, `typeCom`, `valideCom`, `codeClient`, `adresseClient`, `telClient`) VALUES
(4, 'CMC00001', 7, '2025-11-19', '2025-11-19', 8, ' 64Go / Batt 95%  ', 150000, 1, 'oui', 'oui', ' CL00003', ' BEPANDA', 658744968),
(5, 'CMC00002', 7, '2025-11-19', '2025-11-19', 8, ' 64Go / Batt 95%   ', 150000, 2, 'oui', 'non', ' CL00003', ' BEPANDA', 658744968),
(6, 'CMC00002', 7, '2025-11-19', '2025-11-19', 3, ' 256Go / Batt 82%   ', 60000, 2, 'oui', 'non', ' CL00003', ' BEPANDA', 658744968),
(7, 'CMC00002', 7, '2025-11-19', '2025-11-19', 1, ' 32Go / Batt 76%   ', 30000, 1, 'oui', 'non', ' CL00003', ' BEPANDA', 658744968),
(8, 'CMC00003', 6, '2025-11-21', '2025-11-21', 7, ' 256Go / Batt 91% ', 110000, 1, 'oui', 'oui', ' CL00002', ' BEPANDA', 69551248),
(9, 'CMC00004', 10, '2025-11-24', '2025-11-24', 1, ' 32Go / Batt 76% ', 30000, 1, 'oui', 'oui', ' CL00006', ' BEEDI', 697955172),
(10, 'CMC00004', 10, '2025-11-24', '2025-11-24', 2, ' 128Go / Batt 90% ', 55000, 2, 'oui', 'oui', ' CL00006', ' BEEDI', 697955172),
(11, 'CMC00005', 6, '2025-11-24', '2025-11-24', 7, ' 256Go / Batt 91% ', 110000, 3, 'oui', 'oui', ' CL00002', ' BEPANDA', 69551248),
(12, 'CMC00006', 16, '2025-12-10', '2025-12-10', 4, ' 64Go / Batt 90%', 85000, 2, 'oui', 'oui', ' CL00012', ' KOTTO', 659481723);

-- --------------------------------------------------------

--
-- Structure de la table `defectueux`
--

DROP TABLE IF EXISTS `defectueux`;
CREATE TABLE IF NOT EXISTS `defectueux` (
  `id_defectueux` int(11) NOT NULL AUTO_INCREMENT,
  `dateDef` date NOT NULL,
  `auteurDef` varchar(30) NOT NULL,
  `id_fournisseur` int(11) NOT NULL,
  `id_article` int(11) NOT NULL,
  `referenceDef` varchar(255) NOT NULL,
  `montantDef` int(11) NOT NULL,
  `qtiteDef` int(11) NOT NULL,
  PRIMARY KEY (`id_defectueux`),
  KEY `id_article` (`id_article`),
  KEY `id_fournisseur` (`id_fournisseur`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `defectueux`
--

INSERT INTO `defectueux` (`id_defectueux`, `dateDef`, `auteurDef`, `id_fournisseur`, `id_article`, `referenceDef`, `montantDef`, `qtiteDef`) VALUES
(1, '2025-11-21', 'Durell', 13, 8, ' 64Go / Batt 95%', 110000, 1);

-- --------------------------------------------------------

--
-- Structure de la table `employe`
--

DROP TABLE IF EXISTS `employe`;
CREATE TABLE IF NOT EXISTS `employe` (
  `id_employe` int(11) NOT NULL AUTO_INCREMENT,
  `codeEmploye` varchar(255) NOT NULL,
  `nomEmploye` varchar(255) NOT NULL,
  `prenomEmploye` varchar(255) NOT NULL,
  `dateNaiss` date NOT NULL,
  `telEmploye` int(11) NOT NULL,
  `cniEmploye` varchar(255) NOT NULL,
  `adresseEmploye` varchar(255) NOT NULL,
  `dateEmbauche` date NOT NULL,
  `id_fonction` int(11) NOT NULL,
  `salaire` int(11) NOT NULL,
  `actifEmploye` varchar(3) NOT NULL,
  PRIMARY KEY (`id_employe`),
  KEY `id_fonction` (`id_fonction`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `employe`
--

INSERT INTO `employe` (`id_employe`, `codeEmploye`, `nomEmploye`, `prenomEmploye`, `dateNaiss`, `telEmploye`, `cniEmploye`, `adresseEmploye`, `dateEmbauche`, `id_fonction`, `salaire`, `actifEmploye`) VALUES
(1, 'EMP00001', 'MFAMBO', 'VANEL', '2002-01-02', 658560456, 'KIT181', 'BEPANDA', '2025-11-01', 5, 300000, 'OUI'),
(4, 'EMP00004', 'YANKOUA', 'MARIE', '2021-10-05', 696507827, 'KIT18', 'ANGE RAPHAEL', '2010-11-08', 4, 500000, 'OUI'),
(5, 'EMP00005', 'BALEN', 'SANDRA', '2006-03-06', 697955172, 'KIT11023', 'BEETI', '2025-12-08', 4, 200000, 'NON');

-- --------------------------------------------------------

--
-- Structure de la table `facture_article`
--

DROP TABLE IF EXISTS `facture_article`;
CREATE TABLE IF NOT EXISTS `facture_article` (
  `id_factureArt` int(11) NOT NULL AUTO_INCREMENT,
  `id_fournisseur` int(11) NOT NULL,
  `dateFact` date NOT NULL DEFAULT '2025-01-01',
  `numeroFact` varchar(30) NOT NULL,
  `montantFact` int(11) NOT NULL,
  `payeFact` varchar(3) NOT NULL,
  `commentaireFact` varchar(100) NOT NULL,
  PRIMARY KEY (`id_factureArt`),
  KEY `id_fournisseur` (`id_fournisseur`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `facture_article`
--

INSERT INTO `facture_article` (`id_factureArt`, `id_fournisseur`, `dateFact`, `numeroFact`, `montantFact`, `payeFact`, `commentaireFact`) VALUES
(5, 15, '2025-09-09', 'A00001', 25000, 'OUI', 'RAS'),
(6, 13, '2025-09-09', 'A00002', 3500, 'OUI', 'RAS'),
(7, 13, '2025-11-14', 'Q555', 12000, 'OUI', 'RAS'),
(8, 19, '2025-11-14', 'RA444', 120555, 'OUI', 'RAS'),
(9, 13, '2025-11-14', 'P120000', 100000, 'OUI', 'RAS'),
(10, 19, '2025-11-14', 'P01', 100, 'OUI', 'RAS');

-- --------------------------------------------------------

--
-- Structure de la table `facture_client`
--

DROP TABLE IF EXISTS `facture_client`;
CREATE TABLE IF NOT EXISTS `facture_client` (
  `id_facture` int(11) NOT NULL AUTO_INCREMENT,
  `codeFact` varchar(20) NOT NULL,
  `id_client` int(9) NOT NULL,
  `dateFact` date NOT NULL,
  `id_article` int(9) NOT NULL,
  `referenceCom` varchar(255) NOT NULL,
  `prixVenteCom` int(11) NOT NULL,
  `qtiteCom` int(9) NOT NULL,
  `typeCom` varchar(3) NOT NULL,
  `valideFact` varchar(3) NOT NULL DEFAULT 'oui',
  `codeClient` varchar(255) NOT NULL,
  `adresseClient` varchar(255) NOT NULL,
  `telClient` int(20) NOT NULL,
  PRIMARY KEY (`id_facture`),
  KEY `id_client` (`id_client`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `facture_client`
--

INSERT INTO `facture_client` (`id_facture`, `codeFact`, `id_client`, `dateFact`, `id_article`, `referenceCom`, `prixVenteCom`, `qtiteCom`, `typeCom`, `valideFact`, `codeClient`, `adresseClient`, `telClient`) VALUES
(20, 'FAC0005', 6, '2025-11-19', 7, ' 256Go / Batt 91%', 110000, 1, 'oui', 'oui', ' CL00002', ' BEPANDA', 69551248),
(19, 'FAC0005', 6, '2025-11-19', 1, ' 32Go / Batt 76%', 30000, 1, 'oui', 'oui', ' CL00002', ' BEPANDA', 69551248),
(14, 'FAC0001', 14, '2025-11-19', 1, ' 32Go / Batt 76%', 30000, 1, 'oui', 'non', ' CL00010', ' NSAPE', 66554987),
(15, 'FAC0002', 10, '2025-11-19', 1, ' 32Go / Batt 76% ', 30000, 1, 'oui', 'non', ' CL00006', ' BEEDI', 697955172),
(16, 'FAC0002', 10, '2025-11-19', 2, ' 128Go / Batt 90% ', 55000, 1, 'oui', 'non', ' CL00006', ' BEEDI', 697955172),
(17, 'FAC0003', 10, '2025-11-19', 4, ' 64Go / Batt 90%', 85000, 1, 'oui', 'oui', ' CL00006', ' BEEDI', 697955172),
(18, 'FAC0004', 10, '2025-11-19', 6, ' 64Go / Batt 86%', 95000, 5, 'oui', 'oui', ' CL00006', ' BEEDI', 697955172),
(21, 'FAC0006', 16, '2025-12-10', 4, ' 64Go / Batt 90%', 85000, 2, 'oui', 'oui', ' CL00012', ' KOTTO', 659481723);

-- --------------------------------------------------------

--
-- Structure de la table `fonction`
--

DROP TABLE IF EXISTS `fonction`;
CREATE TABLE IF NOT EXISTS `fonction` (
  `id_fonction` int(11) NOT NULL AUTO_INCREMENT,
  `codeFonc` varchar(30) NOT NULL,
  `fonction` varchar(30) NOT NULL,
  `commentaireFonc` varchar(100) NOT NULL,
  `dateFonc` date NOT NULL DEFAULT '2025-02-14',
  `actifFonc` varchar(3) NOT NULL,
  PRIMARY KEY (`id_fonction`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `fonction`
--

INSERT INTO `fonction` (`id_fonction`, `codeFonc`, `fonction`, `commentaireFonc`, `dateFonc`, `actifFonc`) VALUES
(4, 'FO002', 'SECRETAIRE', 'RAS', '2025-12-02', 'OUI'),
(5, 'FO003', 'INFORMATIQUE', 'ras', '2025-12-02', 'OUI'),
(7, 'FON004', 'RH', 'RAS', '2025-12-11', 'OUI');

-- --------------------------------------------------------

--
-- Structure de la table `fournisseur`
--

DROP TABLE IF EXISTS `fournisseur`;
CREATE TABLE IF NOT EXISTS `fournisseur` (
  `id_fournisseur` int(11) NOT NULL AUTO_INCREMENT,
  `codeFour` varchar(30) NOT NULL,
  `dateFour` date NOT NULL DEFAULT '2025-02-14',
  `nomFour` varchar(30) NOT NULL,
  `adresseFour` varchar(30) NOT NULL,
  `telFour` int(20) NOT NULL,
  `soldeFour` int(11) NOT NULL,
  `commentaireFour` varchar(100) NOT NULL,
  `actifFour` varchar(3) NOT NULL,
  PRIMARY KEY (`id_fournisseur`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `fournisseur`
--

INSERT INTO `fournisseur` (`id_fournisseur`, `codeFour`, `dateFour`, `nomFour`, `adresseFour`, `telFour`, `soldeFour`, `commentaireFour`, `actifFour`) VALUES
(11, 'FOUR00001', '2025-09-01', 'DURELL', 'BEPANDA', 658560456, 20000, 'RAS', 'OUI'),
(13, 'FOUR00002', '2025-09-02', 'BAKA', 'BEPANDA', 699887744, 15000, 'RAS', 'OUI'),
(14, 'FOUR00003', '2025-09-02', 'BRIAN', 'MAROUA', 691884557, 20000, 'RAS', 'OUI'),
(15, 'FOUR00004', '2025-09-02', 'DYLAN', 'BEPANDA', 658055109, 50000, 'RAS', 'OUI'),
(16, 'FOUR00005', '2025-09-02', 'BOSTON', 'BEPANDA', 694827551, 80000, 'RAS', 'OUI'),
(17, 'FOUR00006', '2025-09-04', 'NANA', 'HAOUSSA', 654127889, 100000, 'RAS', 'OUI'),
(18, 'FOUR00007', '2025-09-13', 'XAVIER', 'NYALLA', 699884455, 60000, 'RASS', 'OUI'),
(19, 'FOUR00008', '2025-10-16', 'JORDAN', 'NYALLA', 658741233, 100000, 'RAS', 'OUI'),
(20, 'FOUR00009', '2025-10-27', 'FRANCK', 'BEPANDA', 699554478, 200000, 'RAS', 'OUI');

-- --------------------------------------------------------

--
-- Structure de la table `inventaire`
--

DROP TABLE IF EXISTS `inventaire`;
CREATE TABLE IF NOT EXISTS `inventaire` (
  `id_inventaire` int(11) NOT NULL AUTO_INCREMENT,
  `dateInv` date NOT NULL,
  `auteurInv` varchar(30) NOT NULL,
  `id_fournisseur` int(11) NOT NULL,
  `id_article` int(9) NOT NULL,
  `referenceInv` varchar(255) NOT NULL,
  `prixInv` int(11) NOT NULL,
  `qtiteInv` int(11) NOT NULL,
  PRIMARY KEY (`id_inventaire`),
  KEY `id_fournisseur` (`id_fournisseur`),
  KEY `id_article` (`id_article`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `inventaire`
--

INSERT INTO `inventaire` (`id_inventaire`, `dateInv`, `auteurInv`, `id_fournisseur`, `id_article`, `referenceInv`, `prixInv`, `qtiteInv`) VALUES
(3, '2025-01-01', 'Durell', 11, 8, ' 64Go / Batt 95%', 110000, 10),
(4, '2025-01-01', 'Durell', 11, 1, ' 32Go / Batt 76% - 86%', 25000, 10),
(5, '2025-01-01', 'Durell', 11, 2, ' 128Go / Batt 90%', 45000, 10),
(6, '2025-01-01', 'Durell', 11, 3, ' 256Go / Batt 82%', 55000, 10),
(7, '2025-01-01', 'Durell', 11, 4, ' 64Go / Batt 90%', 75000, 10),
(8, '2025-01-01', 'Durell', 11, 5, ' 32Go / Batt 88%', 90000, 10),
(9, '2025-01-01', 'Durell', 11, 6, ' 64Go / Batt 86%', 85000, 10),
(10, '2025-01-01', 'Durell', 11, 7, ' 256Go / Batt 91%', 100000, 10);

-- --------------------------------------------------------

--
-- Structure de la table `notification`
--

DROP TABLE IF EXISTS `notification`;
CREATE TABLE IF NOT EXISTS `notification` (
  `ref` int(11) NOT NULL AUTO_INCREMENT,
  `poste` varchar(150) CHARACTER SET latin1 NOT NULL,
  `id_profil` int(11) NOT NULL,
  `nom_table` varchar(50) CHARACTER SET latin1 NOT NULL,
  `message` varchar(500) CHARACTER SET latin1 NOT NULL,
  `date_notif` date NOT NULL,
  `heure_notif` time(6) NOT NULL,
  PRIMARY KEY (`ref`)
) ENGINE=InnoDB AUTO_INCREMENT=262 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `notification`
--

INSERT INTO `notification` (`ref`, `poste`, `id_profil`, `nom_table`, `message`, `date_notif`, `heure_notif`) VALUES
(1, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>13-11-2025  </strong>', '2025-11-13', '11:49:18.000000'),
(2, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>13-11-2025  </strong>', '2025-11-13', '11:49:43.000000'),
(3, 'DURELL-MT', 1, 'categorie', '<strong class=\'text-dark\'>durell</strong> a ajouté le categorie <strong class=\'text-info\'> \'SMART PHONE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'TELEPHONE\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-13', '11:50:47.000000'),
(4, 'DURELL-MT', 1, 'article', '<strong class=\'text-dark\'>durell</strong> a ajouté un article <strong class=\'text-info\'> \'IPHONE 6S\' </strong> de montant :  <strong class=\'text-danger\'> \'25000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00001\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-13', '11:54:22.000000'),
(5, 'DURELL-MT', 1, 'article', '<strong class=\'text-dark\'>durell</strong> a ajouté un article <strong class=\'text-info\'> \'IPHONE 7\' </strong> de montant :  <strong class=\'text-danger\'> \'45000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00002\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-13', '11:55:20.000000'),
(6, 'DURELL-MT', 1, 'article', '<strong class=\'text-dark\'>durell</strong> a ajouté un article <strong class=\'text-info\'> \'IPHONE 8\' </strong> de montant :  <strong class=\'text-danger\'> \'55000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00003\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-13', '11:56:17.000000'),
(7, 'DURELL-MT', 1, 'article', '<strong class=\'text-dark\'>durell</strong> a ajouté un article <strong class=\'text-info\'> \'IPHONE X\' </strong> de montant :  <strong class=\'text-danger\'> \'75000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00004\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-13', '11:57:03.000000'),
(8, 'DURELL-MT', 1, 'article', '<strong class=\'text-dark\'>durell</strong> a ajouté un article <strong class=\'text-info\'> \'IPHONE Xr\' </strong> de montant :  <strong class=\'text-danger\'> \'90000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00005\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-13', '11:58:04.000000'),
(9, 'DURELL-MT', 1, 'article', '<strong class=\'text-dark\'>durell</strong> a ajouté un article <strong class=\'text-info\'> \'IPHONE Xs\' </strong> de montant :  <strong class=\'text-danger\'> \'85000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00006\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-13', '11:59:32.000000'),
(10, 'DURELL-MT', 1, 'article', '<strong class=\'text-dark\'>durell</strong> a ajouté un article <strong class=\'text-info\'> \'IPHONE XsMax\' </strong> de montant :  <strong class=\'text-danger\'> \'100000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00007\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-13', '12:00:27.000000'),
(11, 'DURELL-MT', 1, 'article', '<strong class=\'text-dark\'>durell</strong> a ajouté un article <strong class=\'text-info\'> \'IPHONE 11\' </strong> de montant :  <strong class=\'text-danger\'> \'110000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00008\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-13', '12:02:15.000000'),
(12, 'DURELL-MT', 1, 'article', ' <strong class=\'text-dark\'>durell</strong> a modifié un article <strong class=\'text-info\'> \'IPHONE 6S\' </strong> de montant :  <strong class=\'text-danger\'> \'25000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00009\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-13', '12:03:24.000000'),
(13, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMF00001 \'</strong> de fournisseur <strong class=\'text-info\'>\' DURELL \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-13', '12:07:18.000000'),
(14, 'DURELL-MT', 1, 'inventaire', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un inventaire sur l\'article  <strong class=\'text-primary\'>\' IPHONE 11 \'</strong>  de prix <strong class=\'text-danger\'>\'  110000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 10 \'  </strong>', '2025-11-13', '12:08:53.000000'),
(15, 'DURELL-MT', 1, 'inventaire', ' <strong class=\'text-dark\'>durell  </strong> a supprimé l\' Article <strong class=\'text-primary\'> \' IPHONE 11 \' </strong> dans l\'inventaire de prix <strong class=\'text-danger\'> \' 110000 \' </strong> et quantité <strong class=\'text-success\'> \'10\'  </strong>', '2025-11-13', '12:09:09.000000'),
(16, 'DURELL-MT', 1, 'inventaire', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un inventaire sur l\'article  <strong class=\'text-primary\'>\' IPHONE 11 \'</strong>  de prix <strong class=\'text-danger\'>\'  110000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 10 \'  </strong>', '2025-11-13', '12:09:41.000000'),
(17, 'DURELL-MT', 1, 'inventaire', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un inventaire sur l\'article  <strong class=\'text-primary\'>\' IPHONE 11 \'</strong>  de prix <strong class=\'text-danger\'>\'  110000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 10 \'  </strong>', '2025-11-13', '12:09:47.000000'),
(18, 'DURELL-MT', 1, 'inventaire', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un inventaire sur l\'article  <strong class=\'text-primary\'>\' IPHONE 6S \'</strong>  de prix <strong class=\'text-danger\'>\'  25000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 10 \'  </strong>', '2025-11-13', '12:09:52.000000'),
(19, 'DURELL-MT', 1, 'inventaire', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un inventaire sur l\'article  <strong class=\'text-primary\'>\' IPHONE 7 \'</strong>  de prix <strong class=\'text-danger\'>\'  45000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 10 \'  </strong>', '2025-11-13', '12:09:58.000000'),
(20, 'DURELL-MT', 1, 'inventaire', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un inventaire sur l\'article  <strong class=\'text-primary\'>\' IPHONE 8 \'</strong>  de prix <strong class=\'text-danger\'>\'  55000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 10 \'  </strong>', '2025-11-13', '12:10:04.000000'),
(21, 'DURELL-MT', 1, 'inventaire', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un inventaire sur l\'article  <strong class=\'text-primary\'>\' IPHONE X \'</strong>  de prix <strong class=\'text-danger\'>\'  75000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 10 \'  </strong>', '2025-11-13', '12:10:10.000000'),
(22, 'DURELL-MT', 1, 'inventaire', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un inventaire sur l\'article  <strong class=\'text-primary\'>\' IPHONE Xr \'</strong>  de prix <strong class=\'text-danger\'>\'  90000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 10 \'  </strong>', '2025-11-13', '12:10:17.000000'),
(23, 'DURELL-MT', 1, 'inventaire', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un inventaire sur l\'article  <strong class=\'text-primary\'>\' IPHONE Xs \'</strong>  de prix <strong class=\'text-danger\'>\'  85000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 10 \'  </strong>', '2025-11-13', '12:10:26.000000'),
(24, 'DURELL-MT', 1, 'inventaire', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un inventaire sur l\'article  <strong class=\'text-primary\'>\' IPHONE XsMax \'</strong>  de prix <strong class=\'text-danger\'>\'  100000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 10 \'  </strong>', '2025-11-13', '12:10:57.000000'),
(25, 'DURELL-MT', 1, 'approvisionnemnent', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un approvisionnement sur l\'article  <strong class=\'text-primary\'>\' IPHONE 11 \'</strong>  de prix <strong class=\'text-danger\'>\'  110000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 5 \'  </strong>', '2025-11-13', '12:12:13.000000'),
(26, 'DURELL-MT', 1, 'approvisionnemnent', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un approvisionnement sur l\'article  <strong class=\'text-primary\'>\' IPHONE X \'</strong>  de prix <strong class=\'text-danger\'>\'  75000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 5 \'  </strong>', '2025-11-13', '12:12:30.000000'),
(27, 'DURELL-MT', 1, 'approvisionnemnent', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un approvisionnement sur l\'article  <strong class=\'text-primary\'>\' IPHONE Xs \'</strong>  de prix <strong class=\'text-danger\'>\'  85000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 5 \'  </strong>', '2025-11-13', '12:12:43.000000'),
(28, 'DURELL-MT', 1, 'sortie', '<strong class=\'text-dark\'>durell</strong> a ajouté une sortie de N°Facture <strong class=\'text-info\'> \'011\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 11 \' </strong>de montant :  <strong class=\'text-danger\'> \'110000\' </strong>  de qtie : <strong class=\'text-dark\'> \'10\' </strong>', '2025-11-13', '12:21:03.000000'),
(29, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la sortie l\'Article  <strong class=\'text-primary\'> \' IPHONE 11 \' </strong>  de prix <strong class=\'text-danger\'> \' 110000 \' </strong> et quantité <strong class=\'text-success\'> \'10\'  </strong>', '2025-11-13', '12:21:24.000000'),
(30, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0001 \'</strong> du client <strong class=\'text-info\'>\' DOUMO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-13', '12:31:02.000000'),
(31, 'DURELL-MT', 1, 'sortie', '<strong class=\'text-dark\'>durell</strong> a ajouté une sortie de N°Facture <strong class=\'text-info\'> \' FAC0001\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 11 \' </strong>de montant :  <strong class=\'text-danger\'> \'110000\' </strong>  de qtie : <strong class=\'text-dark\'> \'1\' </strong>', '2025-11-13', '12:32:06.000000'),
(32, 'DURELL-MT', 1, 'sortie', '<strong class=\'text-dark\'>durell</strong> a ajouté une sortie de N°Facture <strong class=\'text-info\'> \' FAC0001\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE X \' </strong>de montant :  <strong class=\'text-danger\'> \'75000\' </strong>  de qtie : <strong class=\'text-dark\'> \'1\' </strong>', '2025-11-13', '12:32:15.000000'),
(33, 'DURELL-MT', 1, 'facture_article', ' <strong class=\'text-dark\'>durell</strong> a modifié la facture <strong class=\'text-info\'> \'A00002\' </strong> de fournisseur :  <strong class=\'text-primary\'> \'BAKA\' </strong> de montant :  <strong class=\'text-danger\'> \'3500\' </strong>payé :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-13', '15:29:36.000000'),
(34, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>14-11-2025  </strong>', '2025-11-14', '10:12:04.000000'),
(35, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell</strong> a modifié une sortie de N°Facture <strong class=\'text-info\'> \' FAC0001\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE X \' </strong>de montant :  <strong class=\'text-danger\'> \'75000\' </strong>  de qtie : <strong class=\'text-dark\'> \'8\' </strong>', '2025-11-14', '11:03:27.000000'),
(36, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la facture de N° <strong class=\'text-primary\'>\' FAC0002 \'</strong>  du client <strong class=\'text-info\'>\' DOUMO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-14', '11:23:34.000000'),
(37, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la facture de N° <strong class=\'text-primary\'>\' FAC0002 \'</strong>  du client <strong class=\'text-info\'>\' DOUMO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-14', '11:23:43.000000'),
(38, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0002 \'</strong> du client <strong class=\'text-info\'>\' MFAMBO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-14', '13:44:32.000000'),
(39, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0003 \'</strong> du client <strong class=\'text-info\'>\' MFAMBO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-14', '13:46:37.000000'),
(40, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0004 \'</strong> du client <strong class=\'text-info\'>\' MFAMBO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-14', '14:04:58.000000'),
(41, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0005 \'</strong> du client <strong class=\'text-info\'>\' NANA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-14', '14:05:17.000000'),
(42, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0006 \'</strong> du client <strong class=\'text-info\'>\' NANA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-14', '14:11:16.000000'),
(43, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0007 \'</strong> du client <strong class=\'text-info\'>\' NANA \'</strong>  Valide :: <strong class=\'text-info\'>\' non \'</strong>  ', '2025-11-14', '14:24:40.000000'),
(44, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0008 \'</strong> du client <strong class=\'text-info\'>\' NANA \'</strong>  Valide :: <strong class=\'text-info\'>\' non \'</strong>  ', '2025-11-14', '14:24:55.000000'),
(45, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0009 \'</strong> du client <strong class=\'text-info\'>\' NANA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-14', '14:25:11.000000'),
(46, 'DURELL-MT', 1, 'facture_article', '<strong class=\'text-dark\'>durell</strong> a ajouté la facture <strong class=\'text-info\'> \'Q555\' </strong> de fournisseur :  <strong class=\'text-primary\'> \'BAKA\' </strong> de montant :  <strong class=\'text-danger\'> \'12000\' </strong> payé :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-14', '15:09:04.000000'),
(47, 'DURELL-MT', 1, 'facture_article', '<strong class=\'text-dark\'>durell</strong> a ajouté la facture <strong class=\'text-info\'> \'RA444\' </strong> de fournisseur :  <strong class=\'text-primary\'> \'JORDAN\' </strong> de montant :  <strong class=\'text-danger\'> \'120555\' </strong> payé :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-14', '15:09:27.000000'),
(48, 'DURELL-MT', 1, 'facture_article', '<strong class=\'text-dark\'>durell</strong> a ajouté la facture <strong class=\'text-info\'> \'P120000\' </strong> de fournisseur :  <strong class=\'text-primary\'> \'BAKA\' </strong> de montant :  <strong class=\'text-danger\'> \'100000\' </strong> payé :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-14', '15:09:55.000000'),
(49, 'DURELL-MT', 1, 'facture_article', '<strong class=\'text-dark\'>durell</strong> a ajouté la facture <strong class=\'text-info\'> \'P01\' </strong> de fournisseur :  <strong class=\'text-primary\'> \'JORDAN\' </strong> de montant :  <strong class=\'text-danger\'> \'500000\' </strong> payé :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-14', '15:10:17.000000'),
(50, 'DURELL-MT', 1, 'facture_article', ' <strong class=\'text-dark\'>durell</strong> a modifié la facture <strong class=\'text-info\'> \'P01\' </strong> de fournisseur :  <strong class=\'text-primary\'> \'JORDAN\' </strong> de montant :  <strong class=\'text-danger\'> \'500000\' </strong>payé :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-14', '15:30:24.000000'),
(51, 'DURELL-MT', 1, 'facture_article', ' <strong class=\'text-dark\'>durell</strong> a modifié la facture <strong class=\'text-info\'> \'P01\' </strong> de fournisseur :  <strong class=\'text-primary\'> \'JORDAN\' </strong> de montant :  <strong class=\'text-danger\'> \'100\' </strong>payé :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-14', '15:30:31.000000'),
(52, 'DURELL-MT', 1, 'article', ' <strong class=\'text-dark\'>durell</strong> a modifié un article <strong class=\'text-info\'> \'IPHONE 6S\' </strong> de montant :  <strong class=\'text-danger\'> \'25000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00009\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-14', '16:04:25.000000'),
(53, 'DURELL-MT', 1, 'facture_article', ' <strong class=\'text-dark\'>durell</strong> a modifié la facture <strong class=\'text-info\'> \'P01\' </strong> de fournisseur :  <strong class=\'text-primary\'> \'JORDAN\' </strong> de montant :  <strong class=\'text-danger\'> \'100\' </strong>payé :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-14', '16:16:21.000000'),
(54, 'DURELL-MT', 1, 'client', ' <strong class=\'text-dark\'>durell</strong> a modifié le Client  <strong class=\'text-info\'> \'YANKOUA\' </strong> de solde :  <strong class=\'text-danger\'> \'500000\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-14', '16:29:13.000000'),
(55, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>17-11-2025  </strong>', '2025-11-17', '08:22:05.000000'),
(56, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>17-11-2025  </strong>', '2025-11-17', '10:49:09.000000'),
(57, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell</strong> a modifié une sortie de N°Facture <strong class=\'text-info\'> \' FAC0001\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE X \' </strong>de montant :  <strong class=\'text-danger\'> \'75000\' </strong>  de qtie : <strong class=\'text-dark\'> \'8\' </strong>', '2025-11-17', '11:02:37.000000'),
(58, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell</strong> a modifié une sortie de N°Facture <strong class=\'text-info\'> \' FAC0001\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE X \' </strong>de montant :  <strong class=\'text-danger\'> \'75000\' </strong>  de qtie : <strong class=\'text-dark\'> \'8\' </strong>', '2025-11-17', '11:03:00.000000'),
(59, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>17-11-2025  </strong>', '2025-11-17', '11:41:42.000000'),
(60, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell</strong> a modifié une sortie de N°Facture <strong class=\'text-info\'> \' FAC0001\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE X \' </strong>de montant :  <strong class=\'text-danger\'> \'75000\' </strong>  de qtie : <strong class=\'text-dark\'> \'8\' </strong>', '2025-11-17', '12:02:41.000000'),
(61, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell</strong> a modifié une sortie de N°Facture <strong class=\'text-info\'> \' FAC0001\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE X \' </strong>de montant :  <strong class=\'text-danger\'> \'75000\' </strong>  de qtie : <strong class=\'text-dark\'> \'8\' </strong>', '2025-11-17', '12:02:55.000000'),
(62, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>17-11-2025  </strong>', '2025-11-17', '12:20:11.000000'),
(63, 'DURELL-MT', 1, 'article', ' <strong class=\'text-dark\'>durell</strong> a modifié un article <strong class=\'text-info\'> \'IPHONE 11\' </strong> de montant :  <strong class=\'text-danger\'> \'110000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00009\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-17', '16:07:46.000000'),
(64, 'DURELL-MT', 1, 'article', ' <strong class=\'text-dark\'>durell</strong> a modifié un article <strong class=\'text-info\'> \'IPHONE 6S\' </strong> de montant :  <strong class=\'text-danger\'> \'25000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00009\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-17', '16:33:49.000000'),
(65, 'DURELL', 1, 'client', '<strong class=\'text-dark\'>durell</strong> a ajouté le Client <strong class=\'text-info\'> \'SHERIFA\' </strong> de solde :  <strong class=\'text-danger\'> \'0\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-17', '20:25:10.000000'),
(66, 'DURELL', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMC00001 \'</strong> du client <strong class=\'text-info\'>\' SHERIFA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-17', '20:26:05.000000'),
(67, 'DURELL', 1, 'sortie', '<strong class=\'text-dark\'>durell</strong> a ajouté une sortie de N°Facture <strong class=\'text-info\'> \'Q22\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 11 \' </strong>de montant :  <strong class=\'text-danger\'> \'150000\' </strong>  de qtie : <strong class=\'text-dark\'> \'1\' </strong>', '2025-11-17', '20:38:07.000000'),
(68, 'DURELL', 1, 'sortie', ' <strong class=\'text-dark\'>durell</strong> a modifié une sortie de N°Facture <strong class=\'text-info\'> \'Q22\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 11 \' </strong>de montant :  <strong class=\'text-danger\'> \'150000\' </strong>  de qtie : <strong class=\'text-dark\'> \'1\' </strong>', '2025-11-17', '20:39:27.000000'),
(69, 'DURELL', 1, 'sortie', ' <strong class=\'text-dark\'>durell</strong> a modifié une sortie de N°Facture <strong class=\'text-info\'> \'Q22\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 11 \' </strong>de montant :  <strong class=\'text-danger\'> \'150000\' </strong>  de qtie : <strong class=\'text-dark\'> \'1\' </strong>', '2025-11-17', '20:41:09.000000'),
(70, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>17-11-2025  </strong>', '2025-11-17', '20:46:59.000000'),
(71, 'DURELL', 1, 'profil', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un  utilisateur <strong class=\'text-primary\'> \'SHERIFA\' </strong>', '2025-11-17', '20:48:51.000000'),
(72, 'DURELL', 53, 'profil', '<strong class=\'text-dark\'>SHERIFA  </strong>  </strong> s\'est connecté le <strong>17-11-2025  </strong>', '2025-11-17', '20:49:22.000000'),
(73, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>17-11-2025  </strong>', '2025-11-17', '20:50:31.000000'),
(74, 'DURELL', 1, 'client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé le client <strong class=\'text-info\'> \'YANKOUA\' </strong> de solde :  <strong class=\'text-danger\'> \'500000\'  </strong>', '2025-11-17', '20:52:22.000000'),
(75, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>17-11-2025  </strong>', '2025-11-17', '21:43:03.000000'),
(76, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>18-11-2025  </strong>', '2025-11-18', '08:41:41.000000'),
(77, 'DURELL-MT', 1, 'article', ' <strong class=\'text-dark\'>durell</strong> a modifié un article <strong class=\'text-info\'> \'IPHONE 7\' </strong> de montant :  <strong class=\'text-danger\'> \'45000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00009\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-18', '08:42:28.000000'),
(78, 'DURELL-MT', 1, 'article', ' <strong class=\'text-dark\'>durell</strong> a modifié un article <strong class=\'text-info\'> \'IPHONE 8\' </strong> de montant :  <strong class=\'text-danger\'> \'55000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00009\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-18', '08:42:40.000000'),
(79, 'DURELL-MT', 1, 'article', ' <strong class=\'text-dark\'>durell</strong> a modifié un article <strong class=\'text-info\'> \'IPHONE X\' </strong> de montant :  <strong class=\'text-danger\'> \'75000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00009\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-18', '08:44:15.000000'),
(80, 'DURELL-MT', 1, 'article', ' <strong class=\'text-dark\'>durell</strong> a modifié un article <strong class=\'text-info\'> \'IPHONE Xr\' </strong> de montant :  <strong class=\'text-danger\'> \'90000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00009\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-18', '08:44:27.000000'),
(81, 'DURELL-MT', 1, 'article', ' <strong class=\'text-dark\'>durell</strong> a modifié un article <strong class=\'text-info\'> \'IPHONE Xs\' </strong> de montant :  <strong class=\'text-danger\'> \'85000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00009\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-18', '08:45:10.000000'),
(82, 'DURELL-MT', 1, 'article', ' <strong class=\'text-dark\'>durell</strong> a modifié un article <strong class=\'text-info\'> \'IPHONE XsMax\' </strong> de montant :  <strong class=\'text-danger\'> \'100000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00009\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-18', '08:45:29.000000'),
(83, 'DURELL-MT', 1, 'article', ' <strong class=\'text-dark\'>durell</strong> a modifié un article <strong class=\'text-info\'> \'IPHONE 11\' </strong> de montant :  <strong class=\'text-danger\'> \'110000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00009\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-18', '08:46:30.000000'),
(84, 'DURELL-MT', 1, 'article', ' <strong class=\'text-dark\'>durell</strong> a modifié un article <strong class=\'text-info\'> \'IPHONE XsMax\' </strong> de montant :  <strong class=\'text-danger\'> \'100000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00009\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-18', '08:46:37.000000'),
(85, 'DURELL-MT', 1, 'article', ' <strong class=\'text-dark\'>durell</strong> a modifié un article <strong class=\'text-info\'> \'IPHONE XsMax\' </strong> de montant :  <strong class=\'text-danger\'> \'100000\' </strong>  de N° : <strong class=\'text-dark\'> \'ART00009\' </strong> Dispo : <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-18', '08:47:58.000000'),
(86, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMC00002 \'</strong> du client <strong class=\'text-info\'>\' SANDRA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '08:52:24.000000'),
(87, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMC00003 \'</strong>  du client <strong class=\'text-info\'>\' SHERIFA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '09:18:31.000000'),
(88, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la commande Client de N°  <strong class=\'text-info\'> \' CMC00001 \' </strong> du client :  <strong alass=\'text-danger\'> \'SHERIFA\'  </strong>', '2025-11-18', '09:18:42.000000'),
(89, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMC00003 \'</strong>  du client <strong class=\'text-info\'>\' SANDRA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '09:18:58.000000'),
(90, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>18-11-2025  </strong>', '2025-11-18', '09:37:57.000000'),
(91, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0001 \'</strong> du client <strong class=\'text-info\'>\' SANDRA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '10:24:31.000000'),
(92, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>18-11-2025  </strong>', '2025-11-18', '14:16:43.000000'),
(93, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la sortie l\'Article  <strong class=\'text-primary\'> \' IPHONE X \' </strong>  de prix <strong class=\'text-danger\'> \'  \' </strong> et quantité <strong class=\'text-success\'> \'8\'  </strong>', '2025-11-18', '14:44:39.000000'),
(94, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la sortie l\'Article  <strong class=\'text-primary\'> \' IPHONE 11 \' </strong>  de prix <strong class=\'text-danger\'> \'  \' </strong> et quantité <strong class=\'text-success\'> \'1\'  </strong>', '2025-11-18', '14:44:49.000000'),
(95, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la sortie l\'Article  <strong class=\'text-primary\'> \' IPHONE 11 \' </strong>  de prix <strong class=\'text-danger\'> \'  \' </strong> et quantité <strong class=\'text-success\'> \'1\'  </strong>', '2025-11-18', '14:51:23.000000'),
(96, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la commande Client de N°  <strong class=\'text-info\'> \' CMC00002 \' </strong> du client :  <strong alass=\'text-danger\'> \'SANDRA\'  </strong>', '2025-11-18', '14:54:12.000000'),
(97, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>18-11-2025  </strong>', '2025-11-18', '14:54:53.000000'),
(98, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la commande Four de N°  <strong class=\'text-info\'> \' CMF00001 \' </strong> de fournisseur :  <strong alass=\'text-danger\'> \'DURELL\'  </strong>', '2025-11-18', '14:56:06.000000'),
(99, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la commande Four de N°  <strong class=\'text-info\'> \' CMF00001 \' </strong> de fournisseur :  <strong alass=\'text-danger\'> \'DURELL\'  </strong>', '2025-11-18', '14:56:29.000000'),
(100, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la commande Four de N°  <strong class=\'text-info\'> \' CMF00001 \' </strong> de fournisseur :  <strong alass=\'text-danger\'> \'DURELL\'  </strong>de fournisseur :  <strong alass=\'text-success\'> \'IPHONE 11\'  </strong>de montant :  <strong alass=\'text-danger\'> \'\'  </strong>de quantite: <strong alass=\'text-dark\'>\'5\'</strong>', '2025-11-18', '15:01:28.000000'),
(101, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMF00001 \'</strong> de fournisseur <strong class=\'text-info\'>\' BAKA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '15:02:07.000000'),
(102, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la commande Four de N°  <strong class=\'text-info\'> \' CMF00001 \' </strong> de fournisseur :  <strong alass=\'text-danger\'> \'BAKA\'  </strong>de fournisseur :  <strong alass=\'text-success\'> \'IPHONE 11\'  </strong>de montant :  <strong alass=\'text-danger\'> \'110000\'  </strong>de quantite: <strong alass=\'text-dark\'>\'2\'</strong>', '2025-11-18', '15:02:29.000000'),
(103, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMF00001 \'</strong> de fournisseur <strong class=\'text-info\'>\' BOSTON \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '15:04:02.000000'),
(104, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la commande Four de N°  <strong class=\'text-info\'> \' CMF00001 \' </strong> de fournisseur :  <strong class=\'text-dark\'> \'BOSTON\'  </strong>de fournisseur :  <strong class=\'text-success\'> \'IPHONE X\'  </strong>de montant :  <strong class=\'text-danger\'> \'75000\'  </strong>de quantite: <strong class=\'text-dark\'>\'5\'</strong>', '2025-11-18', '15:04:06.000000'),
(105, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMF00001 \'</strong> de fournisseur <strong class=\'text-info\'>\' FRANCK \'</strong>  Valide :: <strong class=\'text-info\'>\' non \'</strong>  ', '2025-11-18', '15:05:07.000000'),
(106, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la commande Four de N°  <strong class=\'text-info\'> \' CMF00001 \' </strong> de fournisseur :  <strong class=\'text-dark\'> \'FRANCK\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 11\'  </strong>de montant :  <strong class=\'text-danger\'> \'110000\'  </strong>de quantite: <strong class=\'text-dark\'>\'2\'</strong>', '2025-11-18', '15:05:10.000000'),
(107, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMF00001 \'</strong> de fournisseur <strong class=\'text-info\'>\' BOSTON \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '15:06:45.000000'),
(108, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la commande Four de N°  <strong class=\'text-info\'> \' CMF00001 \' </strong> de fournisseur :  <strong class=\'text-dark\'> \'BOSTON\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 6S\'  </strong>de montant :  <strong class=\'text-danger\'> \'25000\'  </strong>de quantite: <strong class=\'text-dark\'>\'2\'</strong> valide: <strong class=\'text-success\'>\'oui\'</strong>', '2025-11-18', '15:06:49.000000'),
(109, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMF00002 \'</strong>  de fournisseur <strong class=\'text-info\'>\' BOSTON \'</strong>  Valide :: <strong class=\'text-info\'>\' non \'</strong>  ', '2025-11-18', '15:07:36.000000'),
(110, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la commande Four de N°  <strong class=\'text-info\'> \' CMF00001 \' </strong> de fournisseur :  <strong class=\'text-dark\'> \'BOSTON\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 11\'  </strong>de montant :  <strong class=\'text-danger\'> \'110000\'  </strong>de quantite: <strong class=\'text-dark\'>\'1\'</strong> valide: <strong class=\'text-success\'>\'non\'</strong>', '2025-11-18', '15:07:43.000000'),
(111, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMF00001 \'</strong> de fournisseur <strong class=\'text-info\'>\' BAKA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '15:52:42.000000'),
(112, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMC00001 \'</strong> du client <strong class=\'text-info\'>\' NANOU \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '15:53:06.000000'),
(113, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMC00002 \'</strong>  du client <strong class=\'text-info\'>\' NANOU \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '15:53:12.000000'),
(114, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la commande Client de N°  <strong class=\'text-info\'> \' CMC00001 \' </strong> de fournisseur :  <strong class=\'text-dark\'> \'NANOU\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 7\'  </strong>de montant :  <strong class=\'text-danger\'> \'55000\'  </strong>de quantite: <strong class=\'text-dark\'>\'1\'</strong> valide: <strong class=\'text-success\'>\'oui\'</strong>', '2025-11-18', '15:53:24.000000'),
(115, 'DURELL-MT', 1, 'inventaire', ' <strong class=\'text-dark\'>durell  </strong> a supprimé l\' Article <strong class=\'text-primary\'> \' IPHONE 11 \' </strong> dans l\'inventaire de prix <strong class=\'text-danger\'> \' 110000 \' </strong> et quantité <strong class=\'text-success\'> \'10\'  </strong>', '2025-11-18', '15:56:24.000000'),
(116, 'DURELL-MT', 1, 'sortie', '<strong class=\'text-dark\'>durell</strong> a ajouté une sortie de N°Facture <strong class=\'text-info\'> \'www\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 7 \' </strong>de montant :  <strong class=\'text-danger\'> \'55000\' </strong>  de qtie : <strong class=\'text-dark\'> \'1\' </strong>', '2025-11-18', '16:20:00.000000'),
(117, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la commande Client de N°  <strong class=\'text-info\'> \'  \' </strong> du client :  <strong class=\'text-dark\'> \'SANDRA\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 7\'  </strong>de montant :  <strong class=\'text-danger\'> \'55000\'  </strong>de quantite: <strong class=\'text-dark\'>\'1\'</strong> valide: <strong class=\'text-success\'>\'\'</strong>', '2025-11-18', '16:33:43.000000'),
(118, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0001 \'</strong> du client <strong class=\'text-info\'>\' NANOU \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '16:35:42.000000'),
(119, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la Facture de N°  <strong class=\'text-info\'> \' FAC0001 \' </strong> du client :  <strong class=\'text-dark\'> \'NANOU\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 8\'  </strong>de montant :  <strong class=\'text-danger\'> \'60000\'  </strong>de quantite: <strong class=\'text-dark\'>\'1\'</strong> valide: <strong class=\'text-success\'>\'\'</strong>', '2025-11-18', '16:35:51.000000'),
(120, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0001 \'</strong> du client <strong class=\'text-info\'>\' MFAMBO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '16:42:11.000000'),
(121, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la facture de N°  <strong class=\'text-info\'> \' FAC0001 \' </strong> du client :  <strong class=\'text-dark\'> \'MFAMBO\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 11\'  </strong>de montant :  <strong class=\'text-danger\'> \'150000\'  </strong>de quantite: <strong class=\'text-dark\'>\'1\'</strong> valide: <strong class=\'text-success\'>\'\'</strong>', '2025-11-18', '16:42:58.000000'),
(122, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0001 \'</strong> du client <strong class=\'text-info\'>\' DOUMO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '16:43:35.000000'),
(123, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la facture de N° <strong class=\'text-primary\'>\' FAC0002 \'</strong>  du client <strong class=\'text-info\'>\' DOUMO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '16:43:46.000000'),
(124, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la facture de N° <strong class=\'text-primary\'>\' FAC0002 \'</strong>  du client <strong class=\'text-info\'>\' DOUMO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '16:44:18.000000'),
(125, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la facture de N°  <strong class=\'text-info\'> \' FAC0001 \' </strong> du client :  <strong class=\'text-dark\'> \'DOUMO\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 6S\'  </strong>de montant :  <strong class=\'text-danger\'> \'30000\'  </strong>de quantite: <strong class=\'text-dark\'>\'2\'</strong> valide: <strong class=\'text-success\'>\'oui\'</strong>', '2025-11-18', '16:45:03.000000'),
(126, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0001 \'</strong> du client <strong class=\'text-info\'>\' ANNETTE \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-18', '16:48:16.000000'),
(127, 'DURELL-MT', 1, 'sortie', '<strong class=\'text-dark\'>durell</strong> a ajouté une sortie de N°Facture <strong class=\'text-info\'> \'FAC0001\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 7 \' </strong>de montant :  <strong class=\'text-danger\'> \'55000\' </strong>  de qtie : <strong class=\'text-dark\'> \'1\' </strong>', '2025-11-18', '16:48:52.000000'),
(128, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>19-11-2025  </strong>', '2025-11-19', '10:31:46.000000'),
(129, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la facture de N°  <strong class=\'text-info\'> \' FAC0001 \' </strong> du client :  <strong class=\'text-dark\'> \'ANNETTE\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 7\'  </strong>de montant :  <strong class=\'text-danger\'> \'55000\'  </strong>de quantite: <strong class=\'text-dark\'>\'1\'</strong> valide: <strong class=\'text-success\'>\'oui\'</strong>', '2025-11-19', '11:08:17.000000'),
(130, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0001 \'</strong> du client <strong class=\'text-info\'>\' ANNETTE \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-19', '11:16:08.000000'),
(131, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0002 \'</strong> du client <strong class=\'text-info\'>\' DOUMO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-19', '11:16:36.000000'),
(132, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0003 \'</strong> du client <strong class=\'text-info\'>\' ANNETTE \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-19', '11:16:56.000000'),
(133, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0004 \'</strong> du client <strong class=\'text-info\'>\' JOYCE \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-19', '11:17:17.000000'),
(134, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0005 \'</strong> du client <strong class=\'text-info\'>\' DOUMO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-19', '11:18:47.000000'),
(135, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la facture de N°  <strong class=\'text-info\'> \' FAC0001 \' </strong> du client :  <strong class=\'text-dark\'> \'ANNETTE\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 11\'  </strong>de montant :  <strong class=\'text-danger\'> \'150000\'  </strong>de quantite: <strong class=\'text-dark\'>\'1\'</strong> valide: <strong class=\'text-success\'>\'oui\'</strong>', '2025-11-19', '11:38:28.000000'),
(136, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la facture de N°  <strong class=\'text-info\'> \' FAC0002 \' </strong> du client :  <strong class=\'text-dark\'> \'DOUMO\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 6S\'  </strong>de montant :  <strong class=\'text-danger\'> \'30000\'  </strong>de quantite: <strong class=\'text-dark\'>\'1\'</strong> valide: <strong class=\'text-success\'>\'oui\'</strong>', '2025-11-19', '11:40:33.000000'),
(137, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la facture de N°  <strong class=\'text-info\'> \' FAC0002 \' </strong> du client :  <strong class=\'text-dark\'> \'DOUMO\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE Xs\'  </strong>de montant :  <strong class=\'text-danger\'> \'95000\'  </strong>de quantite: <strong class=\'text-dark\'>\'1\'</strong> valide: <strong class=\'text-success\'>\'oui\'</strong>', '2025-11-19', '11:41:17.000000'),
(138, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la facture de N°  <strong class=\'text-info\'> \' FAC0005 \' </strong> du client :  <strong class=\'text-dark\'> \'DOUMO\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 6S\'  </strong>de montant :  <strong class=\'text-danger\'> \'30000\'  </strong>de quantite: <strong class=\'text-dark\'>\'1\'</strong> valide: <strong class=\'text-success\'>\'oui\'</strong>', '2025-11-19', '11:41:22.000000'),
(139, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la facture de N°  <strong class=\'text-info\'> \' FAC0004 \' </strong> du client :  <strong class=\'text-dark\'> \'JOYCE\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE Xs\'  </strong>de montant :  <strong class=\'text-danger\'> \'95000\'  </strong>de quantite: <strong class=\'text-dark\'>\'4\'</strong> valide: <strong class=\'text-success\'>\'oui\'</strong>', '2025-11-19', '11:41:28.000000'),
(140, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la facture de N°  <strong class=\'text-info\'> \' FAC0004 \' </strong> du client :  <strong class=\'text-dark\'> \'JOYCE\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 6S\'  </strong>de montant :  <strong class=\'text-danger\'> \'30000\'  </strong>de quantite: <strong class=\'text-dark\'>\'5\'</strong> valide: <strong class=\'text-success\'>\'oui\'</strong>', '2025-11-19', '11:41:31.000000'),
(141, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la facture de N°  <strong class=\'text-info\'> \' FAC0003 \' </strong> du client :  <strong class=\'text-dark\'> \'ANNETTE\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE 11\'  </strong>de montant :  <strong class=\'text-danger\'> \'150000\'  </strong>de quantite: <strong class=\'text-dark\'>\'2\'</strong> valide: <strong class=\'text-success\'>\'oui\'</strong>', '2025-11-19', '11:42:07.000000'),
(142, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la facture de N°  <strong class=\'text-info\'> \' FAC0002 \' </strong> du client :  <strong class=\'text-dark\'> \'DOUMO\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE XsMax\'  </strong>de montant :  <strong class=\'text-danger\'> \'110000\'  </strong>de quantite: <strong class=\'text-dark\'>\'1\'</strong> valide: <strong class=\'text-success\'>\'oui\'</strong>', '2025-11-19', '11:42:14.000000'),
(143, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0001 \'</strong> du client <strong class=\'text-info\'>\' ANNETTE \'</strong>  Valide :: <strong class=\'text-info\'>\' non \'</strong>  ', '2025-11-19', '11:47:46.000000'),
(144, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0002 \'</strong> du client <strong class=\'text-info\'>\' SANDRA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-19', '11:49:05.000000');
INSERT INTO `notification` (`ref`, `poste`, `id_profil`, `nom_table`, `message`, `date_notif`, `heure_notif`) VALUES
(145, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0003 \'</strong> du client <strong class=\'text-info\'>\' SANDRA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-19', '11:49:21.000000'),
(146, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0004 \'</strong> du client <strong class=\'text-info\'>\' SANDRA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-19', '11:49:40.000000'),
(147, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0005 \'</strong> du client <strong class=\'text-info\'>\' DOUMO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-19', '11:49:55.000000'),
(148, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>19-11-2025  </strong>', '2025-11-19', '13:31:07.000000'),
(149, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>19-11-2025  </strong>', '2025-11-19', '15:26:41.000000'),
(150, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>19-11-2025  </strong>', '2025-11-19', '20:51:40.000000'),
(151, 'DURELL', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMC00001 \'</strong> du client <strong class=\'text-info\'>\' MFAMBO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-19', '21:32:34.000000'),
(152, 'DURELL', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMC00002 \'</strong>  du client <strong class=\'text-info\'>\' MFAMBO \'</strong>  Valide :: <strong class=\'text-info\'>\' non \'</strong>  ', '2025-11-19', '21:33:29.000000'),
(153, 'DURELL', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMC00002 \'</strong> du client <strong class=\'text-info\'>\' MFAMBO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-19', '21:39:19.000000'),
(154, 'DURELL', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMF00002 \'</strong> de fournisseur <strong class=\'text-info\'>\' BOSTON \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-19', '21:44:25.000000'),
(155, 'DURELL', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMF00003 \'</strong>  de fournisseur <strong class=\'text-info\'>\' BOSTON \'</strong>  Valide :: <strong class=\'text-info\'>\' non \'</strong>  ', '2025-11-19', '21:45:01.000000'),
(156, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>20-11-2025  </strong>', '2025-11-20', '10:14:36.000000'),
(157, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMC00003 \'</strong>  du client <strong class=\'text-info\'>\' MFAMBO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-20', '10:15:18.000000'),
(158, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>20-11-2025  </strong>', '2025-11-20', '14:09:04.000000'),
(159, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMF00003 \'</strong>  de fournisseur <strong class=\'text-info\'>\' BOSTON \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-20', '15:33:06.000000'),
(160, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell</strong> a modifié une sortie de N°Facture <strong class=\'text-info\'> \'\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 7 \' </strong>de montant :  <strong class=\'text-danger\'> \'55000\' </strong>  de qtie : <strong class=\'text-dark\'> \'1\' </strong>', '2025-11-20', '15:36:25.000000'),
(161, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell</strong> a modifié une sortie de N°Facture <strong class=\'text-info\'> \'\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 7 \' </strong>de montant :  <strong class=\'text-danger\'> \'55000\' </strong>  de qtie : <strong class=\'text-dark\'> \'1\' </strong>', '2025-11-20', '15:36:35.000000'),
(162, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>21-11-2025  </strong>', '2025-11-21', '09:34:24.000000'),
(163, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMC00003 \'</strong> du client <strong class=\'text-info\'>\' DOUMO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-21', '10:19:56.000000'),
(164, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMC00004 \'</strong>  du client <strong class=\'text-info\'>\' DOUMO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-21', '10:21:35.000000'),
(165, 'DURELL-MT', 1, 'defectueux', ' <strong class=\'text-dark\'>durell  </strong> a ajouté un article defectueux <strong class=\'text-primary\'>\' IPHONE 11 \'</strong>  de prix <strong class=\'text-danger\'>\'  110000 \'  </strong> et de quantité <strong class=\'text-success\'>\' 1 \'  </strong>', '2025-11-21', '10:26:50.000000'),
(166, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la sortie l\'Article  <strong class=\'text-primary\'> \' IPHONE 7 \' </strong>  de prix <strong class=\'text-danger\'> \' 55000 \' </strong> et quantité <strong class=\'text-success\'> \'1\'  </strong>', '2025-11-21', '10:28:10.000000'),
(167, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la sortie l\'Article  <strong class=\'text-primary\'> \' IPHONE 7 \' </strong>  de prix <strong class=\'text-danger\'> \' 55000 \' </strong> et quantité <strong class=\'text-success\'> \'1\'  </strong>', '2025-11-21', '10:28:13.000000'),
(168, 'DURELL-MT', 1, 'sortie', '<strong class=\'text-dark\'>durell</strong> a ajouté une sortie de N°Facture <strong class=\'text-info\'> \'FAC0005\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 7 \' </strong>de montant :  <strong class=\'text-danger\'> \'55000\' </strong>  de qtie : <strong class=\'text-dark\'> \'10\' </strong>', '2025-11-21', '10:28:25.000000'),
(169, 'DURELL-MT', 1, 'sortie', ' <strong class=\'text-dark\'>durell</strong> a modifié une sortie de N°Facture <strong class=\'text-info\'> \'FAC0005\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 7 \' </strong>de montant :  <strong class=\'text-danger\'> \'55000\' </strong>  de qtie : <strong class=\'text-dark\'> \'9\' </strong>', '2025-11-21', '10:29:56.000000'),
(170, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>24-11-2025  </strong>', '2025-11-24', '08:19:31.000000'),
(171, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMC00004 \'</strong>  du client <strong class=\'text-info\'>\' MFAMBO \'</strong>  Valide :: <strong class=\'text-info\'>\' non \'</strong>  ', '2025-11-24', '08:23:48.000000'),
(172, 'DURELL-MT', 1, 'profil', ' <strong class=\'text-dark\'>durell  </strong> a modifié  l\'utilisateur <strong class=\'text-primary\'> \'SHERIFA\' </strong>', '2025-11-24', '08:25:21.000000'),
(173, 'DURELL-MT', 53, 'profil', '<strong class=\'text-dark\'>SHERIFA  </strong>  </strong> s\'est connecté le <strong>24-11-2025  </strong>', '2025-11-24', '08:25:36.000000'),
(174, 'DURELL-MT', 53, 'commande_client', ' <strong class=\'text-dark\'>SHERIFA  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMC00004 \'</strong> du client <strong class=\'text-info\'>\' SANDRA \'</strong>  Valide :: <strong class=\'text-info\'>\' non \'</strong>  ', '2025-11-24', '08:26:26.000000'),
(175, 'DURELL-MT', 53, 'commande_client', ' <strong class=\'text-dark\'>SHERIFA  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMC00005 \'</strong> du client <strong class=\'text-info\'>\' DOUMO \'</strong>  Valide :: <strong class=\'text-info\'>\' non \'</strong>  ', '2025-11-24', '08:28:08.000000'),
(176, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMC00006 \'</strong>  du client <strong class=\'text-info\'>\' DOUMO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-24', '08:31:29.000000'),
(177, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMC00006 \'</strong>  du client <strong class=\'text-info\'>\' SANDRA \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-24', '08:31:36.000000'),
(178, 'DURELL-MT', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMC00006 \'</strong>  du client <strong class=\'text-info\'>\' MFAMBO \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-11-24', '08:31:43.000000'),
(179, 'DURELL-MT', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la facture de N° <strong class=\'text-primary\'>\' FAC0006 \'</strong>  du client <strong class=\'text-info\'>\' SANDRA \'</strong>  Valide :: <strong class=\'text-info\'>\' non \'</strong>  ', '2025-11-24', '09:45:42.000000'),
(180, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>24-11-2025  </strong>', '2025-11-24', '16:23:45.000000'),
(181, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>25-11-2025  </strong>', '2025-11-25', '10:40:07.000000'),
(182, 'DURELL-MT', 1, 'commande', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la commande Four de N°  <strong class=\'text-info\'> \' CMF00001 \' </strong> de fournisseur :  <strong class=\'text-dark\'> \'BAKA\'  </strong>l\'article :  <strong class=\'text-success\'> \'IPHONE XsMax\'  </strong>de montant :  <strong class=\'text-danger\'> \'100000\'  </strong>de quantite: <strong class=\'text-dark\'>\'2\'</strong> valide: <strong class=\'text-success\'>\'oui\'</strong>', '2025-11-25', '12:44:08.000000'),
(183, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>25-11-2025  </strong>', '2025-11-25', '14:34:58.000000'),
(184, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>26-11-2025  </strong>', '2025-11-26', '10:14:58.000000'),
(185, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>26-11-2025  </strong>', '2025-11-26', '16:46:06.000000'),
(186, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>27-11-2025  </strong>', '2025-11-27', '08:11:05.000000'),
(187, 'DURELL-MT', 1, 'sortie', '<strong class=\'text-dark\'>durell</strong> a ajouté une sortie de N°Facture <strong class=\'text-info\'> \'FAC0005\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 8 \' </strong>de montant :  <strong class=\'text-danger\'> \'60000\' </strong>  de qtie : <strong class=\'text-dark\'> \'2\' </strong>', '2025-11-27', '08:13:35.000000'),
(188, 'DURELL-MT', 1, 'sortie', '<strong class=\'text-dark\'>durell</strong> a ajouté une sortie de N°Facture <strong class=\'text-info\'> \'FAC0005\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 11 \' </strong>de montant :  <strong class=\'text-danger\'> \'150000\' </strong>  de qtie : <strong class=\'text-dark\'> \'2\' </strong>', '2025-11-27', '08:13:44.000000'),
(189, 'DURELL-MT', 53, 'profil', '<strong class=\'text-dark\'>SHERIFA  </strong>  </strong> s\'est connecté le <strong>27-11-2025  </strong>', '2025-11-27', '08:29:36.000000'),
(190, 'DURELL-MT', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>27-11-2025  </strong>', '2025-11-27', '15:25:06.000000'),
(191, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>29-11-2025  </strong>', '2025-11-29', '08:21:33.000000'),
(192, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>29-11-2025  </strong>', '2025-11-29', '20:09:37.000000'),
(193, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>29-11-2025  </strong>', '2025-11-29', '20:21:07.000000'),
(194, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>29-11-2025  </strong>', '2025-11-29', '23:08:38.000000'),
(195, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>29-11-2025  </strong>', '2025-11-29', '23:09:10.000000'),
(196, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>30-11-2025  </strong>', '2025-11-30', '16:14:07.000000'),
(197, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié le categorie  <strong class=\'text-info\'> \'SMART PHONE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'TELEPHONE\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-11-30', '16:40:35.000000'),
(198, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>01-12-2025  </strong>', '2025-12-01', '06:00:46.000000'),
(199, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>01-12-2025  </strong>', '2025-12-01', '08:46:55.000000'),
(200, 'DURELL', 1, 'categorie', '<strong class=\'text-dark\'>durell</strong> a ajouté la fonction <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'DEPARTEMENT  IT\' </strong> de Actif :  <strong class=\'text-success\'> \'NON\'</strong>', '2025-12-01', '09:02:13.000000'),
(201, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>01-12-2025  </strong>', '2025-12-01', '09:09:31.000000'),
(202, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'DEPARTEMENT  IT\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-01', '09:17:30.000000'),
(203, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'DEPARTEMENT  IT\' </strong> de Actif :  <strong class=\'text-success\'> \'NON\'</strong>', '2025-12-01', '09:21:53.000000'),
(204, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'DEPARTEMENT  IT\' </strong> de Actif :  <strong class=\'text-success\'> \'NON\'</strong>', '2025-12-01', '09:22:11.000000'),
(205, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'DEPARTEMENT  IT\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-01', '09:23:01.000000'),
(206, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'DEPARTEMENT  IT\' </strong> de Actif :  <strong class=\'text-success\'> \'NON\'</strong>', '2025-12-01', '09:24:05.000000'),
(207, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'DEPARTEMENT  IT\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-01', '09:24:12.000000'),
(208, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'DEPARTEMENT  IT\' </strong> de Actif :  <strong class=\'text-success\'> \'NON\'</strong>', '2025-12-01', '09:52:16.000000'),
(209, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'DEPARTEMENT  IT\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-01', '09:52:21.000000'),
(210, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'DEPARTEMENT  IT\' </strong> de Actif :  <strong class=\'text-success\'> \'NON\'</strong>', '2025-12-01', '09:57:23.000000'),
(211, 'DURELL', 1, 'categorie', '<strong class=\'text-dark\'>durell</strong> a ajouté la fonction <strong class=\'text-info\'> \'SECRETAIRE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'RAS\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-01', '09:58:08.000000'),
(212, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'DEPARTEMENT  IT\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-01', '09:58:13.000000'),
(213, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>01-12-2025  </strong>', '2025-12-01', '10:02:40.000000'),
(214, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>01-12-2025  </strong>', '2025-12-01', '10:38:38.000000'),
(215, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>01-12-2025  </strong>', '2025-12-01', '14:43:17.000000'),
(216, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>02-12-2025  </strong>', '2025-12-02', '08:56:57.000000'),
(217, 'DURELL', 1, 'fonction', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la fonction <strong class=\'text-info\'> \'SECRETAIRE\' </strong>  Actif :  <strong class=\'text-danger\'> \'OUI\'  </strong>', '2025-12-02', '10:25:10.000000'),
(218, 'DURELL', 1, 'fonction', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la fonction <strong class=\'text-info\'> \'INFORMATIQUE\' </strong>  Actif :  <strong class=\'text-danger\'> \'OUI\'  </strong>', '2025-12-02', '10:25:43.000000'),
(219, 'DURELL', 1, 'categorie', '<strong class=\'text-dark\'>durell</strong> a ajouté la fonction <strong class=\'text-info\'> \'RH\' </strong> de commentaire :  <strong class=\'text-danger\'> \'RAS\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-02', '10:25:59.000000'),
(220, 'DURELL', 1, 'categorie', '<strong class=\'text-dark\'>durell</strong> a ajouté la fonction <strong class=\'text-info\'> \'SECRETAIRE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'RAS\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-02', '10:26:13.000000'),
(221, 'DURELL', 1, 'categorie', '<strong class=\'text-dark\'>durell</strong> a ajouté la fonction <strong class=\'text-info\'> \'INFORTIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'RAS\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-02', '10:26:26.000000'),
(222, 'DURELL', 1, 'categorie', '<strong class=\'text-dark\'>durell</strong> a ajouté la fonction <strong class=\'text-info\'> \'VIRGILE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'RAS\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-02', '10:26:40.000000'),
(223, 'DURELL', 1, 'fonction', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la fonction <strong class=\'text-info\'> \'VIRGILE\' </strong>  Actif :  <strong class=\'text-danger\'> \'OUI\'  </strong>', '2025-12-02', '10:26:44.000000'),
(224, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>03-12-2025  </strong>', '2025-12-03', '10:12:56.000000'),
(225, 'DURELL', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a modifié la commande Four de N° <strong class=\'text-primary\'>\' CMC00006 \'</strong>  du client <strong class=\'text-info\'>\' MFAMBO \'</strong>  Valide :: <strong class=\'text-info\'>\' non \'</strong>  ', '2025-12-03', '10:14:05.000000'),
(226, 'DURELL', 1, 'fonction', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la fonction <strong class=\'text-info\'> \'RH\' </strong>  Actif :  <strong class=\'text-danger\'> \'OUI\'  </strong>', '2025-12-03', '10:16:16.000000'),
(227, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>03-12-2025  </strong>', '2025-12-03', '14:24:01.000000'),
(228, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'RAS\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-03', '14:57:32.000000'),
(229, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>03-12-2025  </strong>', '2025-12-03', '22:24:46.000000'),
(230, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>04-12-2025  </strong>', '2025-12-04', '09:23:46.000000'),
(231, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>05-12-2025  </strong>', '2025-12-05', '09:27:30.000000'),
(232, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>05-12-2025  </strong>', '2025-12-05', '14:33:18.000000'),
(233, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-05', '14:44:37.000000'),
(234, 'DURELL', 1, 'categorie', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'INFORMATIQUE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'ras\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-05', '14:45:17.000000'),
(235, 'DURELL', 1, 'employe', '<strong class=\'text-dark\'>durell</strong> a ajouté un employe <strong class=\'text-info\'> \'MFAMBO\' </strong> de code :  <strong class=\'text-danger\'> \'EMP00001\' </strong> de salaire :  <strong class=\'text-danger\'> \'300000\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-05', '17:17:05.000000'),
(236, 'DURELL', 1, 'employe', '<strong class=\'text-dark\'>durell</strong> a ajouté un employe <strong class=\'text-info\'> \'MFAMBO\' </strong> de code :  <strong class=\'text-danger\'> \'EMP00002\' </strong> de salaire :  <strong class=\'text-danger\'> \'300000\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-05', '17:17:44.000000'),
(237, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>07-12-2025  </strong>', '2025-12-07', '07:27:10.000000'),
(238, 'DURELL', 1, 'employe', '<strong class=\'text-dark\'>durell</strong> a ajouté un employe <strong class=\'text-info\'> \'MFAMBO\' </strong> de code :  <strong class=\'text-danger\'> \'EMP00003\' </strong> de salaire :  <strong class=\'text-danger\'> \'3000000\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-07', '07:36:16.000000'),
(239, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>08-12-2025  </strong>', '2025-12-08', '12:01:27.000000'),
(240, 'DURELL', 1, 'employe', '<strong class=\'text-dark\'>durell</strong> a ajouté un employe <strong class=\'text-info\'> \'YANKOUA\' </strong> de code :  <strong class=\'text-danger\'> \'EMP00004\' </strong> de salaire :  <strong class=\'text-danger\'> \'500000\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-08', '15:28:16.000000'),
(241, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>09-12-2025  </strong>', '2025-12-09', '12:11:44.000000'),
(242, 'DURELL', 1, 'employe', '<strong class=\'text-dark\'>durell</strong> a ajouté un employe <strong class=\'text-info\'> \'BALEN\' </strong> de code :  <strong class=\'text-danger\'> \'EMP00005\' </strong> de salaire :  <strong class=\'text-danger\'> \'200000\' </strong> de Actif :  <strong class=\'text-success\'> \'NON\'</strong>', '2025-12-09', '12:18:23.000000'),
(243, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>09-12-2025  </strong>', '2025-12-09', '15:17:19.000000'),
(244, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>10-12-2025  </strong>', '2025-12-10', '09:01:42.000000'),
(245, 'DURELL', 1, 'client', '<strong class=\'text-dark\'>durell</strong> a ajouté le Client <strong class=\'text-info\'> \'RAHP\' </strong> de solde :  <strong class=\'text-danger\'> \'0\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-10', '09:18:55.000000'),
(246, 'DURELL', 1, 'client', ' <strong class=\'text-dark\'>durell</strong> a modifié le Client  <strong class=\'text-info\'> \'RAHP\' </strong> de solde :  <strong class=\'text-danger\'> \'0\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-10', '09:19:17.000000'),
(247, 'DURELL', 1, 'commande_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la commande Four de N° <strong class=\'text-primary\'>\' CMC00006 \'</strong> du client <strong class=\'text-info\'>\' RAHP \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-12-10', '09:20:09.000000'),
(248, 'DURELL', 1, 'facture_client', ' <strong class=\'text-dark\'>durell  </strong> a ajouté la facture  de N° <strong class=\'text-primary\'>\' FAC0006 \'</strong> du client <strong class=\'text-info\'>\' RAHP \'</strong>  Valide :: <strong class=\'text-info\'>\' oui \'</strong>  ', '2025-12-10', '09:22:17.000000'),
(249, 'DURELL', 1, 'sortie', '<strong class=\'text-dark\'>durell</strong> a ajouté une sortie de N°Facture <strong class=\'text-info\'> \'FAC0006\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE X \' </strong>de montant :  <strong class=\'text-danger\'> \'85000\' </strong>  de qtite : <strong class=\'text-dark\'> \'2\' </strong>', '2025-12-10', '09:24:11.000000'),
(250, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>11-12-2025  </strong>', '2025-12-11', '12:17:00.000000'),
(251, 'DURELL', 1, 'fonction', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'SECRETAIRE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'RAS\' </strong> de Actif :  <strong class=\'text-success\'> \'NON\'</strong>', '2025-12-11', '12:18:23.000000'),
(252, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>11-12-2025  </strong>', '2025-12-11', '18:55:00.000000'),
(253, 'DURELL', 1, 'employe', '<strong class=\'text-dark\'>durell</strong> a ajouté un employe <strong class=\'text-info\'> \'MEPONG\' </strong> de code :  <strong class=\'text-danger\'> \'EMP00006\' </strong> de salaire :  <strong class=\'text-danger\'> \'200000\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-11', '19:12:06.000000'),
(254, 'DURELL', 1, 'employe', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la fonction <strong class=\'text-info\'> \'\' </strong>  Actif :  <strong class=\'text-danger\'> \'\'  </strong>', '2025-12-11', '19:12:44.000000'),
(255, 'DURELL', 1, 'employe', ' <strong class=\'text-dark\'>durell  </strong> a supprimé la fonction <strong class=\'text-info\'> \'\' </strong>  Actif :  <strong class=\'text-danger\'> \'\'  </strong>', '2025-12-11', '19:17:06.000000'),
(256, 'DURELL', 1, 'fonction', '<strong class=\'text-dark\'>durell</strong> a ajouté la fonction <strong class=\'text-info\'> \'RH\' </strong> de commentaire :  <strong class=\'text-danger\'> \'RAS\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-11', '19:18:53.000000'),
(257, 'DURELL', 1, 'fonction', ' <strong class=\'text-dark\'>durell</strong> a modifié la fonction  <strong class=\'text-info\'> \'SECRETAIRE\' </strong> de commentaire :  <strong class=\'text-danger\'> \'RAS\' </strong> de Actif :  <strong class=\'text-success\'> \'OUI\'</strong>', '2025-12-11', '19:19:32.000000'),
(258, 'DURELL', 1, 'sortie', '<strong class=\'text-dark\'>durell</strong> a ajouté une sortie de N°Facture <strong class=\'text-info\'> \'FAC0006\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE X \' </strong>de montant :  <strong class=\'text-danger\'> \'85000\' </strong>  de qtite : <strong class=\'text-dark\'> \'2\' </strong>', '2025-12-11', '19:27:51.000000'),
(259, 'DURELL', 1, 'sortie', '<strong class=\'text-dark\'>durell</strong> a ajouté une sortie de N°Facture <strong class=\'text-info\'> \'FAC0006\' </strong> l\'article :  <strong class=\'text-danger\'> \' IPHONE 11 \' </strong>de montant :  <strong class=\'text-danger\'> \'150000\' </strong>  de qtite : <strong class=\'text-dark\'> \'2\' </strong>', '2025-12-11', '19:29:22.000000'),
(260, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>11-12-2025  </strong>', '2025-12-11', '20:08:35.000000'),
(261, 'DURELL', 1, 'profil', '<strong class=\'text-dark\'>durell  </strong>  </strong> s\'est connecté le <strong>12-12-2025  </strong>', '2025-12-12', '09:03:37.000000');

-- --------------------------------------------------------

--
-- Structure de la table `profil`
--

DROP TABLE IF EXISTS `profil`;
CREATE TABLE IF NOT EXISTS `profil` (
  `id_profil` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT 'INFORMATICIEN',
  `identifiant` varchar(50) CHARACTER SET latin1 NOT NULL,
  `email` varchar(30) CHARACTER SET latin1 NOT NULL,
  `password` varchar(200) CHARACTER SET latin1 NOT NULL,
  `commentaire` varchar(112) CHARACTER SET latin1 DEFAULT NULL,
  `dispoUser` varchar(3) NOT NULL DEFAULT 'OUI',
  PRIMARY KEY (`id_profil`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `profil`
--

INSERT INTO `profil` (`id_profil`, `type`, `identifiant`, `email`, `password`, `commentaire`, `dispoUser`) VALUES
(1, 'admin', 'durell', '', '61c8889b6ce80051755bc5050bc5d0dfdff39589', 'Administrateur', 'OUI'),
(50, 'INFORMATICIEN', 'admin', '', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'ras', 'OUI'),
(52, 'INFORMATICIEN', 'dylan', '', '61c8889b6ce80051755bc5050bc5d0dfdff39589', 'ttt', 'OUI'),
(53, 'SECRETAIRE', 'SHERIFA', '', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'RAS', 'OUI');

-- --------------------------------------------------------

--
-- Structure de la table `sortie`
--

DROP TABLE IF EXISTS `sortie`;
CREATE TABLE IF NOT EXISTS `sortie` (
  `id_sortie` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `numero` varchar(255) NOT NULL,
  `id_client` int(11) NOT NULL,
  `id_article` int(11) NOT NULL,
  `referenceArticle` varchar(255) NOT NULL,
  `prixVente` int(11) NOT NULL,
  `qtite` int(11) NOT NULL,
  `tva` varchar(3) NOT NULL,
  `montantTva` int(11) NOT NULL,
  PRIMARY KEY (`id_sortie`),
  KEY `id_article` (`id_article`),
  KEY `id_client` (`id_client`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sortie`
--

INSERT INTO `sortie` (`id_sortie`, `date`, `numero`, `id_client`, `id_article`, `referenceArticle`, `prixVente`, `qtite`, `tva`, `montantTva`) VALUES
(7, '2025-11-21', 'FAC0005', 14, 2, ' 128Go / Batt 90%', 55000, 9, 'NON', 550000),
(8, '2025-11-27', 'FAC0005', 14, 3, ' 256Go / Batt 82%', 60000, 2, 'NON', 120000),
(9, '2025-11-27', 'FAC0005', 14, 8, ' 64Go / Batt 95%', 150000, 2, 'NON', 300000),
(10, '2025-12-10', 'FAC0006', 16, 4, ' 64Go / Batt 90%', 85000, 2, 'NON', 170000),
(11, '2025-12-11', 'FAC0006', 15, 4, ' 64Go / Batt 90%', 85000, 2, 'NON', 170000),
(12, '2025-12-11', 'FAC0006', 15, 8, ' 64Go / Batt 95%', 150000, 2, 'NON', 300000);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `facture_article`
--
ALTER TABLE `facture_article`
  ADD CONSTRAINT `facture_article_ibfk_1` FOREIGN KEY (`id_fournisseur`) REFERENCES `fournisseur` (`id_fournisseur`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
