<?php
$lang["accueil"] = "Home";
$lang["lettre_motivation"] = "cover letter";
$lang["offre_emploi"] = "job offer";
$lang["about"] = "About";
$lang["boost_carriere"] = "Need to boost your career ?";
$lang["slogan"] = "Make a difference by uploading CV most appreciated by recruiters";
$lang["rediger"] ="Write";
$lang["postuler_ligne"] = "apply online";
$lang["decrocher_job"] = "and get a job";
$lang["pourquoi"] = "Why";
$lang["choisir"] ="choose";
$lang["texte1"] = "is a must-have platform for any job seeker with its tailor-made service that allows you to optimize your quest for employment";
$lang["avec"] = "With";
$lang["vous_pourrez"] = "you will be able";
$lang["presentation"] = "My name is";
$lang["idee_lancer"] = "Where does the idea of ​​launching ";
$lang["mon_histoire"] = "My story";
$lang["texte2"] ="Young student looking for alternation for her Master 2, ";
$lang["texte2suite1"] ="I encountered many obstacles in my quest";
$lang["texte2suite2"] = " (CV writing problems and cover letter, poor job search techniques, missed interview etc)";
$lang["texte2suite3"] = "These obstacles have forged a character and allowed me to understand a maximum of secrets to get my alternation. I managed to get my alternation in M2 in an area where I had no experience and skills. Discover my History ";
$lang["texte2suite4"] = "Because during this beautiful experience of alternation quest, I learned a lot of techniques and tips on job search, I thought it would be interesting to share this experience with people in the need.";
$lang["ou_vient"] = "Hence the idea of ";
$lang["texte2suite5"] = "The experience has been with students and job seekers.";
$lang["texte2suite6"] = "It has been so successful; in less than a month, they have won permanent contracts, internships and alternations.";
$lang["ici"] = "HERE";
$lang["telecharg_motiv"] = "Create and download free resume and cover letter seller";
$lang["beneficie_coching"] = "benefit from personalized coaching on your job search";
$lang["nos_services"] = "Take advantage of our personalized services according to your needs";
$lang["postulez_emploi"] = "Apply for job offers";
$lang["texteCoching"] = "If you are looking for a smart coching for your job search, write us and we will analyze your need and make a quote";
$lang["nomPrenom"] = "last name and first name";
$lang["pays"] = "Country";
$lang["envoyer"] = "send";
$lang["amelioreCV"] = "Improve your resume and cover letter";
$lang["texteAmelioreCV"] = "The resume and cover letter reflect your image. It is very important to use it to highlight your know-how, your personality and your skills. This coaching will allow you to highlight your profile to captivate the recruiter.

   <br/><br/> If you are interested in this coaching, fill in this information";
$lang["nom"] = "name";
$lang["numeroTelephone"] = "Phone number";
$lang["coutCoching"] = "This coaching cost
";
$lang["heure"] = "hour";
$lang["cochingEnLigne"] =  "Coaching is online.";
$lang["optimiseRechEmploi"] = "Optimize your job search";
$lang["texteOptimiseRechEmploi"] = "There are many job search techniques to optimize your search.In this coaching, you will benefit from advanced techniques that have been tested and proven by job seekers.
<br/><br/>In Bonus you will have a coaching to improve your LinkedIn image.
<br/><br/>If you are interested in this coaching, fill in this information.";
$lang["optimiseEntretient"] = "Coching to optimize your interviews";
$lang["texteOptimiseEntretient"] = "You have taken the most important step, your CV has been selected and the recruiter has contacted you for an interview.
                            Recruiters select an average of 4 candidates for interviews. So you have a 25% chance of being recruited.
                            Do not miss this opportunity, trust us, because we will provide you with tips to easily land the Job of your dreams.
                           <br/><br/>
                            If you are interested in this coaching, fill in this information";
$lang["transitionPro"] = "Professional transition to information systems";
$lang["texteTransitionPro"] = "You are passionate about information systems and you want to carry out a professional reconversion, we offer tailor-made training to optimize and facilitate your conversion.We will put at your disposal specific courses to realize this dream.
                            Customized training adapted to your needs. Conditions to benefit from this training:
                            <br/><br/> 
                            Have at least a license (no matter the specialization)
                            <br/>
                             Have at least 6 months of experience.
                             <br/>
                             The training has a duration of one month.
                             <br/>
                             If you are interested in this coaching, fill in this information:";
$lang["cochingSolution"] = "Coaching a solution for you";
$lang["titreCochingSolution"] = "Contact an online advisor to learn about business approach techniques.";
$lang["votreCarrure"] = "Your build";
$lang["texteVotreCarrure"] = "The professional build is a significant element when you face an employer.";
$lang["sensTiming"] = "The meaning of timing";
$lang["texteSensTiming"] = "Learning to manage your time is an essential part of your professional life.";
$lang["derniereCreation"] = "Latest creations";
$lang["astuce&conseil"] = "tips & advice";
$lang["cvApprecier"] = "CV most apreciated";
$lang["abonnezVous"] = "SUBSCRIBE TO OUR NEWS LETTER Discover our tips and tricks to get the job of your dreams";

?>
