<?php

$lang['acctualite'] ='Atualitano';
$lang['auto_ecole'] = 'conduce';
$lang['voyage'] ='Voyagerano fr';
$lang['presentation'] = 'voyaer fr';

?>