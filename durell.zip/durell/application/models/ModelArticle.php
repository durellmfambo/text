<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class ModelArticle extends CI_Model {

    function __construct() {

        parent::__construct();
        $this->load->database('default');  $this->load->library('session'); $this->load->helper('cookie'); $this->load->helper('url');
        
    }


    public function notificationAjout($table,$securite){

        $this->db->query(
            
           "INSERT 
            INTO notification 
            VALUE
            (
                '',
                '".php_uname('n')."',
                ".$this->session->userdata('id_profil').",
                '".$table."',
                '".$securite."',
                now(),now()
            )"
            
        );
        $this->db->close();
    }


    public function getUsername($id_profil){

        $requete = $this->db->query(
            
           "SELECT * 
            FROM profil 
            WHERE id_profil=".$id_profil.""

        )->row();

        if (count($requete)>0) {
            
            return $requete->identifiant;
        }
        $this->db->close();
    }


    public function getArticle($id){

        $requete= $this->db->query(
            
           "SELECT * 
            FROM article 
            WHERE id_article = ".$id.""
            
        )->row();

        if (count($requete)>0) {
            
            return $requete->nomArticle;
        }
        $this->db->close();
    }


    public function getFournisseur($id){

        $requete= $this->db->query(
            
           "SELECT * 
            FROM fournisseur 
            WHERE id_fournisseur = ".$id.""
            
        )->row();

        if (count($requete)>0) {
            
            return $requete->nomFour;
        }
        $this->db->close();
    }


    public function getClient($id){

        $requete= $this->db->query(
            
           "SELECT * 
            FROM client 
            WHERE id_client = ".$id.""
            
        )->row();

        if (count($requete)>0) {
            
            return $requete->nomClient;
        }
        $this->db->close();
    }



    /* CATEGORIE ARTICLE */

    public function codeCategorieArticle(){ 

        $requete = $this->db->query(
            
           "SELECT * 
            FROM Categorie 
            ORDER BY id_categorie DESC limit 1"
        
        )->row();

        $codeCatego =0;

        if (count($requete)>0) {
            $codeCatego = $requete->codeCatego;
        }else{
            $codeCatego = 0;
        }

        $codeCatego++;

        while (strlen($codeCatego)<5) {
            $codeCatego = "0".$codeCatego;
        }
        return "CAT".filter_var($codeCatego, FILTER_SANITIZE_NUMBER_INT);
    }



    public function ajoutCategorieArticle(){

        $choix = $_POST["choix"];    $codeCatego = $this->codeCategorieArticle();

        $nomCatego = $_POST["nomCatego"];   $commentaireCatego = addslashes($_POST['commentaireCatego']); $dateCatego = $_POST["dateCatego"];

        $actifCatego = $_POST["actifCatego"];   $table = "categorie";

        $securiteA = "<strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a ajouté le categorie <strong class='text-info'> '" . $nomCatego . "' </strong> de commentaire :  <strong class='text-danger'> '" . $commentaireCatego . "' </strong> de Actif :  <strong class='text-success'> '" . $actifCatego . "'</strong>";

        $securiteM = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a modifié le categorie  <strong class='text-info'> '" . $nomCatego . "' </strong> de commentaire :  <strong class='text-danger'> '" . $commentaireCatego . "' </strong> de Actif :  <strong class='text-success'> '" . $actifCatego . "'</strong>";

        if ($choix == "ajouter") {

            $requeteNomCatego = $this->db->query(
                
               "SELECT * 
                FROM categorie 
                WHERE nomCatego ='" . $nomCatego . "' "
                
            )->result_array();

            if (count($requeteNomCatego) > 0) {

                echo "Cette categorie '" . $nomCatego . "' apparaît déjà ";
            }
            else {
                $query1 = $this->db->query(
                    
                   "INSERT 
                    INTO categorie 
                    VALUE
                    (
                        '',
                        '".$codeCatego."',
                        '" . $nomCatego . "',
                        '" . $commentaireCatego . "',
                        CAST('" . $dateCatego . "' AS DATE),
                        '".$actifCatego."'
                    )"
                );
                
                if ($query1 == true) {
                    echo "Insertion éffectuée ";
                    $this->notificationAjout($table, addslashes($securiteA));
                } 
                else {
                    echo "Erreur durant l'insertion";
                }
            }
        } 
        elseif ($choix == "modifier") {
         
            $id_table = $_POST["id_table"];
            
            $requete = $this->db->query(
                
               "SELECT * 
                FROM categorie 
                WHERE  nomCatego ='" . $nomCatego . "' "
                
            )->result_array();

            if (count($requete) > 0) {

                foreach ($requete as $row) {

                    if ($row["id_categorie"] == $id_table) {
                
                        $query1 = $this->db->query(
                            
                           "UPDATE categorie 
                            SET 
                                nomCatego ='" . $nomCatego . "',
                                commentaireCatego = '" . $commentaireCatego . "', 
                                dateCatego = CAST('" . $dateCatego . "' AS DATE),
                                actifCatego='".$actifCatego."' 

                            WHERE id_categorie =" . $id_table . ""
                            
                        );
                        if ($query1 == true) {
                            echo "Modification éffectuée";
                            $this->notificationAjout($table, addslashes($securiteM));
                        } 
                        else {
                            echo "Problème pendant la Modification";
                        }
                    } 
                    else {
                        echo "Cette categorie \"" . $nomCatego . "\" apparaît déjà ";
                    }
                }
            } 
            else {
                $query1 = $this->db->query(
                    
                   "UPDATE categorie 
                    set  
                        nomCatego ='" . $nomCatego . "', 
                        commentaireCatego = '" . $commentaireCatego . "' , 
                        dateCatego = CAST('" . $dateCatego . "' AS DATE) ,
                        actifCatego='".$actifCatego."'

                    WHERE id_categorie =" . $id_table . "");
                
                if ($query1 == true) {
                    echo "Modification éffectuée";
                    $this->notificationAjout($table, addslashes($securiteM));
                } 
                else {
                    echo "Problème pendant la Modification";
                }
            }
        } 
        else {
            echo "problème se trouvant dans l'ajoutCategorieArticle";
        }
        $this->db->close();
    }


    public function afficheDataCategorieArticle(){

        /*
        // Charger la librairie Excel
        $this->load->library('excel');

        // Charger un fichier Excel
        $objPHPExcel = PHPExcel_IOFactory::load(FCPATH . "excel/exemple.xlsx");

        // Sélectionner la première feuille
        $sheet = $objPHPExcel->setActiveSheetIndex(0);

        // Parcourir les lignes
        foreach ($sheet->getRowIterator() as $row) {
            $cellIterator = $row->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(false);

            $code    = '';
            $article = '';
            $date    = '';

            $i = 0;

            foreach ($cellIterator as $cell) {
                if ($i == 1) {
                    $code = trim($cell->getValue());
                }
                if ($i == 2) {
                    $article = trim($cell->getValue());
                }
                if ($i == 3) {
                    $date = trim($cell->getValue());
                }
                $i++;
            }

            // Vérifier si la catégorie existe déjà
            $query = $this->db->query("SELECT * FROM categorie WHERE codeCatego = ?", [$code])->row();

            if (empty($query)) {
                // Insertion avec Active Record (plus sécurisé)
                $this->db->insert('categorie', [
                    'codeCatego' => $code,
                    'nomCatego'  => $article,
                    'commentaireCatego'=> 'RAS',
                    'dateCatego' => $date,
                    'actifCatego'      => 'OUI'
                ]);
            }
        }  */

        
        $query1 = $this->db->query(
            
           'SELECT * 
            FROM categorie 
            ORDER BY nomCatego ASC'
            
        )->result_array();

        $i = 0;

        foreach ($query1 as $row) {
        
            echo 
            "<tr>
                <td onclick=\"new();\">" . $i . "</td>
                <td>" . $row['codeCatego'] . "</td>
                <td>" . $row['nomCatego'] . "</td>
                <td> " . $row['dateCatego'] . "</td>";

                if ($row['actifCatego'] == 'OUI') {
                    echo"<td class='text-success'><strong><i class='nav-icon fas fa-check-circle'></i></strong></td>";
                }
                if ($row['actifCatego'] == 'NON') {
                    echo"<td class='text-danger'><strong><i class='nav-icon fas fa-times-circle'></i></strong></td>";
                }echo"
                <td>";
                    if ($this->session->userdata('autoArticle_voir') == 'true') {
                        echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"VoirCategorieArticle('" . $row['id_categorie'] . "','" . $row['codeCatego'] . "','" . $row['nomCatego'] . "','" . addslashes($row['commentaireCatego']) . "','" . $row['dateCatego']  . "','".$row['actifCatego']."')\" class=' ml-2'><i class='nav-icon fas fa-eye text-info'></i></a>";
                    }

                    if ($this->session->userdata('autoArticle_modification') == 'true') {
                        echo "<a type='button' onclick=\"modiCategorieArticle('" . $row['id_categorie'] . "','" . $row['codeCatego'] . "','" . $row['nomCatego'] . "','" . addslashes($row['commentaireCatego']) . "','" . $row['dateCatego'] . "','".$row['actifCatego']."')\" class=' ml-2 '><i class='nav-icon 	fas fa-pen text-success'></i></a>";
                    }

                    if ($this->session->userdata('autoArticle_suppression') == 'true') {
                        echo "<a type='button' class='ml-2' data-toggle='modal' data-target='#supprimer' table='categorie' identifiant='" . $row['id_categorie'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_categorie\");'><i class='far fas fa-trash text-danger'></i></a>
                </td>
            </tr>"; }
            $i++;
        }
        $this->db->close();
    }


    public function dropCategorieArticle($a, $b, $c){

        $CategorieArticle = $this->db->query(
            
           "SELECT * 
            FROM " . $a . " 
            WHERE " . $c . "=" . $b . ""
            
        )->row();

        if (count($CategorieArticle) > 0) {
        
            $table = $a;

            $securiteS = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé la CategorieArticle <strong class='text-info'> '" . $CategorieArticle->nomCatego . "' </strong>  Actif :  <strong class='text-danger'> '" . $CategorieArticle->actifCatego . "'  </strong>";

            $drop = $this->db->query(
                
               "DELETE 
                FROM " . $a . " 
                WHERE " . $c . "=" . $b . ""
            );
            if ($drop == true) {
                
                echo "Suppression effectuée";
                $this->notificationAjout($table, addslashes($securiteS));
            } else {
                echo "Probleme pendant de la suppression";
            }
        }


        $this->db->close();
    }


    public function ListeCategorieArticle(){

        $query = $this->db->query(
            
           "SELECT * 
            FROM categorie 
            WHERE actifCatego = 'OUI' 
            ORDER BY nomCatego ASC"
            
        )->result_array();

        if (count($query) >0) {
            
            foreach ($query as $row) {
                
                echo "<option value='".$row["id_categorie"]."'>".$row["nomCatego"]."</option>";
            }
        }else{
            echo "<option disabled>Aucune categorie actif trouvée</option>";
        }

        $this->db->close();
    }

    
    public function nbreActifCategorieArticle(){

        $query = $this->db->query(
            
           "SELECT COUNT(*) AS nombre_categorie 
            FROM categorie 
            WHERE actifCatego = 'OUI'"
            
        )->row_array();

        echo $query['nombre_categorie'];
    }




    /*  ARTICLE */

    public function codeArticle(){ 

        $CodeArticle = $this->db->query(
            
           "SELECT * 
            from article 
            ORDER BY id_article desc limit 1"
            
        )->row();

        $numero =0;

        if (count($CodeArticle)>0) {
            $numero = $CodeArticle->numeroArticle;
        }else{
            $numero = 0;
        }

        $numero++;

        while (strlen($numero)<5) {
            $numero = "0".$numero;
        }
        return "ART".filter_var($numero, FILTER_SANITIZE_NUMBER_INT);
    }


    public function ajoutArticle(){


        $choix = $_POST["choix"];                               $numeroArticle = $this->codeArticle();

        $id_categorie = $_POST["id_categorie"];                   $referenceArticle = $_POST["referenceArticle"];

        $dateArticle = $_POST["dateArticle"];                     $nomArticle = $_POST["nomArticle"];

        $commentaireArticle = $_POST['commentaireArticle'];       $montantArticle = preg_replace('/\s/', '', $_POST["montantArticle"]);

        $statusArticle = $_POST["statusArticle"];                  $id_fournisseur = $_POST["id_fournisseur"];
        
        $table = "article";                                    $referenceArticle = $_POST["referenceArticle"];

        $prixVente = preg_replace('/\s/', '', $_POST["prixVente"]);


        $notifAjout = "<strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a ajouté un article <strong class='text-info'> '" . $nomArticle . "' </strong> de montant :  <strong class='text-danger'> '" . $montantArticle . "' </strong>  de N° : <strong class='text-dark'> '" . $numeroArticle . "' </strong> Dispo : <strong class='text-success'> '" . $statusArticle . "'</strong>";

        $notifModif = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a modifié un article <strong class='text-info'> '" . $nomArticle . "' </strong> de montant :  <strong class='text-danger'> '" . $montantArticle . "' </strong>  de N° : <strong class='text-dark'> '" . $numeroArticle . "' </strong> Dispo : <strong class='text-success'> '" . $statusArticle . "'</strong>";

        if ($choix == "ajouter") {
            
            $requete = $this->db->query(
                
               "SELECT * 
                FROM article 
                WHERE nomArticle ='" . $nomArticle . "' "
                
            )->result_array();


            if (count($requete) > 0) {

                echo "Cet Article '" . $nomArticle . "' apparaît déjà ";
            }
            else {

                $query1 = $this->db->query(

                   "INSERT 
                    INTO article 
                    VALUE
                    (
                        '',
                        '".$numeroArticle."',
                        '" . $id_categorie . "',
                        '" . $id_fournisseur . "',
                        CAST('" . $dateArticle . "' AS DATE),
                        '" . $nomArticle . "',
                        " . $montantArticle . ",
                        " . $prixVente . ",
                        '" . $referenceArticle . "',
                        '" . $commentaireArticle . "',
                        '".$statusArticle."'
                    ) "

                );
                
                if ($query1 == true) {
                    echo "Insertion éffectuée";
                    $this->notificationAjout($table, addslashes($notifAjout));
                } 
                else {
                    echo "Erreur durant l'insertion";
                }
            }
        } 
        elseif ($choix == "modifier") {
        
            $id_table  = $_POST["id_table"];
            
            $requete = $this->db->query(
                
               "SELECT * 
                FROM article 
                WHERE  nomArticle ='" . $nomArticle . "' "
                
            )->result_array();

            if (count($requete) > 0) {

                foreach ($requete as $row) {

                    if ($row["id_article"] == $id_table ) {
                
                        $query1 = $this->db->query(
                            
                           "UPDATE article 
                            SET

                              nomArticle ='" . $nomArticle . "',  
                              id_categorie ='" . $id_categorie . "',
                              id_fournisseur ='" . $id_fournisseur . "', 
                              dateArticle = CAST('" . $dateArticle . "' AS DATE),
                              montantArticle = '" . $montantArticle . "',
                              prixVente = '" . $prixVente . "', 
                              referenceArticle = '" . $referenceArticle . "',  
                              commentaireArticle = '" . $commentaireArticle . "', 
                              statusArticle ='".$statusArticle."' 

                            WHERE id_article  =" . $id_table  . "");
                        if ($query1 == true) {
                            echo "Modification éffectuée";
                            $this->notificationAjout($table, addslashes($notifModif));
                        } 
                        else {
                            echo "Problème pendant la Modification";
                        }
                    } 
                    else {
                        echo "Cet article \"" . $nomArticle . "\" apparaît déjà ";
                    }
                }
            } 
            else {
                $query1 = $this->db->query(
                    
                   "UPDATE article 
                    SET  
                    
                        nomArticle ='" . $nomArticle . "', 
                        id_categorie ='" . $id_categorie . "', 
                        id_fournisseur ='" . $id_fournisseur . "', 
                        dateArticle = CAST('" . $dateArticle . "' AS DATE), 
                        montantArticle = '" . $montantArticle . "', 
                        prixVente = '" . $prixVente . "', 
                        referenceArticle = '" . $referenceArticle . "',  
                        commentaireArticle = '" . $commentaireArticle . "', 
                        statusArticle ='".$statusArticle."' 
                        
                    WHERE id_article  =" . $id_table  . "");
                    
                if ($query1 == true) {
                    echo "Modification éffectuée";
                    $this->notificationAjout($table, addslashes($notifModif));
                } 
                else {
                    echo "Problème pendant la Modification";
                }
            }
        } 
        else {
            echo "problème se trouvant dans l'ajoutClient";
        }
        $this->db->close();
    }


    public function afficheDataArticle(){

        $requete = $this->db->query(
           'SELECT * 
            FROM article 
            ORDER BY nomArticle ASC')->result_array();
        $i = 0;

        foreach ($requete as $row) {

            
            $Fournisseur = $this->db->query(
               "SELECT * 
                FROM fournisseur 
                WHERE id_fournisseur  =".$row['id_fournisseur'].""
            )->row();
            
        
            echo 
            "<tr>
                <td onclick=\"new();\">" . $i . "</td>
                <td>" . $row['numeroArticle'] . "</td>
                <td>" . $row['nomArticle'] . "</td>
                <td>" . $Fournisseur->nomFour . "</td>
                <td> " . $row['referenceArticle'] . "</td>
                <td> <strong class='text-danger'>".number_format($row['montantArticle'],0,',',' ')."</strong></td>
                <td> <strong class='text-danger'>".number_format($row['prixVente'],0,',',' ')."</strong></td>
                <td> " . $row['dateArticle'] . "</td>";

                if ($row['statusArticle'] == 'OUI') {
                    echo"<td class='text-success'><strong><i class='nav-icon fas fa-check-circle'></i></strong></td>";
                }
                if ($row['statusArticle'] == 'NON') {
                    echo"<td class='text-danger'><strong><i class='nav-icon fas fa-times-circle'></i></strong></td>";
                }echo"
                <td>";
                    if ($this->session->userdata('autoArticle_voir') == 'true') {
                        echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"VoirArticle('" . $row['id_article'] . "','" . $row['numeroArticle'] . "','" . $row['id_categorie'] . "','" . $row['id_fournisseur'] . "','" . $row['dateArticle'] . "','" . $row['nomArticle'] . "','" . $row['montantArticle'] . "','" . $row['prixVente'] . "','" . $row['referenceArticle'] . "','" . addslashes($row['commentaireArticle']) . "','".$row['statusArticle']."')\" class=' ml-2'><i class='nav-icon fas fa-eye text-info'></i></a>";
                    }

                    if ($this->session->userdata('autoArticle_modification') == 'true') {
                       echo "<a type='button' onclick=\"modiArticle('" . $row['id_article'] . "','" . $row['numeroArticle'] . "','" . $row['id_categorie'] . "','" . $row['id_fournisseur'] . "','" . $row['dateArticle'] . "','" . $row['nomArticle'] . "','" . $row['montantArticle'] . "','" . $row['prixVente'] . "','" . $row['referenceArticle'] . "','" . addslashes($row['commentaireArticle']) . "','".$row['statusArticle']."')\" class=' ml-2'><i class='nav-icon 	fas fa-pen text-success'></i></a>";
                       }

                    if ($this->session->userdata('autoArticle_suppression') == 'true') {
                        echo "<a type='button' class='ml-2' data-toggle='modal' data-target='#supprimer' table='article' identifiant='" . $row['id_article'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_article\");'><i class='far fas fa-trash text-danger'></i></a>
                </td>
            </tr>"; }
            $i++;
        }
        $this->db->close();
    }


    public function dropArticle($a, $b, $c){

        $article = $this->db->query(
            
           "SELECT * 
            FROM " . $a . " 
            WHERE " . $c . "=" . $b . ""
            
        )->row();

        if (count($article) > 0) {
        
            $table = $a;

            $securiteS = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé l'article <strong class='text-info'> '" . $article->nomArticle . "' </strong> de solde :  <strong class='text-danger'> '" . $article->montantArticle . "'  </strong>";


            $supp = $this->db->query(
                
               "DELETE 
                FROM " . $a . " 
                WHERE " . $c . "=" . $b . ""
            
            );

            if ($supp == true) {
                
                echo "Suppression effectuée";
                $this->notificationAjout($table, addslashes($securiteS));
            } else {
                echo "Problème pendant la suppression";
            }
        }


        $this->db->close();
    }


    public function ListeArticle(){

        $requete = $this->db->query(
            
           "SELECT * 
            FROM article 
            WHERE statusArticle = 'OUI' 
            ORDER BY nomArticle ASC"
            
        )->result_array();

        if (count($requete) >0) {
            
            foreach ($requete as $row) {
                
                echo "<option value='".$row["id_article"]."'>".$row["nomArticle"]."</option>";
            }
        }else{
            echo "<option disabled>Aucun Article actif trouvé</option>";
        }

        $this->db->close();
    }

    
    public function nbreActifArticle(){
        
        $query = $this->db->query(
            
           "SELECT COUNT(*) AS nbr 
            FROM article 
            WHERE statusArticle = 'OUI'"
            
        )->row_array();
        echo $query['nbr'];
    }
    




    /* COMMANDE FOURNISSEUR */
 

    public function MontantArticle(){
    
        $id_article = $_POST["id_article"];
        

        if (empty($id_article)) {
            
            echo "0";
        }else{
            $Article = $this->db->query(
               "SELECT * 
                FROM article 
                WHERE id_article = ".$id_article." "
            
            )->row();

            echo $Article->montantArticle;
        }

        $this->db->close();
    }

    public function PrixDeVente(){
    
        $id_article = $_POST["id_article"];
        

        if (empty($id_article)) {
            
            echo "0";
        }else{
            $Article = $this->db->query(
                
               "SELECT * 
                FROM article 
                WHERE id_article = ".$id_article." "

            )->row();

            echo $Article->prixVente;
        }

        $this->db->close();
    }


    public function ReferenceArticle(){

        $id_article = $_POST["id_article"];

        $Article = $this->db->query(
            
           "SELECT * 
            FROM article 
            WHERE id_article = ".$id_article.""
            
        )->row();

        if(count($Article)>0){
            echo $Article->referenceArticle;
        }else{
         echo "Pas de reference";
        }
        
        $this->db->close();
    } 


    public function CodeFournisseur(){

        $id_fournisseur = $_POST["id_fournisseur"];

        $Fournisseur = $this->db->query(
            
           "SELECT * 
            FROM fournisseur 
            WHERE id_fournisseur = ".$id_fournisseur.""
            
        )->row();

        if(count($Fournisseur)>0){
            echo $Fournisseur->codeFour;
        }else{
         echo "Pas de code";
        }
        
        $this->db->close();
    }


    public function AdresseFournisseur(){

        $id_fournisseur = $_POST["id_fournisseur"];

        $Fournisseur = $this->db->query(
            
           "SELECT * 
            FROM fournisseur 
            WHERE id_fournisseur = ".$id_fournisseur.""
            
        )->row();

        if(count($Fournisseur)>0){
            echo $Fournisseur->adresseFour;
        }else{
         echo "Pas d'adresse";
        }
        
        $this->db->close();
    } 


    public function TelFournisseur(){

        $id_fournisseur = $_POST["id_fournisseur"];

        $Fournisseur = $this->db->query(
            
           "SELECT * 
            FROM fournisseur 
            WHERE id_fournisseur = ".$id_fournisseur.""
            
        )->row();

        if(count($Fournisseur)>0){
            echo $Fournisseur->telFour;
        }else{
         echo "Pas de numero de telephone";
        }
        
        $this->db->close();
    }


    public function codeCommande(){ 


        $CodeComF = $this->db->query(
            
           "SELECT * 
            FROM commande 
            ORDER BY id_commande desc limit 1"
            
        )->row();

        $code =0;
        if (count($CodeComF)>0) { 
            $code = $CodeComF->codeCom; 
        }else{ 
            $code = 0;
        }
            $code++; 
        while (strlen($code)<5) {
        
            $code = "0".$code;
        }

        return "CMF".filter_var($code, FILTER_SANITIZE_NUMBER_INT);
    }

    
    public function allLigneCommande(){
        
        $nbreLignes = $_POST["nbreLignes"];
        $i=1;
        
        while ( $i<= $nbreLignes) {
            
            echo 
            '<div class="row">

                <div class="col-md-1">
                    <div class="form-group">
                        <label>N°</label>
                        <input type="text" style="border-radius:20px;"class="form-control nbr'.$i.'" placeholder="" value = "'.$i.'" disabled="true" >
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Article</label>                                                                                
                        <select style="border-radius:20px;" class="id_article'.$i.' form-control" onchange="MontantArticle($(\'.id_article'.$i.'\').val(),\'montantCom'.$i.'\');ReferenceArticle($(\'.id_article'.$i.'\').val(),\'referenceCom'.$i.'\');">
                            <option value=""></option>';
                            $this->ModelArticle->ListeArticle(); echo'
                        </select>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <label>Reference</label>
                    <input type="text" style="border-radius:20px;" class="form-control referenceCom'.$i.'" placeholder=""  disabled = "true" >
                </div>
                
                <div class="col-md-2">
                    <label>Montant</label>
                    <input type="text" style="border-radius:20px;" class="form-control montantCom'.$i.'"disabled = "true"  >
                </div>

                <div class="col-md-1">
                    <label>Qtite</label>
                    <input type="text" style="border-radius:20px;" class="form-control qtiteCom'.$i.'">
                </div>
        

                <div class="col-md-1" >
                    <div class="form-group">
                        <label>Fermer</label>
                        <select style="border-radius:20px;" class="typeCom'.$i.' form-control" onchange="activePrix(\'.typeCom'.$i.'\',\'.montantCom'.$i.'\');">
                            <option>oui</option>
                            <option>non</option>
                        </select>
                    </div>
                </div>            
        
            </div> ';
            $i++;
        }  echo '
        
        <div class="row mt-2"> 

            <div class="col-md-1 mt-4"> 
                <a type="button"   class=" btn-light btn "  onclick="montantTVACom();"><i class="fas fa-plus-circle" aria-hidden="true"></i></a>
            </div> 

            <div class="col-md-2">
                <div class="form-group">
                    <label>TVA</label>
                    <input type="text" style="border-radius:20px;" class="montantTVA form-control"  onkeypress="chiffres(event);"  disabled = "true">
                </div>
            </div>

            <div class="col-md-6"></div>

            <div class="col-md-1 mt-4"> 
                <a type="button"   class=" btn-light btn "  onclick="montantTotalCom();"><i class="fas fa-plus-circle" aria-hidden="true"></i></a>
            </div> 

            <div class="col-md-2">
                <div class="form-group">
                    <label>Total</label>
                    <input type="text" style="border-radius:20px;" class="montantTotal form-control"  onkeypress="chiffres(event);"  disabled = "true">
                </div>
            </div>
            
        </div> ';
 
        $this->db->close();
    }

    public function allLigneFacture(){
        
        $nbreLignes = $_POST["nbreLignes"];
        $i=1;
        
        while ( $i<= $nbreLignes) {
            
            echo 
            '<div class="row ">

                <div class="col-md-1">
                    <div class="form-group">
                        <label>N°</label>
                        <input type="text" style="border-radius:20px;"class="form-control nbr'.$i.'" placeholder="" value = "'.$i.'" disabled="true" >
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Article</label>                                                                                
                        <select style="border-radius:20px;" class="id_article'.$i.' form-control" onchange="PrixDeVente($(\'.id_article'.$i.'\').val(),\'prixVenteCom'.$i.'\');ReferenceArticle($(\'.id_article'.$i.'\').val(),\'referenceCom'.$i.'\');">
                            <option value=""></option>';
                            $this->ModelArticle->ListeArticle(); echo'
                        </select>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <label>Reference</label>
                    <input type="text" style="border-radius:20px;" class="form-control referenceCom'.$i.'" placeholder=""  disabled = "true" >
                </div>
                
                <div class="col-md-2">
                    <label>Montant</label>
                    <input type="text" style="border-radius:20px;" class="form-control prixVenteCom'.$i.'"disabled = "true"  >
                </div>

                <div class="col-md-1">
                    <label>Qtite</label>
                    <input type="text" style="border-radius:20px;" class="form-control qtiteCom'.$i.'">
                </div>
        

                <div class="col-md-1" >
                    <div class="form-group">
                        <label>Fermer</label>
                        <select style="border-radius:20px;" class="typeCom'.$i.' form-control" onchange="activePrix(\'.typeCom'.$i.'\',\'.prixVenteCom'.$i.'\');">
                            <option>oui</option>
                            <option>non</option>
                        </select>
                    </div>
                </div>            
        
            </div> ';
            $i++;
        }  echo '
        
        <div class="row mt-2"> 

            <div class="col-md-1 mt-4"> 
                <a type="button"   class=" btn-light btn "  onclick="montantTVA();"><i class="fas fa-plus-circle" aria-hidden="true"></i></a>
            </div> 

            <div class="col-md-2">
                <div class="form-group">
                    <label>TVA</label>
                    <input type="text" style="border-radius:20px;" class="montantTVA form-control"  onkeypress="chiffres(event);"  disabled = "true">
                </div>
            </div>

            <div class="col-md-6"></div>

            <div class="col-md-1 mt-4"> 
                <a type="button"   class=" btn-light btn "  onclick="montantTotal();"><i class="fas fa-plus-circle" aria-hidden="true"></i></a>
            </div> 

            <div class="col-md-2">
                <div class="form-group">
                    <label>Total</label>
                    <input type="text" style="border-radius:20px;" class="montantTotal form-control"  onkeypress="chiffres(event);"  disabled = "true">
                </div>
            </div>
            
        </div> ';
 
        $this->db->close();
    }


    public function ajoutCommande(){

        $codeCom = $this->codeCommande();                         $id_fournisseur = $_POST['id_fournisseur'];
        $codeFour = $_POST['codeFour'];                           $adresseFour = $_POST['adresseFour'];
        $telFour = $_POST['telFour'];                             $dateCrea = $_POST['dateCrea'];
        $dateCom = $_POST['dateCom'];                             $nbreLignes = $_POST["nbreLignes"];
        $valideCom = $_POST['valideCom'];                         $choix = $_POST["choix"];
        
        $id_article = json_decode($_POST['id_article']);          $referenceCom = json_decode($_POST['referenceCom']);
        $montantCom = json_decode($_POST['montantCom']);          $qtiteCom = json_decode($_POST['qtiteCom']); 
        $typeCom = json_decode($_POST['typeCom']);                $id_commande = json_decode($_POST['id_commande']);
        

        $table = "commande"; 

        $securiteA =  " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a ajouté la commande Four de N° <strong class='text-primary'>' " .$codeCom. " '</strong> de fournisseur <strong class='text-info'>' " .$this->getFournisseur($id_fournisseur). " '</strong>  Valide :: <strong class='text-info'>' " .$valideCom. " '</strong>  ";

        $securiteM =  " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a modifié la commande Four de N° <strong class='text-primary'>' " .$codeCom. " '</strong>  de fournisseur <strong class='text-info'>' " .$this->getFournisseur($id_fournisseur). " '</strong>  Valide :: <strong class='text-info'>' " .$valideCom. " '</strong>  ";


        if ($choix == "ajouter") {
            
    
            $i = 1;

            while ( $i<= $nbreLignes) {

                $requeteA = $this->db->query(

                  "INSERT 
                   INTO commande 
                   VALUE
                   (
                        '',
                        '".$codeCom."',
                        ".$id_fournisseur.",
                        CAST('". $dateCrea."' AS DATE),
                        CAST('". $dateCom."' AS DATE), 
                        ".$id_article[$i].",
                        '".$referenceCom[$i]."',
                        ".intval(preg_replace('/\s/','', $montantCom[$i])).",
                        '".$qtiteCom[$i]."', 
                        '".$typeCom[$i]."',
                        '".$valideCom."',
                        '".$codeFour."',
                        '".$adresseFour."',
                        '".$telFour."'
                    )"
                );

                $i++; 
            }

            if ($requeteA == true) {
                
                echo "Insertion éffectuée";
                $this->notificationAjout($table,addslashes($securiteA));
                
            }else{
                echo "probleme pendant l'insertion";
            }

        }elseif ($choix == "modifier") {
            
            $i = 1;
            while ( $i<= $nbreLignes) { 

        $requeteM = $this->db->query(
            
           "UPDATE commande 
            SET  
                dateCrea = CAST('". $dateCrea."' AS DATE), 
                id_fournisseur=".$id_fournisseur.", 
                dateCom = CAST('". $dateCom."' AS DATE), 
                id_article =".$id_article[$i].", 
                qtiteCom =".$qtiteCom[$i].", 
                montantCom =".intval(preg_replace('/\s/','', $montantCom[$i])).", 
                referenceCom = '".addslashes($referenceCom[$i])."', 
                typeCom='".$typeCom[$i]."',
                valideCom='".$valideCom."',
                codeFour='".$codeFour."',
                adresseFour='".$adresseFour."',
                telFour='".$telFour."' 
                
            where id_commande =".$id_commande[$i].""
        
        );

        $i++; 
        }

            if ($requeteM == true) {
                
                echo "Modification éffectuée";

                $this->notificationAjout($table,addslashes($securiteM));

            }else{
                echo "probleme pendant l'insertion";
            }

        }else{
            echo "Probleme de connexion";
        }

        $this->db->close();
    }

 
    public function afficheDataCommande(){ 

	    if (isset($_POST["dateDebut"]) && isset($_POST["dateFin"]) && isset($_POST["id_nom"])) {
            
            $dateDebut = $_POST['dateDebut'];  $dateFin = $_POST['dateFin']; $id_nom = $_POST['id_nom'];
            
		    if (!empty($dateFin) && !empty($dateDebut) && isset($_POST["id_nom"])) {

                $requete = $this->db->query(
                    
                   "SELECT  * 
                    FROM commande 
                    WHERE  id_fournisseur = '".$id_nom."' and dateCom between '".$dateDebut."' and '".$dateFin."'  
                    ORDER BY  dateCom DESC"
                    
                )->result_array();

                if ($id_nom == 'TOUT') {
                    
                    $requete = $this->db->query(
                        
                       "SELECT  * 
                        FROM commande 
                        WHERE  dateCom between '".$dateDebut."' and '".$dateFin."'  
                        ORDER BY dateCom DESC"
                        
                    )->result_array();
                
                }else {
                    
                    $requete = $this->db->query(
                        
                       "SELECT  * 
                        FROM commande 
                        WHERE id_fournisseur = '".$id_nom."' and  dateCom between '".$dateDebut."' and '".$dateFin."' 
                        ORDER BY dateCom DESC "
                        
                    )->result_array();
                    
                }	
            
            }else{
                
                $requete = $this->db->query(
                    
                   "SELECT  * 
                    FROM commande  
                    ORDER BY id_commande DESC"
                    
                )->result_array();    
            }		
            
        }else{ 
            $requete = $this->db->query(
                
               "SELECT * 
                FROM commande 
                ORDER BY id_commande desc"
                
            )->result_array();
        }	
        
        
        $i = 0; $cqtite = 0;  $cmontantTotal = 0; $cmontantCom = 0;
        if (count($requete) >0 ) {
            

            foreach ($requete as $row) {

                $getArticle = $this->db->query(

                   "SELECT * 
                    FROM article 
                    WHERE id_article =".$row['id_article'].""
                    
                )->row();
               
                $getFournisseur = $this->db->query(
                    
                   "SELECT * 
                    FROM fournisseur 
                    where id_fournisseur=".$row['id_fournisseur'].""
                    
                )->row();
                
                
                $cqtite = $cqtite + $row["qtiteCom"];      $cmontantCom = $cmontantCom + $row["montantCom"];

                $prix = $row['montantCom']*$row['qtiteCom'];   $cmontantTotal = $cmontantTotal + $prix;

                echo 

               "<tr>
                    <td onclick=\"new();\">" .$i. "</td>
                    <td>".$row['codeCom']."</td> 
                    <td>".$getArticle->nomArticle."</td> 
                    <td> ".$row['referenceCom']."</td>
                    <td> <strong class='text-primary'>".number_format($row['montantCom'],0,',',' ')."</strong></td>
                    <td> <strong class='text-dark'>".number_format($row['qtiteCom'],0,',',' ')."</strong></td>
                    <td> <strong class='text-danger'>".number_format($row['qtiteCom'] *$row['montantCom'],0,',',' ')."</strong></td>
                    <td> ".$row['dateCom']."</td>

                    <td>"; 

                    $validation = $this->db->query(
                        
                       "SELECT valideCom 
                        FROM commande 
                        WHERE codeCom = '".$row['codeCom']."' and valideCom= 'oui' limit 1"
                        
                    )->row(); 
	  
                    
                    if (count($validation) >0 ) {
                        echo"<td'><a type='button'  class=' btn btn-sm' onclick='printCommande(\"".$row['codeCom']."\",\"".$getFournisseur->nomFour."\",\"".$row['dateCom']."\",\"".$row['dateCrea']."\",\"".$row['codeFour']."\",\"".$row['adresseFour']."\",\"".$row['telFour']."\", \"".number_format($this->MontantCommande($row['codeCom']),0,',',' ')." F\")'><i class='nav-icon fas fa-bell text-dark'></i></a></td>";
                    }echo"

                    
                    <td>";
                        if ($this->session->userdata('autoArticle_voir') == 'true') {
                            echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"voirCommande('"  . $row['id_commande'] . "','" . $row['codeCom'] . "','" . $row['id_fournisseur'] . "','" . $row['dateCrea'] . "','" . $row['dateCom'] . "','" . $row['id_article'] . "','" . $row['referenceCom'] . "','" . $row['montantCom'] . "','" . $row['qtiteCom'] . "','" . $row['typeCom'] . "','" . $row['valideCom'] . "','" . $row['codeFour'] . "','" . $row['adresseFour'] . "','" . $row['telFour'] . "')\" class=' ml-1'><i class='nav-icon  	fas fa-eye text-info'></i></a>";
                        }

                        if ($this->session->userdata('autoArticle_modification') == 'true') {
                            echo "<a type='button' onclick=\"modiCommande('"  . $row['id_commande'] . "','" . $row['codeCom'] . "','" . $row['id_fournisseur'] . "','" . $row['dateCrea'] . "','" . $row['dateCom'] . "','" . $row['valideCom'] . "','" . $row['codeFour'] . "','" . $row['adresseFour'] . "','" . $row['telFour'] . "')\" class=' ml-2'><i class='nav-icon	fas fa-pencil-alt text-success'></i></a>";
                        } 

                        if ($this->session->userdata('autoArticle_suppression') == 'true') {
                            echo "<a type='button' class='ml-2' data-toggle='modal' data-target='#supprimer' table='commande' identifiant='" . $row['id_commande'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_commande\");'><i class='far  	fas fa-trash text-danger'></i></a>
                    </td>

                    

                    
                </tr>";}
                $i++;
            }
        }echo "
        <tr>
            <td style='border: 0px;'><b>Total</b></td> 
            <td style='border: 0px'></td>
            <td style='border: 0px'></td>
            <td style='border: 0px'></td>
            <td style='border: 0px'><b class='text-primary'>".number_format($cmontantCom,0,',',' ')."</b></td>
            <td style='border: 0px'><b class='text-dark'>".number_format($cqtite,0,',',' ')."</b></td> 
            <td style='border: 0px'><b class='text-danger'>".number_format($cmontantTotal,0,',',' ')."</b></td>
            <td style='border: 0px'>
            </td><td style='border: 0px'></td></td><td style='border: 0px'></td>
        </tr>";
        $this->db->close();
    }


    public function MontantCommande($codeCom){

        $requete = $this->db->query(

           'SELECT * 
            FROM commande 
            WHERE codeCom = "'.$codeCom.'"'
            
        )->result_array();
        $somme = 0;

        foreach ($requete as $row) {
            
            $total = $row["montantCom"]*$row["qtiteCom"];
            $somme = $somme + $total;
        }
        return $somme;

        $this->db->close();
    }


    public function modifieDataCommande(){

        $codeCom = $_POST["codeCom"];
        $Commande = $this->db->query(
            
           "SELECT * 
            FROM commande 
            WHERE codeCom = '".$codeCom."' "
            
        )->result_array();

        $i=1;

        foreach ($Commande as $com) {
            
            echo 
            '<div class="row">

                    <div class="col-md-1">
                        <div class="form-group">
                            <label>N°</label>
                            <input type="text" style="border-radius:20px;"class="form-control nbr'.$i.'" placeholder="" value = "'.$i.'" disabled="true" >
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Article</label>
                            <select style="border-radius:20px;" class="id_article'.$i.' form-control" onchange="MontantArticle($(\'.id_article'.$i.'\').val(),\'montantCom'.$i.'\');ReferenceArticle($(\'.id_article'.$i.'\').val(),\'referenceCom'.$i.'\');">';
                               
                                $getArticle = $this->db->query(
                                   "SELECT * 
                                    FROM article 
                                    WHERE id_article = ".$com['id_article'].""
                                )->row(); echo"

                                <option value='".$com['id_article']."'>".$getArticle->nomArticle."</option>";
                                $this->ModelArticle->ListeArticle();echo '
                            </select>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group ">
                            <label>Référence</label>
                            <input type="text" style="border-radius:20px;" class="form-control referenceCom'.$i.'" disabled = "true" value="'.addslashes($com["referenceCom"]).' ">
                        </div>
                    </div>

                    <div class="col-md-2">
                        <label>Montant</label>
                        <input type="text" style="border-radius:20px;" class="form-control montantCom'.$i.'" disabled = "true" placeholder=" " value="'.$com["montantCom"].'" onkeypress="chiffres(event);" >
                    </div>

                    <div class="col-md-1">
                        <label>Qtite</label>
                        <input type="text" style="border-radius:20px;" class="form-control qtiteCom'.$i.'" placeholder=" " value="'.$com["qtiteCom"].'"  onkeypress="chiffres(event);">
                    </div> 
                    

                    <input type="hidden" class="form-control id_commande'.$i.'"  placeholder=" en FCFA" value="'.$com["id_commande"].'" disabled="true" onkeypress="chiffres(event);">

                    <div class="col-md-1">
                        <div class="form-group">
                            <label>Fermer</label>
                            <select style="border-radius:20px;" class="typeCom'.$i.' form-control" onchange="activePrix(\'.typeCom'.$i.'\',\'.montantCom'.$i.'\');">';
                                if ($com['typeCom'] == 'oui') {
                                    echo '
                                    <option>oui</option>
                                    <option>non</option>';
                                }
                                else {
                                    echo '
                                    <option>non</option>
                                    <option>oui</option>';
                                }echo '
                            </select>
                        </div>
                    </div>
                </div>
                <hr>';
            $i++;
        }
        $i = $i-1;

        echo '<input type="hidden" class="form-control compteur"  placeholder=" en FCFA" value="'.$i.'" disabled="true" onkeypress="chiffres(event);">';

        $this->db->close();
    }


    public function PrintCommande(){

        $codeCom = $_POST["codeCom"];  $c = 0;

        $requete = $this->db->query(
           'SELECT * 
            FROM commande 
            where codeCom ="'.$codeCom.'" 
            ORDER BY  dateCom desc'
        )->result_array();
        
        foreach ($requete as $mod) {  echo

               "<tr style='border:none; text-align:center;font-size: 16px;padding:0px;'>

                    <td colspan='1' style='border:none; text-align:center;padding:0px;' >".$mod['codeCom']."</td>";

                    $Article = $this->db->query(
                       "SELECT * 
                        FROM article 
                        WHERE id_article = ".$mod['id_article'].""
                    )->row(); echo"
                    
                    <td colspan='2' style='border: none; text-align:center;padding:0px;'>".$Article->nomArticle."</td>";   echo"
            
                    <td colspan='2' style='border:none; text-align:center;padding:0px;'>".$mod['referenceCom']."</td>

                    <td style='border: none; text-align:center;padding:0px;'><strong class='text-danger'>".number_format($mod['montantCom'],0,',',' ')."</td>
                    
                    <td  style='border:none; text-align:center;padding:0px;'><strong class='text-dark'>".$mod['qtiteCom']."</td>
                
                    <td colspan='2' style='border:none; text-align:center;padding:0px;'><strong class='text-danger'>".number_format($mod['montantCom']*$mod['qtiteCom'],0,',',' ')."</td>";
                    
             
                $c++;
        }

        $this->db->close();
    }

 
    public function dropCommande($a, $b, $c){

        $Commande = $this->db->query(
           "SELECT * 
            FROM " . $a . " where " . $c . "=" . $b . ""
        )->row();

        if (count($Commande) > 0) {
        
            $table = $a; 

            $securiteS = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé la commande Four de N°  <strong class='text-info'> ' " . $Commande->codeCom . " ' </strong> de fournisseur :  <strong class='text-dark'> '" .$this->getFournisseur($Commande->id_fournisseur).  "'  </strong>l'article :  <strong class='text-success'> '" .$this->getArticle($Commande->id_article).  "'  </strong>de montant :  <strong class='text-danger'> '" .$Commande->montantCom.  "'  </strong>de quantite: <strong class='text-dark'>'" .$Commande->qtiteCom.  "'</strong> valide: <strong class='text-success'>'" .$Commande->valideCom. "'</strong>";


            $drop = $this->db->query(
               "DELETE 
                FROM ". $a . " 
                WHERE " . $c . "=" . $b . ""
            );

            if ($drop == true) {
                
                echo "Suppression effectuée";
                $this->notificationAjout($table, addslashes($securiteS));
            } 
            else {
                echo "probleme pendant la suppression";
            }
        }
        $this->db->close();
    }
 

    public function nbrePrintCommande(){

        $query = $this->db->query(
            
           "SELECT COUNT(DISTINCT codeCom) AS nbr 
            FROM commande  "
            
            )->row_array();

        echo $query['nbr'];
    }

    public function nbreNonPrintCommande(){

        $query = $this->db->query(
           "SELECT COUNT(DISTINCT codeCom) AS nbr 
            FROM commande 
            WHERE valideCom = 'non'"
        )->row_array();

        echo $query['nbr'];
    }




    /* COMMANDE CLIENT */


    public function CodeClient(){

        $id_client = $_POST["id_client"];

        $Client = $this->db->query(
          "SELECT * 
           FROM client 
           WHERE id_client = ".$id_client.""
        )->row();

        if(count($Client)>0){
            echo $Client->codeClient;
        }else{
         echo "Pas de code";
        }
        
        $this->db->close();
    }


    public function AdresseClient(){

        $id_client = $_POST["id_client"];

        $Client = $this->db->query(
           "SELECT * 
            FROM client 
            WHERE id_client = ".$id_client.""
        )->row();

        if(count($Client)>0){
            echo $Client->adresseClient;
        }else{
         echo "Pas d'adresse";
        }
        
        $this->db->close();
    } 


    public function TelClient(){
        $id_client = $_POST["id_client"];

        $Client = $this->db->query(
           "SELECT * 
            FROM client 
            WHERE id_client = ".$id_client.""
        )->row();

        if(count($Client)>0){
            echo $Client->telClient;
        }else{
         echo "Pas de numero de telephone";
        }
        
        $this->db->close();
    }

        
    public function codeCommandeClient(){ 

        $CodeClient = $this->db->query(
           "SELECT *
            FROM commande_client 
            ORDER BY id_commandeClient DESC limit 1"
        )->row();

        $code =0;
        
        if (count($CodeClient)>0) {
        
            $code = $CodeClient->codeCom;

        }else{ 
            $code = 0;
        }
        
        $code++; 
        while (strlen($code)<5) { 
            $code = "0".$code;
        }

        return "CMC".filter_var($code, FILTER_SANITIZE_NUMBER_INT);
    }


    public function ajoutCommandeClient(){

        $codeCom = $this->codeCommandeClient();                   $id_client = $_POST['id_client'];
        $codeClient = $_POST['codeClient'];                       $adresseClient = $_POST['adresseClient'];
        $telClient = $_POST['telClient'];                         $dateCrea = $_POST['dateCrea'];
        $dateCom = $_POST['dateCom'];                             $nbreLignes = $_POST["nbreLignes"];
        $valideCom = $_POST['valideCom'];                         $choix = $_POST["choix"];

        $id_article = json_decode($_POST['id_article']);            $referenceCom = json_decode($_POST['referenceCom']);
        $prixVenteCom = json_decode($_POST['prixVenteCom']);              $typeCom = json_decode($_POST['typeCom']);
        $id_commandeClient = json_decode($_POST['id_commandeClient']);  $qtiteCom = json_decode($_POST['qtiteCom']);
        
        
        
        

        $table = "commande_client"; 

        $securiteA =  " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a ajouté la commande Four de N° <strong class='text-primary'>' " .$codeCom. " '</strong> du client <strong class='text-info'>' " .$this->getClient($id_client). " '</strong>  Valide :: <strong class='text-info'>' " .$valideCom. " '</strong>  ";

        $securiteM =  " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a modifié la commande Four de N° <strong class='text-primary'>' " .$codeCom. " '</strong>  du client <strong class='text-info'>' " .$this->getClient($id_client). " '</strong>  Valide :: <strong class='text-info'>' " .$valideCom. " '</strong>  ";


        if ($choix == "ajouter") {
            
    
            $i = 1;

            while ( $i<= $nbreLignes) {

                $query = $this->db->query(
                   "INSERT 
                    INTO commande_client 
                    VALUE
                    (
                        '',
                        '".$codeCom."',
                        ".$id_client.",
                        CAST('". $dateCrea."' AS DATE),
                        CAST('". $dateCom."' AS DATE),
                        ".$id_article[$i].",
                        '".$referenceCom[$i]."',
                        ".intval(preg_replace('/\s/','', $prixVenteCom[$i])).",
                        '".$qtiteCom[$i]."', 
                        '".$typeCom[$i]."',
                        '".$valideCom."',
                        '".$codeClient."',
                        '".$adresseClient."',
                        '".$telClient."'
                    )"
                );

                $i++; 
            }

            if ($query == true) {
                
                echo "Insertion éffectuée";
                $this->notificationAjout($table,addslashes($securiteA));
                
            }else{
                echo "probleme pendant l'insertion";
            }

        }elseif ($choix == "modifier") {
            
            $i = 1;
            while ( $i<= $nbreLignes) { 

        $query = $this->db->query(
           "UPDATE commande_client 
            SET  
                dateCrea = CAST('". $dateCrea."' AS DATE), 
                id_client=".$id_client.", 
                dateCom = CAST('". $dateCom."' AS DATE), 
                id_article =".$id_article[$i].",
                qtiteCom =".$qtiteCom[$i].", 
                prixVenteCom =".intval(preg_replace('/\s/','', $prixVenteCom[$i])).", 
                referenceCom = '".addslashes($referenceCom[$i])."', 
                typeCom='".$typeCom[$i]."',
                valideCom='".$valideCom."',
                codeClient='".$codeClient."',
                adresseClient='".$adresseClient."',
                telClient='".$telClient."' 
            WHERE id_commandeClient =".$id_commandeClient[$i].""
        );
        $i++; 
        }

            if ($query == true) {
                
                echo "Modification éffectuée";
                $this->notificationAjout($table,addslashes($securiteM));

            }else{
                echo "probleme pendant l'insertion";
            }

        }else{
            echo "Probleme de connexion";
        }

        $this->db->close();
    }


    public function afficheDataCommandeClient(){

	    if (isset($_POST["dateDebut"]) && isset($_POST["dateFin"]) && isset($_POST["id_nom"])) {
            
            $dateDebut = $_POST['dateDebut'];  $dateFin = $_POST['dateFin'];  $id_nom = $_POST['id_nom'];
            
		    if (!empty($dateFin) && !empty($dateDebut) && isset($_POST["id_nom"])) {

                $requete = $this->db->query(
                   "SELECT  * 
                    FROM commande_client 
                    WHERE  id_client = '".$id_nom."' and dateCom between '".$dateDebut."' and '".$dateFin."'  
                    ORDER BY dateCom DESC"
                )->result_array();

                if ($id_nom == 'ALL') {
                    
                    $requete = $this->db->query(
                       "SELECT  * 
                        FROM commande_client 
                        WHERE  dateCom between '".$dateDebut."' and '".$dateFin."'  
                        ORDER BY dateCom DESC"
                    )->result_array();
                
                }else {
                    
                    $requete = $this->db->query(
                       "SELECT  * 
                        FROM commande_client 
                        WHERE id_client = '".$id_nom."' and  dateCom between '".$dateDebut."' and '".$dateFin."' 
                        ORDER BY dateCom DESC "
                    )->result_array();
                    
                }	
            
            }else{
                
                $requete = $this->db->query(
                   "SELECT  * 
                    FROM commande_client  
                    ORDER BY id_commandeClient DESC"
                )->result_array();    
            }		
            
        }else{ 
            $requete = $this->db->query(
               "SELECT * 
                FROM commande_client 
                ORDER BY id_commandeClient desc"
            )->result_array();
        }	
        
        if (count($requete) >0 ) {
            
            $i = 0; $cqtite = 0;  $cmontantTotal = 0; $cprixVenteCom = 0;

            foreach ($requete as $row) {

                $getArticle = $this->db->query(
                   "SELECT * 
                    FROM article 
                    WHERE id_article =".$row['id_article']." "
                )->row();
               
                $getClient = $this->db->query(
                   "SELECT * 
                    FROM client 
                    WHERE id_client=".$row['id_client'].""
                )->row();
                
                $cqtite = $cqtite + $row["qtiteCom"];      $cprixVenteCom = $cprixVenteCom + $row["prixVenteCom"];

                $prix = $row['prixVenteCom']*$row['qtiteCom'];   $cmontantTotal = $cmontantTotal + $prix;

                echo "

                <tr>
                    <td onclick=\"new();\">" .$i. "</td>
                    <td>".$row['codeCom']."</td> 
                    <td>".$getArticle->nomArticle."</td> 
                    <td> ".$row['referenceCom']."</td>
                    <td> <strong class='text-primary'>".number_format($row['prixVenteCom'],0,',',' ')."</strong></td>
                    <td> <strong class='text-dark'>".number_format($row['qtiteCom'],0,',',' ')."</strong></td>
                    <td> <strong class='text-danger'>".number_format($row['qtiteCom'] *$row['prixVenteCom'],0,',',' ')."</strong></td>
                    <td> ".$row['dateCom']."</td>

                    <td>"; 

                    $validation = $this->db->query(
                       "SELECT valideCom 
                        FROM commande_client 
                        WHERE codeCom = '".$row['codeCom']."' and valideCom= 'oui' limit 1"
                    )->row(); 
                    
                    if (count($validation) >0 ) {
                        echo"<td'><a type='button'  class=' btn btn-sm' onclick='printCommandeClient(\"".$row['codeCom']."\",\"".$getClient->nomClient."\",\"".$row['dateCom']."\",\"".$row['dateCrea']."\",\"".$row['codeClient']."\",\"".$row['adresseClient']."\",\"".$row['telClient']."\", \"".number_format($this->MontantCommandeClient($row['codeCom']),0,',',' ')." F\")'><i class='nav-icon fas fa-bell text-dark'></i></a></td>";
                    }echo"
                    
                    <td>";
                        if ($this->session->userdata('autoArticle_voir') == 'true') {
                            echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"voirCommandeClient('"  . $row['id_commandeClient'] . "','" . $row['codeCom'] . "','" . $row['id_client'] . "','" . $row['dateCrea'] . "','" . $row['dateCom'] . "','" . $row['id_article'] . "','" . $row['referenceCom'] . "','" . $row['prixVenteCom'] . "','" . $row['qtiteCom'] . "','" . $row['typeCom'] . "','" . $row['valideCom'] . "','" . $row['codeClient'] . "','" . $row['adresseClient'] . "','" . $row['telClient'] . "')\" class=' ml-1'><i class='nav-icon  fas fa-eye text-info'></i></a>";
                        }
                        if ($this->session->userdata('autoArticle_modification') == 'true') {
                            echo "<a type='button' onclick=\"modiCommandeClient('"  . $row['id_commandeClient'] . "','" . $row['codeCom'] . "','" . $row['id_client'] . "','" . $row['dateCrea'] . "','" . $row['dateCom'] . "','" . $row['valideCom'] . "','" . $row['codeClient'] . "','" . $row['adresseClient'] . "','" . $row['telClient'] . "')\" class=' ml-2'><i class='nav-icon	fas fa-pencil-alt text-success'></i></a>";
                        } 
                        if ($this->session->userdata('autoArticle_suppression') == 'true') {
                            echo "<a type='button' class='ml-2' data-toggle='modal' data-target='#supprimer' table='commande_client' identifiant='" . $row['id_commandeClient'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_commandeClient\");'><i class='far fas fa-trash text-danger'></i></a>
                    </td>  
                </tr>   ";}
                $i++;
            }
        }echo "
        <tr>
            <td style='border: 0px;'><b>Total</b></td> 
            <td style='border: 0px'></td>
            <td style='border: 0px'></td>
            <td style='border: 0px'></td>
            <td style='border: 0px'><b class='text-primary'>".number_format($cprixVenteCom,0,',',' ')."</b></td>
            <td style='border: 0px'><b class='text-dark'>".number_format($cqtite,0,',',' ')."</b></td> 
            <td style='border: 0px'><b class='text-danger'>".number_format($cmontantTotal,0,',',' ')."</b></td>
            <td style='border: 0px'>
            </td><td style='border: 0px'></td></td><td style='border: 0px'></td>
        </tr>";
        $this->db->close();
    }


    public function modifieDataCommandeClient(){

        $codeCom = $_POST["codeCom"];
        $Commande = $this->db->query(
           "SELECT * 
            FROM commande_client 
            WHERE codeCom = '".$codeCom."' ")->result_array();
        $i=1;

        foreach ($Commande as $mod) {
            
            echo 
            '<div class="row">

                    <div class="col-md-1">
                        <div class="form-group">
                            <label>N°</label>
                            <input type="text" style="border-radius:20px;"class="form-control nbr'.$i.'" placeholder="" value = "'.$i.'" disabled="true" >
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Article</label>
                            <select style="border-radius:20px;" class="id_article'.$i.' form-control" onchange="getMontantArticle($(\'.id_article'.$i.'\').val(),\'prixVenteCom'.$i.'\');getReferenceArticle($(\'.id_article'.$i.'\').val(),\'referenceCom'.$i.'\');">';
                                $getArticle = $this->db->query(
                                   "SELECT * 
                                    FROM article 
                                    WHERE id_article = ".$mod['id_article'].""
                                )->row(); echo"

                                <option value='".$mod['id_article']."'>".$getArticle->nomArticle."</option>";
                                $this->ModelArticle->ListeArticle();echo '
                            </select>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group ">
                            <label>Référence</label>
                            <input type="text" style="border-radius:20px;" class="form-control referenceCom'.$i.'" disabled = "true" value="'.addslashes($mod["referenceCom"]).' ">
                        </div>
                    </div>

                    <div class="col-md-2">
                        <label>Montant</label>
                        <input type="text" style="border-radius:20px;" class="form-control prixVenteCom'.$i.'" disabled = "true" placeholder=" " value="'.$mod["prixVenteCom"].'" onkeypress="chiffres(event);" >
                    </div>

                    <div class="col-md-1">
                        <label>Qtite</label>
                        <input type="text" style="border-radius:20px;" class="form-control qtiteCom'.$i.'" placeholder=" " value="'.$mod["qtiteCom"].'"  onkeypress="chiffres(event);">
                    </div> 
                    

                    <input type="hidden" class="form-control id_commandeClient'.$i.'"  placeholder=" en FCFA" value="'.$mod["id_commandeClient"].'" disabled="true" onkeypress="chiffres(event);">

                    <div class="col-md-1">
                        <div class="form-group">
                            <label>Fermer</label>
                            <select style="border-radius:20px;" class="typeCom'.$i.' form-control" onchange="activePrix(\'.typeCom'.$i.'\',\'.prixVenteCom'.$i.'\');">';
                                if ($mod['typeCom'] == 'oui') {
                                    echo '
                                    <option>oui</option>
                                    <option>non</option>';
                                }
                                else {
                                    echo '
                                    <option>non</option>
                                    <option>oui</option>';
                                }echo '
                            </select>
                        </div>
                    </div>
                </div>
                <hr>';
            $i++;
        }
        $i = $i-1;

        echo '<input type="hidden" class="form-control compteur"  placeholder=" en FCFA" value="'.$i.'" disabled="true" onkeypress="chiffres(event);">';

        $this->db->close();
    }

    
    public function MontantCommandeClient($codeCom){

        $requete = $this->db->query(
           'SELECT * 
            FROM commande_client 
            WHERE codeCom = "'.$codeCom.'"'
        )->result_array();

        $somme = 0;

        foreach ($requete as $row) {
            
            $total = $row["prixVenteCom"]*$row["qtiteCom"];
            $somme = $somme + $total;
        }
        return $somme;

        $this->db->close();
    }


    public function PrintCommandeClient(){

        $codeCom = $_POST["codeCom"]; $c= 0;
        $requete = $this->db->query(
           'SELECT * 
            FROM commande_client 
            WHERE codeCom ="'.$codeCom.'" 
            ORDER BY dateCom desc' 
        )->result_array();
        
        foreach ($requete as $row) { echo 
        
            "<tr style='border:none; text-align:center;font-size: 16px;padding:0px;'>

                <td colspan='1' style='border:none; text-align:center;padding:0px;' >".$row['codeCom']."</td>";

                $getArticle = $this->db->query(
                   "SELECT * 
                    FROM article 
                    WHERE id_article = ".$row['id_article'].""
                )->row(); echo"
                
                <td colspan='2' style='border: none; text-align:center;padding:0px;'>".$getArticle->nomArticle."</td>";  echo"
    
                <td colspan='2' style='border:none; text-align:center;padding:0px;'>".$row['referenceCom']."</td>

                <td style='border: none; text-align:center;padding:0px;'><strong class='text-danger'>".number_format($row['prixVenteCom'],0,',',' ')."</td>
                
                <td  style='border:none; text-align:center;padding:0px;'><strong class='text-dark'>".$row['qtiteCom']."</td>
            
                <td colspan='2' style='border:none; text-align:center;padding:0px;'><strong class='text-danger'>".number_format($row['prixVenteCom']*$row['qtiteCom'],0,',',' ')."</td>";
            
                 
            $c++;
        }

        $this->db->close();
    }


    public function dropCommandeClient($a, $b, $c){

        $Commande = $this->db->query(
           "SELECT * 
            FROM " . $a . " 
            WHERE " . $c . "=" . $b . ""
        )->row();

        if (count($Commande) > 0) {
        
            $table = $a; 

            $securiteS =" <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé la commande Client de N°  <strong class='text-info'> ' " . $Commande->codeCom . " ' </strong> du client :  <strong class='text-dark'> '" .$this->getClient($Commande->id_client).  "'  </strong>l'article :  <strong class='text-success'> '" .$this->getArticle($Commande->id_article).  "'  </strong>de montant :  <strong class='text-danger'> '" .$Commande->prixVenteCom.  "'  </strong>de quantite: <strong class='text-dark'>'" .$Commande->qtiteCom.  "'</strong> valide: <strong class='text-success'>'" .$Commande->valideCom. "'</strong>";

            $drop = $this->db->query(
               "DELETE 
                FROM " . $a . " 
                WHERE " . $c . "=" . $b . ""
            );

            if ($drop == true) {
                
                echo "Suppression effectuée";
                $this->notificationAjout($table, addslashes($securiteS));
            } 
            else {
                echo "probleme pendant  la suppression";
            }
        }
        $this->db->close();
    }


    public function nbreActifCommandeClient(){
        $query = $this->db->query(
           "SELECT COUNT(*) AS nbr 
            FROM commande_client 
            WHERE valideCom = 'oui'"
        )->row_array();
        echo $query['nbr'];
    }


    
    /* FACTURE CLIENT */


    public function modifieDataFacture(){

        $codeFact = $_POST["codeFact"];
        $Commande = $this->db->query(
           "SELECT * 
            FROM facture_client 
            WHERE codeFact = '".$codeFact."' "
        )->result_array();
        $i=1;

        foreach ($Commande as $mod) {
            
            echo 
            '<div class="row">

                    <div class="col-md-1">
                        <div class="form-group">
                            <label>N°</label>
                            <input type="text" style="border-radius:20px;"class="form-control nbr'.$i.'" placeholder="" value = "'.$i.'" disabled="true" >
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Article</label>
                            <select style="border-radius:20px;" class="id_article'.$i.' form-control" onchange="getMontantArticle($(\'.id_article'.$i.'\').val(),\'prixVenteCom'.$i.'\');getReferenceArticle($(\'.id_article'.$i.'\').val(),\'referenceCom'.$i.'\');">';
                                $getArticle = $this->db->query(
                                   "SELECT * 
                                    FROM article 
                                    WHERE id_article = ".$mod['id_article'].""
                                )->row(); echo"
                                <option value='".$mod['id_article']."'>".$getArticle->nomArticle."</option>";
                                $this->ModelArticle->ListeArticle();echo '
                            </select>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group ">
                            <label>Référence</label>
                            <input type="text" style="border-radius:20px;" class="form-control referenceCom'.$i.'" disabled = "true" value="'.addslashes($mod["referenceCom"]).' ">
                        </div>
                    </div>

                    <div class="col-md-2">
                        <label>Montant</label>
                        <input type="text" style="border-radius:20px;" class="form-control prixVenteCom'.$i.'" disabled = "true" placeholder=" " value="'.$mod["prixVenteCom"].'" onkeypress="chiffres(event);" >
                    </div>

                    <div class="col-md-1">
                        <label>Qtite</label>
                        <input type="text" style="border-radius:20px;" class="form-control qtiteCom'.$i.'" placeholder=" " value="'.$mod["qtiteCom"].'"  onkeypress="chiffres(event);">
                    </div> 
                    

                    <input type="hidden" class="form-control id_facture'.$i.'"  placeholder=" en FCFA" value="'.$mod["id_facture"].'" disabled="true" onkeypress="chiffres(event);">

                    <div class="col-md-1">
                        <div class="form-group">
                            <label>Fermer</label>
                            <select style="border-radius:20px;" class="typeCom'.$i.' form-control" onchange="activePrix(\'.typeCom'.$i.'\',\'.prixVenteCom'.$i.'\');">';
                                if ($mod['typeCom'] == 'oui') {
                                    echo '
                                    <option>oui</option>
                                    <option>non</option>';
                                }
                                else {
                                    echo '
                                    <option>non</option>
                                    <option>oui</option>';
                                }echo '
                            </select>
                        </div>
                    </div>
                </div>
                <hr>';
            $i++;
        }
        $i = $i-1;

        echo '<input type="hidden" class="form-control compteur"  placeholder=" en FCFA" value="'.$i.'" disabled="true" onkeypress="chiffres(event);">';

        $this->db->close();
    }


    public function dropFactureClient($a, $b, $c){

        $Commande = $this->db->query(
           "SELECT * 
            FROM " . $a . " 
            WHERE " . $c . "=" . $b . ""
        )->row();

        if (count($Commande) > 0) {
        
            $table = $a; 

            $securiteS =" <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé la facture de N°  <strong class='text-info'> ' " . $Commande->codeFact . " ' </strong> du client :  <strong class='text-dark'> '" .$this->getClient($Commande->id_client).  "'  </strong>l'article :  <strong class='text-success'> '" .$this->getArticle($Commande->id_article).  "'  </strong>de montant :  <strong class='text-danger'> '" .$Commande->prixVenteCom.  "'  </strong>de quantite: <strong class='text-dark'>'" .$Commande->qtiteCom.  "'</strong> valide: <strong class='text-success'>'" .$Commande->valideFact. "'</strong>";

            $drop = $this->db->query(
               "DELETE 
                FROM " . $a . " 
                WHERE " . $c . "=" . $b . ""
            );
            if ($drop == true) {
                
                echo "Suppression effectuée";
                $this->notificationAjout($table, addslashes($securiteS));
            } 
            else {
                echo "probleme pendant  la suppression";
            }
        }
        $this->db->close();
    }
}