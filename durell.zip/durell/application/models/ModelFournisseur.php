<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class ModelFournisseur extends CI_Model {


    function __construct() {

        parent::__construct(); $this->load->database('default');  $this->load->library('session'); $this->load->helper('cookie');
        $this->load->helper('url');
        
    }


    public function notificationAjout($table,$securite){

        $this->db->query(
            "INSERT 
            INTO notification 
            VALUE
            (
                '',
                '".php_uname('n')."',
                ".$this->session->userdata('id_profil').",
                '".$table."',
                '".$securite."',
                now(),now()
            )"
        );
        $this->db->close();
    }


    public function getUsername($id_profil){

        $query = $this->db->query(
            "SELECT * 
            FROM profil 
            WHERE id_profil=".$id_profil.""
        )->row();

        if (count($query)>0) {
            
            return $query->identifiant;
        }
        $this->db->close();
    }

    public function codeFournisseur(){ 

        $getCodeFournisseur = $this->db->query(
           "SELECT * 
            FROM fournisseur 
            ORDER BY id_fournisseur desc limit 1"
        )->row();

        $codeFour =0;

        if (count($getCodeFournisseur)>0) {
            $codeFour = $getCodeFournisseur->codeFour;
        }else{
            $codeFour = 0;
        }

        $codeFour++;

        while (strlen($codeFour)<5) {
            $codeFour = "0".$codeFour;
        }
        return "FOUR".filter_var($codeFour, FILTER_SANITIZE_NUMBER_INT);
    }

    
    public function setFournisseur($id){

        $query= $this->db->query(
            "SELECT * 
            FROM fournisseur 
            WHERE id_fournisseur = ".$id.""
        )->row();

        if (count($query)>0) {
            
            return $query->nomFour;
        }
        $this->db->close();
    }








    /* FOURNISSEUR */

    public function ajoutFournisseur(){

        $choix = $_POST["choix"];    $codeFour = $this->codeFournisseur(); $dateFour = $_POST["dateFour"];

        $nomFour = $_POST["nomFour"];  $adresseFour = $_POST["adresseFour"];

        $telFour = $_POST["telFour"];   $soldeFour = preg_replace('/\s/', '', $_POST["soldeFour"]);

        $commentaireFour = $_POST['commentaireFour'];    $actifFour = $_POST["actifFour"];   $table = "fournisseur";

        $securiteA = "<strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a ajouté le fournisseur <strong class='text-info'> '" . $nomFour . "' </strong> de solde :  <strong class='text-danger'> '" . $soldeFour . "' </strong> de Actif :  <strong class='text-success'> '" . $actifFour . "'</strong>";

        $securiteM = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a modifié le fournisseur  <strong class='text-info'> '" . $nomFour . "' </strong> de solde :  <strong class='text-danger'> '" . $soldeFour . "' </strong> de Actif :  <strong class='text-success'> '" . $actifFour . "'</strong>";

        if ($choix == "ajouter") {
            
            $requeteTelFour = $this->db->query(
               "SELECT * 
                FROM fournisseur 
                WHERE telFour ='" . $telFour . "' "
            )->result_array();

            $requeteNomFour = $this->db->query(
               "SELECT * 
                FROM fournisseur 
                WHERE nomFour ='" . $nomFour . "' "
            )->result_array();

            if (count($requeteTelFour) > 0) {

                echo "Ce contact '" . $telFour . "' apparaît déjà ";
            }
            elseif (count($requeteNomFour) > 0) {

                echo "Ce Fournisseur '" . $nomFour . "' apparaît déjà ";
            }
            else {
                $query1 = $this->db->query(
                   "INSERT 
                    INTO fournisseur 
                    VALUE
                    (
                        '',
                        '".$codeFour."',
                        CAST('" . $dateFour . "' AS DATE),
                        '" . $nomFour . "',
                        '" . $adresseFour . "',
                        " . $telFour . ",
                        " . $soldeFour . ",
                        '" . $commentaireFour . "',
                        '".$actifFour."'
                    ) "
                );
                
                if ($query1 == true) {
                    echo "Insertion éffectuée";
                    $this->notificationAjout($table, addslashes($securiteA));
                } 
                else {
                    echo "Erreur durant l'insertion";
                }
            }
        } 
        elseif ($choix == "modifier") {
         
                $id_table  = $_POST["id_table"];
            
            $requete = $this->db->query(
               "SELECT * 
                FROM fournisseur 
                WHERE  nomFour ='" . $nomFour . "' "
            )->result_array();

            if (count($requete) > 0) {

                foreach ($requete as $row) {

                    if ($row["id_fournisseur"] == $id_table) {
                
                        $query1 = $this->db->query(
                           "UPDATE fournisseur 
                            SET 
                                telFour ='" . $telFour . "', 
                                adresseFour ='" . $adresseFour . "', 
                                nomFour ='" . $nomFour . "',
                                soldeFour = '" . $soldeFour . "', 
                                commentaireFour = '" . $commentaireFour . "', 
                                dateFour = CAST('" . $dateFour . "' AS DATE) ,
                                actifFour='".$actifFour."' 
                                
                            WHERE id_fournisseur =" . $id_table  . ""
                        );

                        if ($query1 == true) {
                            echo "Modification éffectuée";
                            $this->notificationAjout($table, addslashes($securiteM));
                        } 
                        else {
                            echo "Problème pendant la Modification";
                        }
                    } 
                    else {
                        echo "Ce fournisseur \"" . $nomFour . "\" apparaît déjà ";
                    }
                }
            } 
            else {
               $query1 = $this->db->query(
                   "UPDATE fournisseur 
                    SET 
                        telFour='" . $telFour . "', 
                        adresseFour ='" . $adresseFour . "', 
                        nomFour ='" . $nomFour . "', 
                        commentaireFour = '" . $commentaireFour . "' ,
                        soldeFour = '" . $soldeFour . "', 
                        dateFour = CAST('" . $dateFour . "' AS DATE) ,
                        actifFour='".$actifFour."'
                        
                    WHERE id_fournisseur  =" . $id_table  . ""
                );
                        
                if ($query1 == true) {
                    echo "Modification éffectuée";
                    $this->notificationAjout($table, addslashes($securiteM));
                } 
                else {
                    echo "Problème pendant la Modification";
                }
            }
        } 
        else {
            echo "problème se trouvant dans l'ajoutFournisseur";
        }
        $this->db->close();
    }


    public function afficheDataFournisseur(){

        $query1 = $this->db->query(
           "SELECT * 
            FROM fournisseur 
            ORDER BY nomFour ASC"
        )->result_array();

        $compteur = 0;

        foreach ($query1 as $row) {
        
            echo 
            "<tr>
                <td onclick=\"new();\">" . $compteur . "</td>
                <td>" . $row['codeFour'] . "</td>
                <td>" . $row['nomFour'] . "</td>
                <td>" . $row['adresseFour'] . "</td>
                <td> " . $row['telFour'] . "</td>
                <td> <strong class='text-danger'>".number_format($row['soldeFour'],0,',',' ')."</strong></td>
                <td> " . $row['dateFour'] . "</td>";

                if ($row['actifFour'] == 'OUI') {
                    echo"<td class='text-success'><strong><i class='nav-icon fas fa-user-check'></i></strong></td>";
                }
                if ($row['actifFour'] == 'NON') {
                    echo"<td class='text-danger'><strong><i class='nav-icon fas fa-user-times'></i></strong></td>";
                }echo"
                <td>";
                    if ($this->session->userdata('autoFournisseur_voir') == 'true') {
                        echo "<a type='button'  data-toggle='modal' data-target='#voir' onclick=\"VoirFournisseur('" . $row['id_fournisseur'] . "','" . $row['codeFour'] . "','" . $row['nomFour'] . "','" . $row['adresseFour'] . "','" . $row['telFour'] . "','" . $row['soldeFour'] . "','" . addslashes($row['commentaireFour']) . "','" . $row['dateFour']  . "','".$row['actifFour']."')\" class=' ml-2 '><i class='nav-icon fas fa-eye text-info'></i></a>";
                    }

                    if ($this->session->userdata('autoFournisseur_modification') == 'true') {
                        echo "<a  type='button' onclick=\"modiFournisseur('" . $row['id_fournisseur'] . "','" . $row['codeFour'] . "','" . $row['nomFour'] . "','" . $row['adresseFour'] . "','" . $row['telFour'] . "','" . $row['soldeFour'] . "','" . addslashes($row['commentaireFour']) . "','" . $row['dateFour'] . "','".$row['actifFour']."')\" class=' ml-2'><i class='nav-icon 	fas fa-pen text-success'></i></a>";
                    }

                    if ($this->session->userdata('autoFournisseur_suppression') == 'true') {
                        echo "<a  type='button' class='ml-2' data-toggle='modal' data-target='#supprimer' table='fournisseur' identifiant='" . $row['id_fournisseur'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_fournisseur\");'><i class='far fas fa-trash text-danger'></i></a>
                </td>
            </tr>"; }
            $compteur++;
        }
        $this->db->close();
    }


    public function dropFournisseur($a, $b, $c){

        $Fournisseur = $this->db->query(
            "SELECT * 
            FROM " . $a . " 
            WHERE " . $c . "=" . $b . ""
        )->row();

        if (count($Fournisseur) > 0) {
        
            $table = $a;

            $securiteS = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé le fournisseur <strong class='text-info'> '" . $Fournisseur->nomFour . "' </strong> de solde :  <strong class='text-danger'> '" . $Fournisseur->soldeFour . "'  </strong>";


            $drop = $this->db->query(
               "DELETE 
                FROM " . $a . " 
                WHERE " . $c . "=" . $b . ""
            );
            if ($drop == true) {
                
                echo "Suppression effectuée";
                $this->notificationAjout($table, addslashes($securiteS));
            } else {
                echo "Pas supprimé";
            }
        }


        $this->db->close();
    }


    public function ListeFournisseur(){

        $query = $this->db->query(
           "SELECT * 
            FROM fournisseur 
            WHERE actifFour = 'OUI' 
            ORDER BY nomFour ASC"
        )->result_array();
        if (count($query) >0) {
            
            foreach ($query as $row) {
                
                echo "<option value='".$row["id_fournisseur"]."'>".$row["nomFour"]."</option>";
            }
        }else{
            echo "<option disabled>Aucun fournisseur actif trouvé</option>";
        }

        $this->db->close();
    }

    
    public function nbreActifFournisseur(){

        $query = $this->db->query(
           "SELECT COUNT(*) AS nombre_fournisseur 
            FROM fournisseur 
            WHERE actifFour = 'OUI'"
        )->row_array();

        echo $query['nombre_fournisseur'];
    }


    public function nbreNonActifFournisseur(){

        $query = $this->db->query(
           "SELECT COUNT(*) AS nombre_fournisseur 
            FROM fournisseur 
            WHERE actifFour = 'NON'"
        )->row_array();

        echo $query['nombre_fournisseur'];
    }
    

    /* FACTURE */

    public function ajoutFacture(){

        $choix = $_POST["choix"];  

        $id_fournisseur = $_POST["id_fournisseur"];  $dateFact = $_POST["dateFact"];

        $numeroFact = $_POST["numeroFact"];   $montantFact = preg_replace('/\s/', '', $_POST["montantFact"]);

        $commentaireFact = $_POST['commentaireFact'];    $payeFact = $_POST["payeFact"];   $table = "facture_article";

        $securiteA = "<strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a ajouté la facture <strong class='text-info'> '" . $numeroFact . "' </strong> de fournisseur :  <strong class='text-primary'> '" .$this->setFournisseur($id_fournisseur). "' </strong> de montant :  <strong class='text-danger'> '" . $montantFact . "' </strong> payé :  <strong class='text-success'> '" . $payeFact . "'</strong>";

        $securiteM = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a modifié la facture <strong class='text-info'> '" . $numeroFact . "' </strong> de fournisseur :  <strong class='text-primary'> '" .$this->setFournisseur($id_fournisseur). "' </strong> de montant :  <strong class='text-danger'> '" . $montantFact . "' </strong>payé :  <strong class='text-success'> '" . $payeFact . "'</strong>";

        if ($choix == "ajouter") {
            
            $requeteTelClient = $this->db->query(
               "SELECT * 
                FROM facture_article 
                WHERE numeroFact ='" . $numeroFact . "' "
            )->result_array();

            if (count($requeteTelClient) > 0) {

                echo "Cette facture '" . $numeroFact . "' apparaît déjà ";
            }
            else {
                $query1 = $this->db->query(
                   "INSERT 
                    INTO facture_article 
                    VALUE
                    (
                        '',
                        '".$id_fournisseur."',
                        CAST('" . $dateFact . "' AS DATE),
                        '" . $numeroFact . "',
                        " . $montantFact . ",
                        '" . $payeFact . "',
                        '".$commentaireFact."'
                    ) "
                );
                
                if ($query1 == true) {
                    echo "Insertion éffectuée";
                    $this->notificationAjout($table, addslashes($securiteA));
                } 
                else {
                    echo "Erreur durant l'insertion";
                }
            }
        } 
        elseif ($choix == "modifier") {
        
            $id_table  = $_POST["id_table"];
            
            $requete = $this->db->query(
               "SELECT * 
                FROM facture_article 
                WHERE  numeroFact ='" . $numeroFact . "' "
            )->result_array();

            if (count($requete) > 0) {

                foreach ($requete as $row) {

                    if ($row["id_factureArt"] == $id_table ) {
                
                        $query1 = $this->db->query(
                           "UPDATE facture_article 
                            SET 
                                numeroFact ='" . $numeroFact . "', 
                                dateFact = CAST('" . $dateFact . "' AS DATE), 
                                id_fournisseur ='" . $id_fournisseur . "',
                                montantFact = '" . $montantFact . "', 
                                commentaireFact = '" . $commentaireFact . "',
                                payeFact='".$payeFact."' 
                                
                            where id_factureArt  =" . $id_table  . ""
                        );
                        if ($query1 == true) {
                            echo "Modification éffectuée";
                            $this->notificationAjout($table, addslashes($securiteM));
                        } 
                        else {
                            echo "Problème pendant la Modification";
                        }
                    } 
                    else {
                        echo "Cette facture \"" . $numeroFact . "\" apparaît déjà ";
                    }
                }
            } 
            else {
                $query1 = $this->db->query(
                   "UPDATE facture_article 
                    SET 
                        numeroFact ='" . $numeroFact . "', 
                        dateFact = CAST('" . $dateFact . "' AS DATE), 
                        id_fournisseur ='" . $id_fournisseur . "',
                        montantFact = '" . $montantFact . "', 
                        commentaireFact = '" . $commentaireFact . "',
                        payeFact='".$payeFact."' 
                        
                    where id_factureArt  =" . $id_table  . ""
                );
                
                if ($query1 == true) {
                    echo "Modification éffectuée";
                    $this->notificationAjout($table, addslashes($securiteM));
                } 
                else {
                    echo "Problème pendant la Modification";
                }
            }
        } 
        else {
            echo "problème se trouvant dans l'ajoutClient";
        }
        $this->db->close();
    }
   
    public function afficheDataFacture(){

        $sql = $this->db->query(
           "SELECT * 
            FROM facture_article 
            ORDER BY id_factureArt DESC"
        )->result_array();

        $c = 0;
        foreach ($sql as $row) {

            $Fournisseur = $this->db->query(
               "SELECT * 
                FROM fournisseur 
                WHERE id_fournisseur=".$row['id_fournisseur'].""
            )->row(); 
            echo 
            "<tr>
                <td onclick=\"new();\">" . $c . "</td>
                <td>" .$Fournisseur->nomFour. "</td>
                <td>" . $row['dateFact'] . "</td>
                <td> " . $row['numeroFact'] . "</td>
                <td> <strong class='text-danger'>".number_format($row['montantFact'],0,',',' ')."</strong></td>
                <td> " . $row['commentaireFact'] . "</td>";

                if ($row['payeFact'] == 'OUI') {
                    echo"<td class='text-success'><strong><i class='nav-icon fas fa-check-circle'></i></strong></td>";
                }
                if ($row['payeFact'] == 'NON') {
                    echo"<td class='text-danger'><strong><i class='nav-icon fas fa-times-circle'></i></strong></td>";
                }echo"
                <td>";
                    if ($this->session->userdata('autoFournisseur_voir') == 'true') {
                        echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"VoirFacture('" . $row['id_factureArt'] . "','" . $row['id_fournisseur'] . "','" . $row['dateFact'] . "','" . $row['numeroFact'] . "','" . $row['montantFact'] . "','" . $row['commentaireFact'] . "','".$row['payeFact']."')\" class=' ml-2'><i class='nav-icon fas fa-eye text-info'></i></a>";
                    }

                    if ($this->session->userdata('autoFournisseur_modification') == 'true') {
                        echo "<a type='button' onclick=\"modiFacture('" . $row['id_factureArt'] . "','" . $row['id_fournisseur'] . "','" . $row['dateFact'] . "','" . $row['numeroFact'] . "','" . $row['montantFact'] . "','" . $row['commentaireFact'] . "','".$row['payeFact']."')\" class=' ml-2 '><i class='nav-icon 	fas fa-pen text-success'></i></a>";
                    }

                    if ($this->session->userdata('autoFournisseur_suppression') == 'true') {
                        echo "<a class='ml-2'type='button' data-toggle='modal' data-target='#supprimer' table='facture_article' identifiant='" . $row['id_factureArt'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_factureArt\");'><i class='far fas fa-trash text-danger'></i></a>
                </td>
            </tr>"; }
            $c++;
        }
        $this->db->close();
    }


    public function dropFacture($a, $b, $c){

        $Facture = $this->db->query(

           "SELECT * 
            FROM " . $a . " 
            WHERE " . $c . "=" . $b . ""
            
        )->row();

        if (count($Facture) > 0) {
        
            $table = $a;
            $securiteS = "<strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé la facture <strong class='text-info'> '" . $Facture->numeroFact . "' </strong> de fournisseur :  <strong class='text-primary'> '" .$this->setFournisseur($Facture->id_fournisseur).  "'  </strong> de montant :  <strong class='text-danger'> '" . $Facture->montantFact . "'  </strong>";
            
            $drop = $this->db->query(

               "DELETE 
                FROM " . $a . " 
                WHERE " . $c . "=" . $b . ""
            );

            if ($drop == true) {
                
                echo "Suppression effectuée";
                $this->notificationAjout($table, addslashes($securiteS));
            } else {
                echo "Pas supprimé";
            }
        }


        $this->db->close();
    }


    public function nbreActifFacture(){

        $query = $this->db->query(

            "SELECT COUNT(DISTINCT codeCom) AS nbre
            FROM facture_article 
            WHERE payeFact = 'OUI'"

        )->row_array();

        echo $query['nbre'];
    }


    public function nbreNonActifFacture(){

        $query = $this->db->query(

            "SELECT COUNT(DISTINCT codeCom) AS nbre 
            FROM facture_article 
            WHERE payeFact = 'NON'"
            
        )->row_array();

        echo $query['nbre'];
    }



    public function fournisseurPlusUtilise(){

        $query = $this->db->query(

            "SELECT f.id_fournisseur, f.nomFour, COUNT(fa.id_fournisseur) AS nb_factures
            FROM fournisseur f
            JOIN facture_article fa ON f.id_fournisseur = fa.id_fournisseur
            GROUP BY f.id_fournisseur, f.nomFour
            ORDER BY nb_factures DESC"

        )->row_array(); 

        if (!empty($query)) {

            echo $query['nomFour'];
        } else {

            echo "Aucun fournisseur trouvé.";
        }
    }


    public function nbrFournisseurPlusUtilise(){

        $query = $this->db->query(

            "SELECT f.id_fournisseur, f.nomFour, COUNT(fa.id_fournisseur) AS nb_factures
            FROM fournisseur f
            JOIN facture_article fa ON f.id_fournisseur = fa.id_fournisseur
            GROUP BY f.id_fournisseur, f.nomFour
            ORDER BY nb_factures DESC"

        )->row_array(); 

        if (!empty($query)) {

            echo $query['nb_factures'];
        } else {

            echo "Aucune.";
        }
        
    }


    public function fournisseurMoinsUtilise(){

        $query = $this->db->query(

            "SELECT f.id_fournisseur, f.nomFour, COUNT(fa.id_fournisseur) AS nb_factures
            FROM fournisseur f
            JOIN facture_article fa ON f.id_fournisseur = fa.id_fournisseur
            GROUP BY f.id_fournisseur, f.nomFour
            ORDER BY nb_factures ASC"

        )->row_array(); 

        if (!empty($query)) {

            echo $query['nomFour'];
        } else {

            echo "Aucun fournisseur trouvé.";
        }
    }


    public function nbrFournisseurMoinsUtilise(){

        $query = $this->db->query(

           "SELECT f.id_fournisseur, f.nomFour, COUNT(fa.id_fournisseur) AS nb_factures
            FROM fournisseur f
            JOIN facture_article fa ON f.id_fournisseur = fa.id_fournisseur
            GROUP BY f.id_fournisseur, f.nomFour
            ORDER BY nb_factures ASC"

        )->row_array(); 

        if (!empty($query)) {

            echo $query['nb_factures'];
        } else {

            echo "Aucune";
        }

    }


    public function fournisseurMilieu(){

        $query = $this->db->query(

           "SELECT f.id_fournisseur, f.nomFour, COUNT(fa.id_fournisseur) AS nb_factures
            FROM fournisseur f
            JOIN facture_article fa ON f.id_fournisseur = fa.id_fournisseur
            GROUP BY f.id_fournisseur, f.nomFour
            ORDER BY nb_factures ASC" 

        )->result_array(); 

        if (!empty($query)) {
            $count = count($query);
            $middleIndex = floor($count / 2); 

            $clientMilieu = $query[$middleIndex];

            echo $clientMilieu['nomFour'];
        } else {
            echo "Aucune fournisseur trouvé.";
        }
    }


    public function nbrFournisseurMilieu(){

        $query = $this->db->query(

           "SELECT f.id_fournisseur, f.nomFour, COUNT(fa.id_fournisseur) AS nb_factures
            FROM fournisseur f
            JOIN facture_article fa ON f.id_fournisseur = fa.id_fournisseur
            GROUP BY f.id_fournisseur, f.nomFour
            ORDER BY nb_factures ASC" 

        )->result_array(); 

        if (!empty($query)) {
            $count = count($query);
            $middleIndex = floor($count / 2); 

            $clientMilieu = $query[$middleIndex];

            echo $clientMilieu['nb_factures'];
        } else {
            echo "Aucune.";
        }
    }



    
    

}