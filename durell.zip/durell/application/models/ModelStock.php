<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class ModelStock extends CI_Model {
// 
    function __construct() {
        parent::__construct();
        $this->load->database('default');
        $this->load->library('session');
        $this->load->helper('cookie');
        $this->load->helper('url');
        
    }

    public function notificationAjout($table,$securite){

        $this->db->query(
            "INSERT 
            INTO notification 
            VALUE
            (
                '',
                '".php_uname('n')."',
                ".$this->session->userdata('id_profil').",
                '".$table."',
                '".$securite."',
                now(),now()
            )"
        );
        $this->db->close();
    }


    public function getUsername($id_profil){

        $query = $this->db->query(
           "SELECT * 
            FROM profil 
            WHERE id_profil=".$id_profil.""
        )->row();

        if (count($query)>0) {
            
            return $query->identifiant;
        }
        $this->db->close();
    }


    public function getArticle($id){
        $requete= $this->db->query(
            "SELECT * 
            FROM article 
            WHERE id_article = ".$id.""
        )->row();

        if (count($requete)>0) {
            
            return $requete->nomArticle;
        }
        $this->db->close();
    }


    public function getFournisseur($id){
        $requete= $this->db->query(
           "SELECT * 
            FROM fournisseur 
            WHERE id_fournisseur = ".$id.""
        )->row();

        if (count($requete)>0) {
            
            return $requete->nomFour;
        }
        $this->db->close();
    }

     
    public function ListeArticle(){
        $requete = $this->db->query(
           "SELECT  * 
            FROM article 
            ORDER BY nomArticle ASC"
        )->result_array();
        if (count($requete) >0) {
            
            foreach ($requete as $row) {
                
                echo "<option value='".$row["id_article"]."'>".$row["nomArticle"]."</option>";
            }
        }else{

        }

        $this->db->close();
    }

 
    public function ReferenceArticleM(){
    
	    $id_article = $_POST["id_article"];
    
        $Article = $this->db->query(
           "SELECT * 
            FROM article 
            WHERE id_article = ".$id_article." "
        )->row();

        echo $Article->referenceArticle;

        $this->db->close();
    }


    public function MontantArticleM(){
    
	    $id_article = $_POST["id_article"];
    
        $Article = $this->db->query(
           "SELECT * 
            FROM article 
            WHERE id_article = ".$id_article." "
        )->row();

        echo $Article->montantArticle;

        $this->db->close();
    }


    public function prixDeVente(){
    
	    $id_article = $_POST["id_article"];
    
        $Article = $this->db->query(
           "SELECT * 
            FROM article 
            WHERE id_article = ".$id_article." "
        )->row();

        echo $Article->prixVente;

        $this->db->close();
    }
    

    /* INVENTAIRE */ 

    public function MontantArticle(){
    
        $id_article = $_POST["id_article"];
        

        if (empty($id_article)) {
            
            echo "0";
        }else{
            $Article = $this->db->query(
               "SELECT * 
                FROM article 
                WHERE id_article = ".$id_article." "
            )->row();

            echo $Article->montantArticle;
        }

        $this->db->close();
    }

    public function ReferenceArticle(){

        $id_article = $_POST["id_article"];

        $Article = $this->db->query(
           "SELECT * 
            FROM article 
            WHERE id_article = ".$id_article.""
        )->row();

        if(count($Article)>0){
            echo $Article->referenceArticle;
        }else{
         echo "Pas de reference";
        }
        
        $this->db->close();
    } 


    public function DernierInventaire(){
        
       $requete = $this->db->query(
            "SELECT * 
            FROM inventaire 
            ORDER BY dateInv DESC LIMIT 1"
        )->row();
       
      
       if (count($requete)>0) {
           
         return $requete->dateInv;
       }

       $this->db->close();
    }


    public function tableInventaire(){

        $Article = $this->db->query(
           "SELECT * 
            FROM article 
            ORDER BY nomArticle ASC"
        )->result_array();

        echo'
            <tr class="formInv">
                <td>
                    <select style="border-radius:20px;" class="id_article form-control" onchange="MontantArticle($(\'.id_article\').val(),\'prixInv\');ReferenceArticle($(\'.id_article\').val(),\'referenceInv\'); ">
                        <option></option>';
                        if (count($Article)>0) {
                            
                            foreach ($Article as $row) {
                                
                                echo"
                                <option value = '".$row['id_article']."' nomArticle='".$row['article']."'>".$row['nomArticle']."</option>";
                            }
                        }echo' 
                    </select>
                </td>

                <td>
                    <input type="text" style="border-radius:20px;" placeholder ="reference" class="form-control referenceInv" disabled="true" >
                </td>
                                  
                <td>
                    <input type="text" style="border-radius:20px;" placeholder ="Montant" class="form-control prixInv"disabled="true" onkeypress="chiffres(event);">
                </td>
                                  
                <td>
                    <div>
                        <input type="text" style="border-radius:20px;" class="form-control qtiteInv"placeholder ="qtite" onkeypress="chiffres(event);">
                    </div>
                </td>

                <td>
                    <div class="input-group input-group-sm">
                       
                        <span class="input-group-append">'; 
                            if($this->session->userdata('autoStock_ajout') == "true") {
                                echo '<button type="button" class="btn btn-dark buttonA" onclick="ajoutInventaire();">Ajouter <i class="nav-icon fas fa-plus-circle"></i></button>';
                            }echo'
                        </span>
                    </div>
                </td>
            </tr>';

        $this->db->close();
    }


    public function ajoutInventaire(){

        $dateInv = $_POST["dateInv"];                        $auteurInv = $_POST["auteurInv"];
        $id_fournisseur = $_POST["id_fournisseur"];          $id_article = $_POST["id_article"];
		$referenceInv = $_POST["referenceInv"];              $prixInv = $_POST["prixInv"];
		$qtiteInv = $_POST["qtiteInv"];                     $dateL = date("Y/m/d"); $dateE = date("Y/m/d"); $table = "inventaire"; 

        $securiteA =" <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong> a ajouté un inventaire sur l'article  <strong class='text-primary'>' " .$this->getArticle($id_article). " '</strong>  de prix <strong class='text-danger'>' " . $prixInv ." '  </strong> et de quantité <strong class='text-success'>' " . $qtiteInv ." '  </strong>";

        
        $Article = $this->db->query(
            "SELECT * 
            FROM inventaire 
            ORDER BY id_inventaire DESC LIMIT 1"
        )->row();

        if (count($Article)>0) {
            
            $dateL = date("Y/m/d",strtotime($Article->dateInv)); $dateE = date("Y/m/d",strtotime($dateInv));
        }

        if ($dateE < $dateL) {
           
            echo "La date  doit être supérieure   à celle de l'inventaire"; 
        }else{
            $ajoutInventaire = $this->db->query(
                "INSERT 
                INTO inventaire 
                VALUE
                    (
                        '',
                        CAST('". $dateInv."' AS DATE),
                        '".$auteurInv."',
                        ".$id_fournisseur.",
                        ".$id_article.",
                        '".$referenceInv."',
                        ".$prixInv.",
                        ".$qtiteInv."
                    )"
                );

            if ($ajoutInventaire == true) {
                
                echo "Insertion éffectuée";
                $this->notificationAjout($table,addslashes($securiteA));
            }else{
                echo "Probleme de connexion";
            }
        }
        $this->db->close();
    }


    
    public function afficheDataInventaire(){
		  
        if (isset($_POST["dateDebut"]) && isset($_POST["dateFin"]) && isset($_POST["id_nom"])) {
            
            $dateDebut = $_POST['dateDebut'];  $dateFin = $_POST['dateFin']; $id_nom = $_POST['id_nom'];
            
		    if (!empty($dateFin) && !empty($dateDebut) && isset($_POST["id_nom"])) {

                $requete = $this->db->query(
                   "SELECT  * 
                    FROM inventaire 
                    WHERE  id_fournisseur = '".$id_nom."' and dateInv between '".$dateDebut."' and '".$dateFin."'  
                    ORDER BY dateInv DESC"
                )->result_array();

                if ($id_nom == 'ALL') {
                    
                    $requete = $this->db->query(
                       "SELECT  * 
                        FROM inventaire 
                        WHERE  dateInv BETWEEN '".$dateDebut."' and '".$dateFin."'  
                        ORDER BY dateInv DESC"
                    )->result_array();
                
                }else {
                    
                    $requete = $this->db->query(
                       "SELECT  * 
                        FROM inventaire 
                        WHERE id_fournisseur = '".$id_nom."' and  dateInv BETWEEN '".$dateDebut."' and '".$dateFin."' 
                        ORDER BY dateInv DESC "
                    )->result_array();
                    
                }	
            
            }else{
                
                $requete = $this->db->query(
                   "SELECT  * 
                    FROM inventaire  
                    ORDER BY id_inventaire DESC"
                )->result_array();    
            }		
            
        }else{ 
            $requete = $this->db->query(
               "SELECT * 
                FROM inventaire ORDER BY id_inventaire DESC"
            )->result_array();
        }
        

        if (count($requete) >0 ) {
            
            $c = 0;
            foreach ($requete as $row) {
                
                $getNomArticle = $this->db->query(
                   "SELECT * 
                    FROM article 
                    WHERE id_article =".$row['id_article'].""
                )->row();

                $getFournisseur = $this->db->query(
                   "SELECT * 
                    FROM fournisseur 
                    WHERE id_fournisseur=".$row['id_fournisseur'].""
                )->row();

                echo"
                    <tr>
                        <td onclick=\"new();\">".$c."</td>";echo"
                        <td>".$getFournisseur->nomFour."</td>
                        <td>".$getNomArticle->nomArticle."</td>
                        <td>".$row['referenceInv']."</td>
                        <td> <strong class='text-danger'>".number_format($row['prixInv'],0,',',' ')."</strong></td>
                        <td> <strong class='text-dark'>".number_format($row['qtiteInv'],0,',',' ')."</strong></td>
                        <td> ".$row['dateInv']."</td>
                        <td>";

                            if ($this->session->userdata('autoArticle_voir') == 'true') {
                                echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"VoirInventaire('". $row['id_inventaire'] . "','" . $row['dateInv'] . "','" . $row['auteurInv'] . "','" . $row['id_fournisseur'] . "','" . $row['id_article'] . "','" . $row['referenceInv'] . "','" . $row['prixInv'] . "','" . $row['qtiteInv'] . "')\" class=' ml-1'><i class='nav-icon  fas fa-eye text-info'></i></a>";
                            }

                            if ($this->session->userdata('autoStock_modification') == 'true') {
                                echo "<a type='button' onclick=\"ModiInventaire('". $row['id_inventaire'] . "','" . $row['dateInv'] . "','" . $row['auteurInv'] . "','" . $row['id_fournisseur'] . "','" . $row['id_article'] . "','" . $row['referenceInv'] . "','" . $row['prixInv'] . "','" . $row['qtiteInv'] . "')\" class=' ml-2'><i class='nav-icon  fas fa-pencil-alt text-success'></i></a>";
                            }
                            if($this->session->userdata('autoStock_suppression')=='true'){
                                echo"<a type='button' class='ml-2' data-toggle='modal' data-target='#supprimer' table='inventaire' identifiant='" . $row['id_inventaire'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_inventaire\");'><i class='far  fas fa-trash text-danger'></i></a>
                        </td>
                    </tr>"; }
                  $c++;
            }
        }

        $this->db->close();
    }

 
    public function modiInventaire(){

        $choix = $_POST["choix"];                             $dateInv = $_POST["dateInvM"];
        $auteurInv = $_POST["auteurInvM"];                    $id_fournisseur = $_POST["id_fournisseurM"];
        $id_article = $_POST["id_articleM"];                  $prixInv = $_POST["prixInvM"];
		$qtiteInv = $_POST["qtiteInvM"];                      $table = "inventaire"; 
		$referenceInv = $_POST["referenceInvM"];
        

        $securiteM =  " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a modifié l'inventaire l'article  <strong class='text-primary'>' " .$this->getArticle($id_article). " '</strong> de prix <strong class='text-danger'>' " . $prixInv ." '  </strong>et de quantité <strong class='text-success'>' " . $qtiteInv ." '  </strong>";

        if ($choix == "update") {
            
            $id_modi = $_POST["id_modi"];

            $requete = $this->db->query(
               "SELECT * 
                FROM inventaire 
                WHERE id_fournisseur ='". $id_fournisseur ."'  "
            )->result_array();

            if (count($requete) > 0) {
                
                foreach ($requete as $row) {
                    
                    if ($row["id_inventaire"] == $id_modi) {

                        
                        $query1 = $this->db->query(
                           "UPDATE inventaire 
                            SET 
                                dateInv = CAST('". $dateInv."' AS DATE), 
                                auteurInv ='" . $auteurInv . "', 
                                id_fournisseur =" . $id_fournisseur . ",
                                id_article = " . $id_article . " , 
                                referenceInv ='" . $referenceInv . "', 
                                prixInv =" . $prixInv . ", 
                                qtiteInv =" . $qtiteInv . " 
                                
                            where id_inventaire =" . $id_modi . " "
                        );
                       
                        if ($query1 == true) {

                            echo "Modification éffectuée";

                            $this->notificationAjout($table, addslashes($securiteM));

                        } else {
                            echo "Erreur durant l'insertion";
                        }
                    } 
                }
            } else {
                $query1 = $this->db->query(
                   "UPDATE inventaire 
                    SET  
                        dateInv =CAST('". $dateInv."' AS DATE), 
                        auteurInv ='" . $auteurInv . "', 
                        id_fournisseur =" . $id_fournisseur . ",
                        id_article = " . $id_article . " , 
                        referenceInv ='" . $referenceInv . "', 
                        prixInv =" . $prixInv . ", 
                        qtiteInv =" . $qtiteInv . " 
                        
                    where id_inventaire =" . $id_modi . " "
                );
                
                if ($query1 == true) {

                    echo "Modification éffectuée";

                    $this->notificationAjout($table, addslashes($securiteM));
                } else {
                    echo "Erreur durant l'insertion";
                }
            }
        } else {
            echo "Erreur contactez l'administrateur";
        }

        $this->db->close();
    }

    
    public function dropInventaire($a, $b, $c){

        $getArticle = $this->db->query(
           "SELECT * 
            FROM " . $a . " 
            WHERE " . $c . "=" . $b . ""
        )->row();

        if (count($getArticle) > 0) {
        
            $table = $a; 
            
            $securiteS = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé l' Article <strong class='text-primary'> ' " .$this->getArticle($getArticle->id_article). " ' </strong> dans l'inventaire de prix <strong class='text-danger'> ' " . $getArticle->prixInv . " ' </strong> et quantité <strong class='text-success'> '" . $getArticle->qtiteInv . "'  </strong>";


            $drop = $this->db->query(
               "DELETE 
                FROM " . $a . " 
                WHERE " . $c . "=" . $b . ""
            );
            if ($drop == true) {
                
                echo "Suppression  effectuée";
                $this->notificationAjout($table, addslashes($securiteS));
            } 
            else {
                echo "Pas supprimé";
            }
        }
        $this->db->close();
    }




    /* APPROVISIONNEMENT */

    public function tableApprovisionnement(){

        $getArticle = $this->db->query(
           "SELECT * 
            FROM article 
            ORDER BY nomArticle asc"
        )->result_array();

        echo'
            <tr class="formApp">
                <td>
                    <select style="border-radius:20px;" class="id_article form-control" onchange="MontantArticle($(\'.id_article\').val(),\'prixApp\');ReferenceArticle($(\'.id_article\').val(),\'referenceApp\');">
                        <option></option>';
                        if (count($getArticle)>0) {
                            
                            foreach ($getArticle as $row) {
                                
                                echo"
                                <option value = '".$row['id_article']."' nomArticle='".$row['article']."'>".$row['nomArticle']."</option>";
                            }
                        }echo' 
                    </select>
                </td>

                <td>
                    <input type="text" style="border-radius:20px;" placeholder ="reference" class="form-control referenceApp" disabled="true">
                </td>
                                  
                <td>
                    <input type="text" style="border-radius:20px;" placeholder ="Montant" class="form-control prixApp" onkeypress="chiffres(event);"disabled="true">
                </td>
                                  
                <td>
                    <div>
                        <input type="text" style="border-radius:20px;" placeholder ="qtite"class="form-control qtiteApp" onkeypress="chiffres(event);">
                    </div>
                </td>

                <td>
                    <div class="input-group input-group-sm">
                       
                        <span class="input-group-append">'; 
                            if($this->session->userdata('autoStock_ajout') == "true") {
                                echo '<button type="button" class="btn btn-dark buttonA" onclick="ajoutApprovisionnement();">Ajouter <i class="nav-icon fas fa-plus-circle"></i></button>';
                            }echo'
                        </span>
                    </div>
                </td>
            </tr>';

        $this->db->close();
    }


    public function ajoutApprovisionnement(){

        $dateApp = $_POST["dateApp"];                             $auteurApp = $_POST["auteurApp"];
        $id_fournisseur = $_POST["id_fournisseur"];               $id_article = $_POST["id_article"];
		$blApp = $_POST["blApp"];                                 $referenceApp = $_POST["referenceApp"];
		$prixApp = $_POST["prixApp"];                             $qtiteApp = $_POST["qtiteApp"];
         
        $dateL = date("Y/m/d");  $dateE = date("Y/m/d");          $table = "approvisionnemnent"; 

        $securiteA =" <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong> a ajouté un approvisionnement sur l'article  <strong class='text-primary'>' " .$this->getArticle($id_article). " '</strong>  de prix <strong class='text-danger'>' " . $prixApp ." '  </strong> et de quantité <strong class='text-success'>' " . $qtiteApp ." '  </strong>";
 

        $Article = $this->db->query(
           "SELECT * 
            FROM approvisionnement 
            ORDER BY id_app DESC LIMIT 1"
        )->row();

        if (count($Article)>0) {
            
            $dateL = date("Y/m/d",strtotime($Article->dateApp));  $dateE = date("Y/m/d",strtotime($dateApp));
        }

        if ($dateE < $dateL) {
           
            echo "La date  doit être supérieure  à celle de l'inventaire"; 
        }else{
            $ajoutApp  = $this->db->query(
               "INSERT 
                INTO approvisionnement 
                VALUE
                (
                    '',
                    CAST('". $dateApp."' AS DATE),
                    '".$auteurApp."',
                    ".$id_fournisseur.",
                    '".$blApp."',
                    ".$id_article.",
                    '".$referenceApp."',
                    ".$prixApp.",
                    ".$qtiteApp."
                )"
            );

            if ($ajoutApp == true) {
                
                echo "Insertion éffectuée";
                $this->notificationAjout($table,addslashes($securiteA));
            }else{
                echo "Probleme de connexion";
            }
        }
        $this->db->close();
    }


    public function afficheDataApprovisionnement(){
		
		
		if (isset($_POST["dateDebut"]) && isset($_POST["dateFin"]) && isset($_POST["id_nom"])) {
            
            $dateDebut = $_POST['dateDebut'];  $dateFin = $_POST['dateFin']; $id_nom = $_POST['id_nom'];
            
		    if (!empty($dateFin) && !empty($dateDebut) && isset($_POST["id_nom"])) {

                $requete = $this->db->query(
                   "SELECT  * 
                    FROM approvisionnement 
                    WHERE  id_fournisseur = '".$id_nom."' and dateApp BETWEEN '".$dateDebut."' and '".$dateFin."' 
                    ORDER BY dateApp DESC"
                )->result_array();

                if ($id_nom == 'ALL') {
                    
                    $requete = $this->db->query(
                       "SELECT  * 
                        FROM approvisionnement 
                        WHERE  dateApp BETWEEN '".$dateDebut."' and '".$dateFin."'  
                        ORDER BY dateApp DESC"
                    )->result_array();
                
                }else {
                    
                    $requete = $this->db->query(
                       "SELECT  * 
                        FROM approvisionnement 
                        WHERE id_fournisseur = '".$id_nom."' and  dateApp BETWEEN '".$dateDebut."' and '".$dateFin."'
                        ORDER BY dateApp DESC "
                    )->result_array();
                    
                }	
            
            }else{
                
                $requete = $this->db->query(
                   "SELECT  * 
                    FROM approvisionnement  
                    ORDER BY id_app DESC"
                )->result_array();    
            }		
            
        }else{ 
            $requete = $this->db->query(
               "SELECT * 
                FROM approvisionnement 
                ORDER BY id_app DESC"
            )->result_array();
        }

        $c = 0;    $cqtite = 0;  $cmontantArticle = 0; $cmontantTotal = 0;

        if (count($requete) >0 ) {
            
           
            foreach ($requete as $row) {
                
                $getNomArticle = $this->db->query(
                   "SELECT * 
                    FROM article 
                    WHERE id_article =".$row['id_article'].""
                )->row();

                $getFournisseur = $this->db->query(
                   "SELECT * 
                    FROM fournisseur 
                    WHERE id_fournisseur=".$row['id_fournisseur'].""
                )->row();

                $cqtite = $cqtite + $row["qtiteApp"];   $cmontantArticle = $cmontantArticle + $row["prixApp"]; 

                $prix = $row['prixApp']*$row['qtiteApp']; $cmontantTotal = $cmontantTotal + $prix;


                echo"
                    <tr>
                        <td onclick=\"new();\">".$c."</td>";echo" 
                        <td>".$getFournisseur->nomFour."</td>
                        <td>".$getNomArticle->nomArticle."</td>
                        <td>".$row['referenceApp']."</td>
                        <td> <strong class='text-danger'>".number_format($row['prixApp'],0,',',' ')."</strong></td>
                        <td> <strong class='text-dark'>".number_format($row['qtiteApp'],0,',',' ')."</strong></td>
                        <td> <strong class='text-danger'>".number_format($row['qtiteApp']*$row['prixApp'],0,',',' ')."</strong></td>
                        <td> ".$row['dateApp']."</td>
                        <td>";

                            if ($this->session->userdata('autoArticle_voir') == 'true') {
                                echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"VoirApprovisionnement('". $row['id_app'] . "','" . $row['dateApp'] . "','" . $row['auteurApp'] . "','" . $row['id_fournisseur'] . "','" . $row['blApp'] . "','" . $row['id_article'] . "','" . $row['referenceApp'] . "','" . $row['prixApp'] . "','" . $row['qtiteApp'] . "')\" class=' ml-1'><i class='nav-icon  fas fa-eye text-info'></i></a>";
                            }

                            if ($this->session->userdata('autoStock_modification') == 'true') {
                                echo "<a type='button' onclick=\"ModiApprovisionnement('". $row['id_app'] . "','" . $row['dateApp'] . "','" . $row['auteurApp'] . "','" . $row['id_fournisseur'] . "','" . $row['blApp'] . "','" . $row['id_article'] . "','" . $row['referenceApp'] . "','" . $row['prixApp'] . "','" . $row['qtiteApp'] . "')\" class=' ml-2'><i class='nav-icon  fas fa-pencil-alt text-success'></i></a>";
                            }
                            if($this->session->userdata('autoStock_suppression')=='true'){
                                echo"<a type='button' class='ml-2' data-toggle='modal' data-target='#supprimer' table='approvisionnement' identifiant='" . $row['id_app'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_app\");'><i class='far  	fas fa-trash text-danger'></i></a>
                        </td>
                    </tr>"; }
                  $c++;
            }
        }echo "
        <tr>
            <td style='border: 0px;'><b>Total</b></td> <td style='border: 0px'></td>
            <td style='border: 0px'></td><td style='border: 0px'></td> 
            <td style='border: 0px'><b class='text-danger'>".number_format($cmontantArticle,0,',',' ')."</b></td>
            <td style='border: 0px'><b>".number_format($cqtite,0,',',' ')."</b></td>
            <td style='border: 0px'><b class='text-danger'>".number_format($cmontantTotal,0,',',' ')."</b></td>
            </td><td style='border: 0px'></td></td><td style='border: 0px'></td>
        </tr>";

        $this->db->close();
    }
    

  
 
    public function afficheData(){
		
		
		$requete = $this->db->query("SELECT * from fournisseur order by id_fournisseur desc")->result_array();
        
        if (count($requete) >0 ) {
        
            $query = $this->db->query("SELECT COUNT(*) AS nombre_fournisseur FROM fournisseur WHERE actifFour = 'OUI'")->row_array();
            echo $query['nombre_fournisseur'];
        }

        $this->db->close();
    }


    public function modiApprovisionnement(){

        $choix = $_POST["choix"];

        $dateApp = $_POST["dateAppM"];                       $auteurApp = $_POST["auteurAppM"];
        $id_fournisseur = $_POST["id_fournisseurM"];         $blApp = $_POST["blAppM"];
        $id_article = $_POST["id_articleM"];                 $referenceApp = $_POST["referenceAppM"];
		$prixApp = $_POST["prixAppM"];                       $qtiteApp = $_POST["qtiteAppM"];    $table = "approvisionnement"; 
        
        $securiteM =  " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a modifié l'approvisionnement l'article  <strong class='text-primary'>' " .$this->getArticle($id_article). " '</strong> de prix <strong class='text-danger'>' " . $prixApp ." '  </strong>et de quantité <strong class='text-success'>' " . $qtiteApp ." '  </strong>";

        if ($choix == "modifier") {
            
            $id_modi = $_POST["id_modi"];

            $requete = $this->db->query(
               "SELECT * 
                FROM approvisionnement 
                WHERE id_fournisseur ='". $id_fournisseur ."'  "
            )->result_array();

            if (count($requete) > 0) {
                
                foreach ($requete as $row) {
                    
                    if ($row["id_app"] == $id_modi) {

                        
                        $query1 = $this->db->query(
                           "UPDATE approvisionnement 
                            SET 
                                dateApp = CAST('". $dateApp."' AS DATE), 
                                auteurApp ='" . $auteurApp . "', 
                                id_fournisseur =" . $id_fournisseur . ", 
                                blApp ='" . $blApp . "',
                                id_article = " . $id_article . " , 
                                referenceApp ='" . $referenceApp . "', 
                                prixApp =" . $prixApp . ", 
                                qtiteApp =" . $qtiteApp . " 
                                
                            WHERE id_app =" . $id_modi . " "
                        );
                       
                        if ($query1 == true) {

                            echo "Modification éffectuée";

                            $this->notificationAjout($table, addslashes($securiteM));

                        } else {
                            echo "Erreur durant l'insertion";
                        }
                    } 
                }
            } else {
                $query1 = $this->db->query(
                   "UPDATE approvisionnement 
                    SET  
                        dateApp =CAST('". $dateApp."' AS DATE), 
                        auteurApp ='" . $auteurApp . "', 
                        id_fournisseur =" . $id_fournisseur . ", 
                        blApp ='" . $blApp . "',
                        id_article = " . $id_article . " , 
                        referenceApp ='" . $referenceApp . "', 
                        prixApp =" . $prixApp . ", 
                        qtiteApp =" . $qtiteApp . " 
                        
                    WHERE id_app =" . $id_modi . " "
                );
                
                if ($query1 == true) {

                    echo "Modification éffectuée";

                    $this->notificationAjout($table, addslashes($securiteM));
                } else {
                    echo "Erreur durant l'insertion";
                }
            }
        } else {
            echo "Erreur contactez l'administrateur";
        }

        $this->db->close();
    }


    public function dropApprovisionnement($a, $b, $c){

        $getArticle = $this->db->query(
           "SELECT * 
            FROM " . $a . " 
            WHERE " . $c . "=" . $b . ""
        )->row();

        if (count($getArticle) > 0) {
        
            $table = $a;
            
            $securiteS = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé l' Article <strong class='text-primary'> ' " .$this->getArticle($getArticle->id_article). " ' </strong> dans l'approvisionnement de prix <strong class='text-danger'> ' " . $getArticle->prixApp . " ' </strong> et quantité <strong class='text-success'> '" . $getArticle->qtiteApp . "'  </strong>";


            $drop = $this->db->query(
               "DELETE 
                FROM " . $a . " WHERE " . $c . "=" . $b . ""
            );

            if ($drop == true) {
                
                echo "Suppression  effectuée";
                $this->notificationAjout($table, addslashes($securiteS));
            } 
            else {
                echo "Pas supprimé";
            }
        }
        $this->db->close();
    }



    public function ListeArticleApp(){
        $requete = $this->db->query(
           "SELECT  * 
            FROM article 
            WHERE id_article IN 
                (   
                    SELECT id_article 
                    FROM approvisionnement
                ) 
            ORDER BY nomArticle"
        )->result_array();

        if (count($requete) >0) {
            # code...
            foreach ($requete as $row) {
                # code...
                echo "<option value='".$row["id_article"]."'>".$row["nomArticle"]."</option>";
            }
        }else{
            echo "Veillez Approvisionner";
        }

        $this->db->close();
    }

    /* DEFECTUEUX */

    public function tableDefectueux(){

        $getArticle = $this->db->query(
           "SELECT  * 
            FROM article 
            WHERE id_article IN 
                (
                    SELECT id_article 
                    FROM approvisionnement
                ) 
            ORDER BY nomArticle"
        )->result_array();

        echo'
            <tr class="formDef">
                <td>
                    <select style="border-radius:20px;" class="id_article form-control" onchange="MontantArticle($(\'.id_article\').val(),\'montantDef\');ReferenceArticle($(\'.id_article\').val(),\'referenceDef\');">
                        <option></option>';
                        if (count($getArticle)>0) {
                            
                            foreach ($getArticle as $row) {
                                
                                echo"
                                <option value = '".$row['id_article']."' nomArticle='".$row['article']."'>".$row['nomArticle']."</option>";
                            }
                        }echo' 
                    </select>
                </td>

                <td>
                    <input type="text" style="border-radius:20px;" placeholder ="reference" class="form-control referenceDef" disabled="true">
                </td>
                                  
                <td>
                    <input type="text" style="border-radius:20px;" placeholder ="Montant" class="form-control montantDef" onkeypress="chiffres(event);"disabled="true">
                </td>
                                  
                <td>
                    <div>
                        <input type="text" style="border-radius:20px;" placeholder ="qtite"class="form-control qtiteDef" onkeypress="chiffres(event);">
                    </div>
                </td>

                <td>
                    <div class="input-group input-group-sm">
                       
                        <span class="input-group-append">'; 
                            if($this->session->userdata('autoStock_ajout') == "true") {
                                echo '<button type="button" class="btn btn-dark buttonA" onclick="ajoutDefectueux();">Ajouter <i class="nav-icon fas fa-plus-circle"></i></button>';
                            }echo'
                        </span>
                    </div>
                </td>
            </tr>';

        $this->db->close();
    }


    public function ajoutDefectueux(){

        $dateDef = $_POST["dateDef"];                             $auteurDef = $_POST["auteurDef"];
        $id_fournisseur = $_POST["id_fournisseur"];               $id_article = $_POST["id_article"]; 
        $referenceDef = $_POST["referenceDef"];                   $qtiteDef = $_POST["qtiteDef"];
		$montantDef = $_POST["montantDef"];                             
         
        $dateL = date("Y/m/d");  $dateE = date("Y/m/d");                 $table = "defectueux"; 

        $securiteA =" <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong> a ajouté un article defectueux <strong class='text-primary'>' " .$this->getArticle($id_article). " '</strong>  de prix <strong class='text-danger'>' " . $montantDef ." '  </strong> et de quantité <strong class='text-success'>' " . $qtiteDef ." '  </strong>";
 

        $Article = $this->db->query(
           "SELECT * 
            FROM defectueux 
            ORDER BY id_defectueux 
            DESC LIMIT 1"
        )->row();

        if (count($Article)>0) {
            
            $dateL = date("Y/m/d",strtotime($Article->dateDef));  $dateE = date("Y/m/d",strtotime($dateDef));
        }

        if ($dateE < $dateL) { 
            echo "La date  doit être supérieure  à celle de l'inventaire"; 
        }else{
            $ajoutApp  = $this->db->query(
               "INSERT 
                INTO defectueux 
                VALUE
                    (
                        '',
                        CAST('". $dateDef."' AS DATE),
                        '".$auteurDef."',
                        ".$id_fournisseur.",
                        ".$id_article.",
                        '".$referenceDef."',
                        ".$montantDef.",
                        ".$qtiteDef."
                    )"
                );

            if ($ajoutApp == true) {
                
                echo "Insertion éffectuée";
                $this->notificationAjout($table,addslashes($securiteA));
            }else{
                echo "Probleme de connexion";
            }
        }
        $this->db->close();
    }


    public function afficheDataDefectueux(){
		
		
		if (isset($_POST["dateDebut"]) && isset($_POST["dateFin"]) && isset($_POST["id_nom"])) {
            
            $dateDebut = $_POST['dateDebut'];  $dateFin = $_POST['dateFin']; $id_nom = $_POST['id_nom'];
            
		    if (!empty($dateFin) && !empty($dateDebut) && isset($_POST["id_nom"])) {

                $requete = $this->db->query(
                   "SELECT  * 
                    FROM defectueux 
                    WHERE  id_fournisseur = '".$id_nom."' and dateDef BETWEEN '".$dateDebut."' and '".$dateFin."'  
                    ORDER BY dateDef DESC"
                )->result_array();

                if ($id_nom == 'ALL') {
                    
                    $requete = $this->db->query(
                       "SELECT  * 
                        FROM defectueux 
                        WHERE  dateDef BETWEEN '".$dateDebut."' and '".$dateFin."'  ORDER BY dateDef DESC"
                    )->result_array();
                
                }else {
                    
                    $requete = $this->db->query(
                       "SELECT  * 
                        FROM defectueux 
                        WHERE id_fournisseur = '".$id_nom."' and  dateDef BETWEEN '".$dateDebut."' and '".$dateFin."'ORDER BY dateDef DESC "
                    )->result_array();
                    
                }	
            
            }else{
                
                $requete = $this->db->query(
                   "SELECT  * 
                    FROM defectueux  
                    ORDER BY id_defectueux DESC"
                )->result_array();    
            }		
            
        }else{ 
            $requete = $this->db->query(
               "SELECT * 
                FROM defectueux 
                ORDER BY id_defectueux DESC"
            )->result_array();
        }

        

        if (count($requete) >0 ) {
            
            $c = 0;
            foreach ($requete as $row) {
                
                $getNomArticle = $this->db->query(
                   "SELECT * 
                    FROM article 
                    WHERE id_article =".$row['id_article'].""
                )->row();

                $getFournisseur = $this->db->query(
                   "SELECT * 
                    FROM fournisseur 
                    WHERE id_fournisseur=".$row['id_fournisseur'].""
                )->row();

                echo"
                    <tr>
                        <td onclick=\"new();\">".$c."</td>";echo" 
                        <td>".$getNomArticle->nomArticle."</td>
                        <td>".$row['referenceDef']."</td>
                        <td> <strong class='text-danger'>".number_format($row['montantDef'],0,',',' ')."</strong></td>
                        <td> <strong class='text-dark'>".number_format($row['qtiteDef'],0,',',' ')."</strong></td>
                        <td> <strong class='text-danger'>".number_format($row['montantDef']*$row['qtiteDef'],0,',',' ')."</strong></td>
                        <td> ".$row['dateDef']."</td>
                        <td>";

                            if ($this->session->userdata('autoArticle_voir') == 'true') {
                                echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"VoirDefectueux('". $row['id_defectueux'] . "','" . $row['dateDef'] . "','" . $row['auteurDef'] . "','" . $row['id_fournisseur'] . "','" . $row['id_article'] . "','" . $row['referenceDef'] . "','" . $row['montantDef'] . "','" . $row['qtiteDef'] . "')\" class=' ml-1'><i class='nav-icon  fas fa-eye text-info'></i></a>";
                            }

                            if ($this->session->userdata('autoStock_modification') == 'true') {
                                echo "<a type='button' onclick=\"ModiDefectueux('". $row['id_defectueux'] . "','" . $row['dateDef'] . "','" . $row['auteurDef'] . "','" . $row['id_fournisseur'] . "','" . $row['id_article'] . "','" . $row['referenceDef'] . "','" . $row['montantDef'] . "','" . $row['qtiteDef'] . "')\" class=' ml-2'><i class='nav-icon  	fas fa-pencil-alt text-success'></i></a>";
                            }
                            if($this->session->userdata('autoStock_suppression')=='true'){
                                echo"<a type='button' class='ml-2' data-toggle='modal' data-target='#supprimer' table='defectueux' identifiant='" . $row['id_defectueux'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_defectueux\");'><i class='far  	fas fa-trash text-danger'></i></a>
                        </td>
                    </tr>"; }
                  $c++;
            }
        }

        $this->db->close();
    }
    
 
    public function modiDefectueux(){

        $choix = $_POST["choix"];

        $dateDef = $_POST["dateDefM"];                             $auteurDef = $_POST["auteurDefM"];
        $id_fournisseur = $_POST["id_fournisseurM"];               $id_article = $_POST["id_articleM"];
		$referenceDef = $_POST["referenceDefM"];             	   $montantDef = $_POST["montantDefM"];
		$qtiteDef = $_POST["qtiteDefM"];                           $table = "defectueux"; 
         
        $securiteM =  " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a modifié  l'article  defectueux <strong class='text-primary'>' " .$this->getArticle($id_article). " '</strong> de prix <strong class='text-danger'>' " . $montantDef ." '  </strong>et de quantité <strong class='text-success'>' " . $qtiteDef." '  </strong>";

        if ($choix == "modifier") {
            
            $id_modi = $_POST["id_modi"];

            $requete = $this->db->query(
               "SELECT * 
                FROM defectueux 
                WHERE id_fournisseur ='". $id_fournisseur ."'  "
            )->result_array();

            if (count($requete) > 0) {
                
                foreach ($requete as $row) {
                    
                    if ($row["id_defectueux"] == $id_modi) {

                        
                        $query1 = $this->db->query(
                           "UPDATE defectueux 
                            SET 
                                dateDef = CAST('". $dateDef."' AS DATE), 
                                auteurDef ='" . $auteurDef . "', 
                                id_fournisseur =" . $id_fournisseur . ",
                                id_article = " . $id_article . " , 
                                referenceDef ='" . $referenceDef . "', 
                                montantDef =" . $montantDef . ", 
                                qtiteDef =" . $qtiteDef . " 
                                
                            WHERE id_defectueux =" . $id_modi . " "
                        );
                       
                        if ($query1 == true) {

                            echo "Modification éffectuée";

                            $this->notificationAjout($table, addslashes($securiteM));

                        } else {
                            echo "Erreur durant l'insertion";
                        }
                    } 
                }
            } else {
                $query1 = $this->db->query(
                   "UPDATE defectueux 
                    SET 
                        dateDef = CAST('". $dateDef."' AS DATE), 
                        auteurDef ='" . $auteurDef . "', 
                        id_fournisseur =" . $id_fournisseur . ",
                        id_article = " . $id_article . " , 
                        referenceDef ='" . $referenceDef . "', 
                        montantDef =" . $montantDef . ", 
                        qtiteDef =" . $qtiteDef . " 
                        
                    WHERE id_defectueux =" . $id_modi . " "
                );
                
                if ($query1 == true) {

                    echo "Modification éffectuée";

                    $this->notificationAjout($table, addslashes($securiteM));
                } else {
                    echo "Erreur durant l'insertion";
                }
            }
        } else {
            echo "Erreur contactez l'administrateur";
        }

        $this->db->close();
    }


    public function dropDefectueux($a, $b, $c){

        $getArticle = $this->db->query(
           "SELECT * 
            FROM " . $a . " 
            WHERE " . $c . "=" . $b . ""
        )->row();

        if (count($getArticle) > 0) {
        
            $table = $a;
            
            $securiteS = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé l' Article defectueux <strong class='text-primary'> ' " .$this->getArticle($getArticle->id_article). " ' </strong>  de prix <strong class='text-danger'> ' " . $getArticle->montantDef . " ' </strong> et quantité <strong class='text-success'> '" . $getArticle->qtiteDef . "'  </strong>";


            $drop = $this->db->query(
               "DELETE 
                FROM " . $a . " 
                WHERE " . $c . "=" . $b . ""
            );

            if ($drop == true) {
                
                echo "Suppression  effectuée";
                $this->notificationAjout($table, addslashes($securiteS));
            } 
            else {
                echo "Pas supprimé";
            }
        }
        $this->db->close();
    }


    public function afficheStockDasboard(){
        
        $Article = $this->db->query(
           "SELECT * 
            FROM article 
            ORDER BY nomArticle"
        )->result_array();    $c = 0;

        if (count($Article) > 0) {
            
            foreach ($Article as $row) {

                $qtiteInv = 0;   $qtiteApp = 0;   $qtiteDef = 0;  $qtiteSort = 0; $dernierInv = $this->DernierInventaire();

                 
                $Inventaire = $this->db->query(
                   "SELECT * 
                    FROM inventaire 
                    WHERE  id_article = ".$row['id_article']." 
                    ORDER BY dateInv DESC"
                )->result_array();
                
                $Approvisionnement = $this->db->query(
                   "SELECT * 
                    FROM approvisionnement 
                    WHERE id_article = ".$row['id_article']." and dateApp >= '".$dernierInv."' "
                )->result_array();
                
                $Defectueux = $this->db->query(
                   "SELECT * 
                    FROM defectueux 
                    WHERE dateDef >= '".$dernierInv."' and  id_article = ".$row['id_article'].""
                )->result_array();
            
                $sortie = $this->db->query(
                   "SELECT * 
                    FROM sortie 
                    WHERE date >= '".$dernierInv."' and  id_article = ".$row['id_article'].""
                )->result_array();
            

                $article = $this->db->query(
                    "SELECT * 
                    FROM article 
                    WHERE id_article =".$row['id_article'].""
                )->row();  echo"
                
                <tr>
                    <td onclick=\"new();\">".$c."</td>
                    <td>". $article->nomArticle."</td> 
                    <td><strong class='text-info'>".number_format($article->montantArticle,0,',',' ')."</strong></td>"; 
 
                
                if (count($Approvisionnement)>0) { 

                    foreach ($Approvisionnement as $app) {
                        $qtiteApp= $qtiteApp + $app['qtiteApp'];
                    }echo"

                    <td><strong class='text-dark'>".number_format($qtiteApp,0,',',' ')."</strong></td>";
                }
                else{
                    echo"
                    <td><strong class='text-dark'>".number_format(0,0,',',' ')."</strong></td>";
                } echo"
                    <td><strong class='text-danger'>".number_format($article->montantArticle*$qtiteApp,0,',',' ')."</strong></td>

                    <td><strong class='text-primary'>".number_format($article->prixVente,0,',',' ')."</strong></td>";
  
                
                if (count($sortie)>0) { 

                    foreach ($sortie as $sortie) {
                        $qtiteSort = $qtiteSort + $sortie['qtite'];
                    }echo"
                    <td><strong class='text-dark'>".number_format($qtiteSort,0,',',' ')."</strong></td> ";
                }else{
                    echo"
                    <td><strong class='text-dark'>".number_format(0,0,',',' ')."</strong></td>";
                } echo"
                    <td><strong class='text-danger'>".number_format($article->prixVente*$qtiteSort,0,',',' ')."</strong></td>
                    <td><strong class='text-success'>".number_format(($article->prixVente-$article->montantArticle )*$qtiteSort,0,',',' ')."</strong></td> ";
                $c++;
            }
        }
        $this->db->close();
    }


           
    public function afficheStock(){
        
        $Article = $this->db->query(
            "SELECT * 
            FROM article 
            ORDER BY nomArticle"
        )->result_array();    $c = 0;

        if (count($Article) > 0) {
            
            foreach ($Article as $row) {

                $qtiteInv = 0;   $qtiteApp = 0;   $qtiteDef = 0;  $qtiteSort = 0; $dernierInv = $this->DernierInventaire();

                 
                $Inventaire = $this->db->query(
                   "SELECT * 
                    FROM inventaire 
                    WHERE  id_article = ".$row['id_article']." 
                    ORDER BY dateInv DESC"
                )->result_array();
                
                $Approvisionnement = $this->db->query(
                   "SELECT * 
                    FROM approvisionnement 
                    WHERE id_article = ".$row['id_article']." and dateApp >= '".$dernierInv."'"
                )->result_array();
                
                $Defectueux = $this->db->query(
                   "SELECT * 
                    FROM defectueux 
                    WHERE dateDef >= '".$dernierInv."' and  id_article = ".$row['id_article'].""
                )->result_array();
            
                $sortie = $this->db->query(
                   "SELECT * 
                    FROM sortie 
                    WHERE date >= '".$dernierInv."' and  id_article = ".$row['id_article'].""
                )->result_array();
            

                $article = $this->db->query(
                   "SELECT * 
                    FROM article 
                    WHERE id_article =".$row['id_article'].""
                )->row();  echo"
                
                <tr>
                    <td onclick=\"new();\">".$c."</td>
                    <td>". $article->nomArticle."</td>
                    <td>". $article->referenceArticle."</td>
                    <td><strong class='text-danger'>".number_format($article->prixVente,0,',',' ')."</strong></td>"; 

                   
                if (count($Inventaire)>0) {
                    
                    foreach ($Inventaire as $inventaire) { 
                        $qtiteInv = $qtiteInv + $inventaire['qtiteInv'];
                    }echo"
                    <td><strong class='text-dark'>".number_format($qtiteInv,0,',',' ')."</strong></td>";
                }else{ echo "
                    <td><strong class='text-dark'>".number_format(0,0,',',' ')."</strong></td>";
                } 
                
                if (count($Approvisionnement)>0) { 

                    foreach ($Approvisionnement as $app) {
                        $qtiteApp= $qtiteApp + $app['qtiteApp'];
                    }echo"
                    <td><strong class='text-dark'>".number_format($qtiteApp,0,',',' ')."</strong></td>";
                }else{echo"
                    <td><strong class='text-dark'>".number_format(0,0,',',' ')."</strong></td>";
                }   
                
                if (count($Defectueux)>0) { 
                    foreach ($Defectueux as $Def) {
                        $qtiteDef = $qtiteDef + $Def['qtiteDef'];
                    }echo"
                    <td><strong class='text-danger'>".number_format($qtiteDef,0,',',' ')."</strong></td> ";
                }else{echo"
                    <td><strong class='text-danger'>".number_format(0,0,',',' ')."</strong></td>";
                }

                if (count($sortie)>0) { 
                    foreach ($sortie as $sortie) {
                        $qtiteSort = $qtiteSort + $sortie['qtite'];
                    }echo"
                    <td><strong class='text-danger'>".number_format($qtiteSort,0,',',' ')."</strong></td> ";
                }else{echo"
                    <td><strong class='text-danger'>".number_format(0,0,',',' ')."</strong></td>";
                }
                
                $stock = $qtiteInv  + $qtiteApp - $qtiteDef -  $qtiteSort;  echo"
                
                <td><strong class='text-primary'>".number_format($stock,0,',',' ')."</strong></td>";

                if ($this->session->userdata('autoUser_suppression') == 'true') {
                    echo "<td><strong class='text-success'>".number_format($stock*$article->prixVente,0,',',' ')."</strong></td>";
                }else{
                    echo "<td></td>";
                }

                 
                $c++;
            }
        }
        $this->db->close();
    }



        
    public function StockArticle(){
        
        $id_article = $_POST["id_article"];   $date = $_POST["date"];
        
        $inv = 0; $app = 0; $def = 0; $sort = 0;
        

        if (empty($id_article)) {
            echo "0 ";
        }else{
    
            $inventaire = $this->db->query(
               "SELECT sum(qtiteInv) AS sommeInv 
                FROM inventaire 
                WHERE id_article = ".$id_article." and dateInv BETWEEN '".$this->DernierInventaire()."' and '".$date."' "
            )->row();

            if (count($inventaire) >0) {

                $inv =  $inventaire->sommeInv;	

            }else{	 

                $inv =  0;
            }

            $approvisionnement = $this->db->query(
               "SELECT sum(qtiteApp) AS sommeApp 
                FROM approvisionnement 
                WHERE id_article = ".$id_article." and dateApp BETWEEN '".$this->DernierInventaire()."' and '".$date."' "
            )->row();

            if (count($approvisionnement) >0) {

                $app =  $approvisionnement->sommeApp;

            }else{	
            
                $app =  0;
            }
            
            $Sortie = $this->db->query(
               "SELECT sum(qtite) AS sommeSortie 
                FROM sortie 
                WHERE id_article = ".$id_article."  and date between '".$this->DernierInventaire()."' and '".$date."' "
            )->row();

            if (count($Sortie) >0) {
                 $sort =  $Sortie->sommeSortie;	
            }else{	
            
                 $sort =  0;	
            }
            
            $defectueux = $this->db->query(
                "SELECT sum(qtiteDef) AS sommeDef 
                FROM defectueux 
                WHERE id_article = ".$id_article." and  dateDef BETWEEN '".$this->DernierInventaire()."' and '".$date."' "
            )->row();

            if (count($defectueux) >0) {

                $def =  $defectueux->sommeDef;	

            }else{	
            
                $def =  0;	

            }

            echo $inv + $app  - $sort - $def;
        
            
        }

        $this->db->close();
    }


    public function ajoutSortie(){


        $choix = $_POST["choix"];                             $id_table = $_POST["id_table"];  
        $date = $_POST["date"];                               $numero = $_POST["numero"]; 
        $id_client = $_POST["id_client"];                     $id_article = $_POST["id_article"]; 
        $referenceArticle = $_POST['referenceArticle'];       $prixVente = preg_replace('/\s/', '', $_POST["prixVente"]); 
        $qtite = $_POST["qtite"];                             $tva = $_POST["tva"]; 
        $table = "sortie";                                    $montantTva = preg_replace('/\s/', '', $_POST["montantTva"]); 

        $notifAjout = "<strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a ajouté une sortie de N°Facture <strong class='text-info'> '" . $numero . "' </strong> l'article :  <strong class='text-danger'> ' " .$this->getArticle($id_article). " ' </strong>de montant :  <strong class='text-danger'> '" . $prixVente . "' </strong>  de qtite : <strong class='text-dark'> '" . $qtite . "' </strong>";

        $notifModif = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a modifié une sortie de N°Facture <strong class='text-info'> '" . $numero . "' </strong> l'article :  <strong class='text-danger'> ' " .$this->getArticle($id_article). " ' </strong>de montant :  <strong class='text-danger'> '" . $prixVente . "' </strong>  de qtite : <strong class='text-dark'> '" . $qtite . "' </strong>";

        if ($choix == "ajouter") {
            
            $requete = $this->db->query(
               "SELECT * 
                FROM sortie "
            )->result_array();

 
            $query = $this->db->query(
               "INSERT 
                INTO sortie 
                VALUE
                    (
                        '',
                        CAST('" . $date . "' AS DATE),
                        '".$numero."',
                        '" . $id_client . "',
                        '" . $id_article . "',
                        '" . $referenceArticle . "',
                        " . $prixVente . ",
                        " . $qtite . ",
                        '" . $tva . "',
                        ".$montantTva."
                    ) "
                );
            
            if ($query == true) {
                echo "Insertion éffectuée";
                $this->notificationAjout($table, addslashes($notifAjout));
            } 
            else {
                echo "Erreur durant l'insertion";
            }
        } 
        elseif ($choix == "modifier") {
        
            $id_table  = $_POST["id_table"];
            
            $requete = $this->db->query(
                "SELECT * 
                FROM sortie "
            )->result_array();

            if (count($requete) > 0) {

                foreach ($requete as $row) {

                    if ($row["id_sortie"] == $id_table ) {
                
                        $query1 = $this->db->query(
                           "UPDATE sortie 
                            SET  
                                numero ='" . $numero . "',  
                                id_client ='" . $id_client . "', 
                                id_article ='" . $id_article . "', 
                                date = CAST('" . $date . "' AS DATE), 
                                prixVente = '" . $prixVente . "', 
                                referenceArticle = '" . $referenceArticle . "',  
                                qtite = '" . $qtite . "', 
                                tva ='".$tva."', 
                                montantTva ='".$montantTva."' 
                            
                            where id_sortie =" . $id_table  . ""
                        );
                        if ($query1 == true) {
                            echo "Modification éffectuée";
                            $this->notificationAjout($table, addslashes($notifModif));
                        } 
                        else {
                            echo "Problème pendant la Modification";
                        }
                    } 
                }
            } 
            else {
                $query1 = $this->db->query(
                   "UPDATE sortie 
                    SET  
                        numero ='" . $numero . "',  
                        id_client ='" . $id_client . "', 
                        id_article ='" . $id_article . "', 
                        date = CAST('" . $date . "' AS DATE), 
                        prixVente = '" . $prixVente . "', 
                        referenceArticle = '" . $referenceArticle . "',  
                        qtite = '" . $qtite . "', 
                        tva ='".$tva."', 
                        montantTva ='".$montantTva."' 

                    where id_sortie =" . $id_table  . ""
                );
                
                if ($query1 == true) {
                    echo "Modification éffectuée";
                    $this->notificationAjout($table, addslashes($notifModif));
                } 
                else {
                    echo "Problème pendant la Modification";
                }
            }
        } 
        else {
            echo "problème se trouvant dans l'ajoutClient";
        }
        $this->db->close();
    }



    public function afficheDataSortie(){
		  
        if (isset($_POST["dateDebut"]) && isset($_POST["dateFin"]) && isset($_POST["id_nom"])) {
            
            $dateDebut = $_POST['dateDebut'];  $dateFin = $_POST['dateFin']; $id_nom = $_POST['id_nom'];
            
		    if (!empty($dateFin) && !empty($dateDebut) && isset($_POST["id_nom"])) {

                $requete = $this->db->query(
                   "SELECT  * 
                    FROM sortie 
                    WHERE  id_client = '".$id_nom."' and date between '".$dateDebut."' and '".$dateFin."'  
                    ORDER BY date DESC"
                )->result_array();

                if ($id_nom == 'ALL') {
                    
                    $requete = $this->db->query(
                       "SELECT  * 
                        FROM sortie 
                        WHERE  date between '".$dateDebut."' and '".$dateFin."'  
                        ORDER BY date DESC"
                    )->result_array();
                
                }else {
                    
                    $requete = $this->db->query(
                       "SELECT  * 
                        FROM sortie 
                        WHERE id_client = '".$id_nom."' and  date between '".$dateDebut."' and '".$dateFin."' 
                        ORDER BY date DESC "
                    )->result_array();
                    
                }	
            
            }else{
                
                $requete = $this->db->query(
                   "SELECT  * 
                    FROM sortie  
                    ORDER BY id_sortie DESC"
                )->result_array();    
            }		
            
        }else{ 
            $requete = $this->db->query(
                "SELECT * 
                FROM sortie ORDER BY id_sortie desc"
            )->result_array();
        }

        
        $c = 0;  $cqtite = 0; $cmontantTva = 0;  $cmontantArticle = 0;
        

        if (count($requete) >0 ) {
            
            foreach ($requete as $row) {
                
                $client = $this->db->query(
                   "SELECT * 
                    FROM client 
                    WHERE id_client  =".$row['id_client'].""
                )->row();

                $article = $this->db->query(
                   "SELECT * 
                    FROM article 
                    WHERE id_article  =".$row['id_article'].""
                )->row();

                $cqtite = $cqtite + $row["qtite"]; 

                $prixtva = $row['montantTva']; $cmontantTva = $cmontantTva + $prixtva;

                $prix = $row['prixVente']*$row['qtite']; $cmontantArticle = $cmontantArticle + $prix;

                echo"
                <tr>
                    <td onclick=\"new();\">" . $c . "</td>
                    <td>" . $row['numero'] . "</td>  
                    <td>" . $article->nomArticle . "</td>
                    <td> <strong class='text-danger'>".number_format($row['prixVente'],0,',',' ')."</strong></td>
                    <td> <strong class='text-dark'>".number_format($row['qtite'],0,',',' ')."</strong></td> 
                    <td> <strong class='text-danger'>".number_format($row['prixVente']*$row['qtite'],0,',',' ')."</strong></td>";
                    if ($row['tva'] == 'OUI') {
                        echo"<td class='text-primary'><strong>oui</strong></td>";
                    }
                    if ($row['tva'] == 'NON') {
                        echo"<td class='text-dark'><strong>non</td>";
                    }echo" 
                    <td> <strong class='text-dark'>".number_format($row['montantTva'],0,',',' ')."</strong></td> 
                    <td> " . $row['date'] . "</td>
                    <td>";

                    if ($this->session->userdata('autoArticle_voir') == 'true') {
                        echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"VoirSortie('" . $row['id_sortie'] . "','" . $row['date'] . "','" . $row['numero'] . "','" . $row['id_client'] . "','" . $row['id_article'] . "','" . $row['referenceArticle'] . "','" . $row['prixVente'] . "','" . $row['qtite'] . "','" . $row['tva'] . "','".$row['montantTva']."')\"><i class='nav-icon fas fa-eye text-info'></i></a>";
                    }

                    if ($this->session->userdata('autoArticle_modification') == 'true') {
                        echo "<a type='button' onclick=\"modiSortie('" . $row['id_sortie'] . "','" . $row['date'] . "','" . $row['numero'] . "','" . $row['id_client'] . "','" . $row['id_article'] . "','" . $row['referenceArticle'] . "','" . $row['prixVente'] . "','" . $row['qtite'] . "','" . $row['tva'] . "','".$row['montantTva']."')\" class=' ml-2'><i class='nav-icon fas fa-pen text-success'></i></a>";
                    }

                    if ($this->session->userdata('autoArticle_suppression') == 'true') {
                        echo "<a type='button' class='ml-2' data-toggle='modal' data-target='#supprimer' table='sortie' identifiant='" . $row['id_sortie'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_sortie\");'><i class='far fas fa-trash text-danger'></i></a>
                    </td> 
                </tr>"; }
                $c++;
            }
        } echo "
        <tr>
            <td style='border: 0px;'><b>Total</b></td> <td style='border: 0px'></td>
            <td style='border: 0px'></td><td style='border: 0px'></td>
            <td style='border: 0px'><b>".number_format($cqtite,0,',',' ')."</b></td>
            <td style='border: 0px'><b class='text-danger'>".number_format($cmontantArticle,0,',',' ')."</b></td>
            <td style='border: 0px'><td style='border: 0px'>
            <b class='text-primary'>".number_format($cmontantTva,0,',',' ')."</b></td>
            </td><td style='border: 0px'></td></td><td style='border: 0px'></td>
        </tr>";
		
        $this->db->close();
    }


    public function dropSorti($a, $b, $c){

        $requete = $this->db->query(
           "SELECT * 
            FROM " . $a . " 
            WHERE " . $c . "=" . $b . ""
        )->row();

        if (count($requete) > 0) {
        
            $table = $a;
            
            $securiteS = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé la sortie l'Article  <strong class='text-primary'> ' " .$this->getArticle($requete->id_article). " ' </strong>  de prix <strong class='text-danger'> ' " . $requete->prixVente . " ' </strong> et quantité <strong class='text-success'> '" . $requete->qtite . "'  </strong>";


            $drop = $this->db->query(
               "DELETE 
                FROM " . $a . " 
                WHERE " . $c . "=" . $b . ""
            );

            if ($drop == true) {
                
                echo "Suppression  effectuée";
                $this->notificationAjout($table, addslashes($securiteS));
            } 
            else {
                echo "Pas supprimé";
            }
        }
        $this->db->close();
    }


}