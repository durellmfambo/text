<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class ModelEmploye extends CI_Model {


    function __construct() {

        parent::__construct(); $this->load->database('default');  $this->load->library('session'); $this->load->helper('cookie');
        $this->load->helper('url');
        
    }


    public function notificationAjout($table,$securite){

        $this->db->query(
            "INSERT 
            INTO notification 
            VALUE
            (
                '',
                '".php_uname('n')."',
                ".$this->session->userdata('id_profil').",
                '".$table."',
                '".$securite."',
                now(),now()
            )"
        );
        $this->db->close();
    }


    public function getUsername($id_profil){

        $query = $this->db->query(
            "SELECT * 
            FROM profil 
            WHERE id_profil=".$id_profil.""
        )->row();

        if (count($query)>0) {
            
            return $query->identifiant;
        }
        $this->db->close();
    }

    /* FONCTION */

    public function codeFonction(){ 

        $requete = $this->db->query(
            
           "SELECT * 
            FROM fonction 
            ORDER BY id_fonction DESC limit 1"
        
        )->row();

        $code =0;

        if (count($requete)>0) {
            $code = $requete->codeFonc;
        }else{
            $code = 0;
        }

        $code++;

        while (strlen($code)<3) {
            $code = "0".$code;
        }
        return "FON".filter_var($code, FILTER_SANITIZE_NUMBER_INT);
    }
  

    public function ajoutFonction(){

        $choix = $_POST["choix"];    $codeFonc = $this->codeFonction();

        $fonction = $_POST["fonction"];   $commentaireFonc = addslashes($_POST['commentaireFonc']); $dateFonc = $_POST["dateFonc"];

        $actifFonc = $_POST["actifFonc"];   $table = "fonction";

        $securiteA = "<strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a ajouté la fonction <strong class='text-info'> '" . $fonction . "' </strong> de commentaire :  <strong class='text-danger'> '" . $commentaireFonc . "' </strong> de Actif :  <strong class='text-success'> '" . $actifFonc . "'</strong>";

        $securiteM = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a modifié la fonction  <strong class='text-info'> '" . $fonction . "' </strong> de commentaire :  <strong class='text-danger'> '" . $commentaireFonc . "' </strong> de Actif :  <strong class='text-success'> '" . $actifFonc . "'</strong>";

        if ($choix == "ajouter") {

            $requete = $this->db->query(
                
               "SELECT * 
                FROM fonction 
                WHERE fonction ='" . $fonction . "' "
                
            )->result_array();

            if (count($requete) > 0) {

                echo "Cette fonction '" . $fonction . "' apparaît déjà ";
            }
            else {
                $query1 = $this->db->query(
                    
                   "INSERT 
                    INTO fonction 
                    VALUE
                    (
                        '',
                        '".$codeFonc."',
                        '" . $fonction . "',
                        '" . $commentaireFonc . "',
                        CAST('" . $dateFonc . "' AS DATE),
                        '".$actifFonc."'
                    )"
                );
                
                if ($query1 == true) {
                    echo "Insertion éffectuée ";
                    $this->notificationAjout($table, addslashes($securiteA));
                } 
                else {
                    echo "Erreur durant l'insertion";
                }
            }
        } 
        elseif ($choix == "modifier") {
         
            $id_table = $_POST["id_table"];
            
            $requete = $this->db->query(
                
               "SELECT * 
                FROM fonction 
                WHERE  fonction ='" . $fonction . "' "
                
            )->result_array();

            if (count($requete) > 0) {

                foreach ($requete as $row) {

                    if ($row["id_fonction"] == $id_table) {
                
                        $query1 = $this->db->query(
                            
                           "UPDATE fonction 
                            SET 
                                fonction ='" . $fonction . "',
                                commentaireFonc = '" . $commentaireFonc . "', 
                                dateFonc = CAST('" . $dateFonc . "' AS DATE),
                                actifFonc='".$actifFonc."' 

                            WHERE id_fonction =" . $id_table . ""
                            
                        );
                        if ($query1 == true) {
                            echo "Modification éffectuée";
                            $this->notificationAjout($table, addslashes($securiteM));
                        } 
                        else {
                            echo "Problème pendant la Modification";
                        }
                    } 
                    else {
                        echo "Cette fonction \"" . $fonction . "\" apparaît déjà ";
                    }
                }
            } 
            else {
                $query1 = $this->db->query(
                    
                   "UPDATE fonction 
                    set  
                        fonction ='" . $fonction . "', 
                        commentaireFonc = '" . $commentaireFonc . "' , 
                        dateFonc = CAST('" . $dateFonc . "' AS DATE) ,
                        actifFonc='".$actifFonc."'

                    WHERE id_fonction =" . $id_table . "");
                
                if ($query1 == true) {
                    echo "Modification éffectuée";
                    $this->notificationAjout($table, addslashes($securiteM));
                } 
                else {
                    echo "Problème pendant la Modification";
                }
            }
        } 
        else {
            echo "problème se trouvant dans l'ajoutCategorieArticle";
        }
        $this->db->close();
    }


    public function afficheDataFonction(){

        $query1 = $this->db->query(
            
           'SELECT * 
            FROM fonction 
            ORDER BY fonction ASC'
            
        )->result_array();

        $i = 0;

        foreach ($query1 as $row) {
        
            echo 
            "<tr>
                <td onclick=\"new();\">" . $i . "</td>
                <td>" . $row['codeFonc'] . "</td>
                <td>" . $row['fonction'] . "</td>
                <td> " . $row['dateFonc'] . "</td>";

                if ($row['actifFonc'] == 'OUI') {
                    echo"<td class='text-success'><strong><i class='nav-icon fas fa-check-circle'></i></strong></td>";
                }
                if ($row['actifFonc'] == 'NON') {
                    echo"<td class='text-danger'><strong><i class='nav-icon fas fa-times-circle'></i></strong></td>";
                }echo"
                <td>";
                    if ($this->session->userdata('autoEmploye_voir') == 'true') {
                        echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"VoirFonction('" . $row['id_fonction'] . "','" . $row['codeFonc'] . "','" . $row['fonction'] . "','" . addslashes($row['commentaireFonc']) . "','" . $row['dateFonc']  . "','".$row['actifFonc']."')\" class=' ml-2'><i class='nav-icon fas fa-eye text-info'></i></a>";
                    }

                    if ($this->session->userdata('autoEmploye_modification') == 'true') {
                        echo "<a type='button' onclick=\"modiFonction('" . $row['id_fonction'] . "','" . $row['codeFonc'] . "','" . $row['fonction'] . "','" . addslashes($row['commentaireFonc']) . "','" . $row['dateFonc']  . "','".$row['actifFonc']."')\" class=' ml-2 '><i class='nav-icon 	fas fa-pen text-success'></i></a>";
                    }

                    if ($this->session->userdata('autoEmploye_suppression') == 'true') {
                        echo "<a type='button' class='ml-2' data-toggle='modal' data-target='#supprimer' table='fonction' identifiant='" . $row['id_fonction'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_fonction\");'><i class='far fas fa-trash text-danger'></i></a>
                </td>
            </tr>"; }
            $i++;
        }
        $this->db->close();
    }


    public function dropFonction($a, $b, $c){

        $fonction = $this->db->query(
            
           "SELECT * 
            FROM " . $a . " 
            WHERE " . $c . "=" . $b . ""
            
        )->row();

        if (count($fonction) > 0) {
        
            $table = $a;

            $securiteS = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé la fonction <strong class='text-info'> '" . $fonction->fonction . "' </strong>  Actif :  <strong class='text-danger'> '" . $fonction->actifFonc . "'  </strong>";

            $drop = $this->db->query(
                
               "DELETE 
                FROM " . $a . " 
                WHERE " . $c . "=" . $b . ""
            );
            if ($drop == true) {
                
                echo "Suppression effectuée";
                $this->notificationAjout($table, addslashes($securiteS));
            } else {
                echo "Probleme pendant de la suppression";
            }
        }


        $this->db->close();
    }
    

    public function ListeFonction(){

        $query = $this->db->query(
            
           "SELECT * 
            FROM fonction 
            WHERE actifFonc = 'OUI' 
            ORDER BY fonction ASC"
            
        )->result_array();

        if (count($query) >0) {
            
            foreach ($query as $row) {
                
                echo "<option value='".$row["id_fonction"]."'>".$row["fonction"]."</option>";
            }
        }else{
            echo "<option disabled>Aucune fonction actif trouvée</option>";
        }

        $this->db->close();
    }
    


    /* FONCTION */

    

    public function codeEmploye(){ 

        $Code = $this->db->query(
            
           "SELECT * 
            from employe 
            ORDER BY id_employe desc limit 1"
            
        )->row();

        $numero =0;

        if (count($Code)>0) {
            $numero = $Code->codeEmploye;
        }else{
            $numero = 0;
        }

        $numero++;

        while (strlen($numero)<5) {
            $numero = "0".$numero;
        }
        return "EMP".filter_var($numero, FILTER_SANITIZE_NUMBER_INT);
    }

    public function getCodeEmploye(){

        $id_employe = $_POST["id_employe"];

        $employe = $this->db->query(
          "SELECT * 
           FROM employe 
           WHERE id_employe = ".$id_employe.""
        )->row();

        if(count($employe)>0){
            echo $employe->codeEmploye;
        }else{
         echo "Pas de code";
        }
        
        $this->db->close();
    }

    public function ajoutEmploye(){

        $choix = $_POST["choix"];    $numero = $this->codeEmploye();

        $telEmploye = $_POST["telEmploye"];                         $prenomEmploye = addslashes($_POST['prenomEmploye']); 
        $dateNaiss = $_POST["dateNaiss"];                           $nomEmploye = addslashes($_POST['nomEmploye']);
        $cniEmploye = addslashes($_POST['cniEmploye']);             $adresseEmploye = addslashes($_POST['adresseEmploye']); 
        $actifEmploye = $_POST["actifEmploye"];                     $salaire = $_POST["salaire"]; 
        $dateEmbauche = $_POST["dateEmbauche"];                     $actifEmploye = $_POST["actifEmploye"];    
        $table = "employe";                                         $id_fonction = $_POST["id_fonction"]; 

        $securiteA = "<strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a ajouté un employé <strong class='text-info'> '" . $nomEmploye . "' </strong> de cod :  <strong class='text-danger'> '" . $numero . "' </strong> de salaire :  <strong class='text-success'> '" . $salaire . "'</strong>";

        $securiteM = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a modifié un employé  <strong class='text-info'> '" . $nomEmploye . "' </strong> de code :  <strong class='text-danger'> '" . $numero . "' </strong> de salaire :  <strong class='text-success'> '" . $salaire . "'</strong>";

        if ($choix == "ajouter") {

            $requete = $this->db->query(
                
               "SELECT * 
                FROM employe 
                WHERE nomEmploye ='" . $nomEmploye . "' "
                
            )->result_array();

            if (count($requete) > 0) {

                echo "Cet employe '" . $nomEmploye . "' apparaît déjà ";
            }
            else {
                $query1 = $this->db->query(
                    
                   "INSERT 
                    INTO employe 
                    VALUE
                    (
                        '',
                        '".$numero."',
                        '" . $nomEmploye . "',
                        '" . $prenomEmploye . "',
                        CAST('" . $dateNaiss . "' AS DATE),
                        " . $telEmploye . ",
                        '" . $cniEmploye . "',
                        '" . $adresseEmploye . "',
                        CAST('" . $dateEmbauche . "' AS DATE),
                        '" . $id_fonction . "',
                        " . $salaire . ",
                        '".$actifEmploye."'
                    )"
                );
                
                if ($query1 == true) {
                    echo "Insertion éffectuée ";
                    $this->notificationAjout($table, addslashes($securiteA));
                } 
                else {
                    echo "Erreur durant l'insertion";
                }
            }
        } 
        elseif ($choix == "modifier") {
         
            $id_table = $_POST["id_table"];
            
            $requete = $this->db->query(
                
               "SELECT * 
                FROM employe 
                WHERE  nomEmploye ='" . $nomEmploye . "' "
                
            )->result_array();

            if (count($requete) > 0) {

                foreach ($requete as $row) {

                    if ($row["id_employe"] == $id_table) {
                
                        $query1 = $this->db->query(
                            
                           "UPDATE employe 
                            SET 
                                nomEmploye ='" . $nomEmploye . "',
                                prenomEmploye = '" . $prenomEmploye . "', 
                                dateNaiss = CAST('" . $dateNaiss . "' AS DATE),
                                telEmploye = " . $telEmploye . ", 
                                cniEmploye = '" . $cniEmploye . "', 
                                adresseEmploye ='" . $adresseEmploye . "',
                                dateEmbauche = CAST('" . $dateEmbauche . "' AS DATE),
                                id_fonction = '" . $id_fonction . "', 
                                salaire = " . $salaire . ", 
                                actifEmploye='".$actifEmploye."' 

                            WHERE id_employe =" . $id_table . ""
                            
                        );
                        if ($query1 == true) {
                            echo "Modification éffectuée";
                            $this->notificationAjout($table, addslashes($securiteM));
                        } 
                        else {
                            echo "Problème pendant la Modification";
                        }
                    } 
                    else {
                        echo "Cet employe \"" . $nomEmploye . "\" apparaît déjà ";
                    }
                }
            } 
            else {
                $query1 = $this->db->query(
                    
                   "UPDATE employe 
                    set  
                        nomEmploye ='" . $nomEmploye . "',
                        prenomEmploye = '" . $prenomEmploye . "', 
                        dateNaiss = CAST('" . $dateNaiss . "' AS DATE),
                        telEmploye = " . $telEmploye . ", 
                        cniEmploye = '" . $cniEmploye . "', 
                        adresseEmploye ='" . $adresseEmploye . "',
                        dateEmbauche = CAST('" . $dateEmbauche . "' AS DATE),
                        id_fonction = '" . $id_fonction . "', 
                        salaire = " . $salaire . ", 
                        actifEmploye='".$actifEmploye."' 

                    WHERE id_employe =" . $id_table . ""
                    );
                
                if ($query1 == true) {
                    echo "Modification éffectuée";
                    $this->notificationAjout($table, addslashes($securiteM));
                } 
                else {
                    echo "Problème pendant la Modification";
                }
            }
        } 
        else {
            echo "problème se trouvant dans l'ajoutCategorieArticle";
        }
        $this->db->close();
    }

    public function afficheDataEmploye(){

        $query = $this->db->query(
            
           'SELECT * 
            FROM employe 
            ORDER BY nomEmploye ASC'
            
        )->result_array();
        

        $i = 0;

        $date = date('Y-m-d');

        foreach ($query as $row) {

            $dateEm = new DateTime($row['dateEmbauche']);   $dateNaiss = new DateTime($row['dateNaiss']);

            $dateNow = new DateTime($date);                  $diff = $dateNaiss->diff($dateNow); 
            $diffEm = $dateEm->diff($dateNow); 

            $fonction = $this->db->query(
               "SELECT * 
                FROM fonction 
                WHERE id_fonction=".$row['id_fonction'].""
            )->row(); 
            echo  
            "<tr>
                <td onclick=\"new();\">" . $i . "</td>
                <td>" . $row['nomEmploye']. "</td>
                <td>" . $row['prenomEmploye'] . "</td>
                <td><strong class='text-dark'>" . $diff->y."ans"."</strong></td>
                <td>" . $fonction->fonction. "</td>
                <td> <strong class='text-danger'>".number_format($row['salaire'],0,',',' ')."</strong></td>
                <td> " . $row['dateEmbauche'] . "</td>";

                if( (($diffEm->d) >= 364) || (($diffEm->m) >= 12) || (($diffEm->y) >= 1)  ) {
                    echo"<td><strong class='text-success'> $diffEm->y ans</td>";
                }
                else if ( (($diffEm->d) >= 30) || (($diffEm->m) >= 1)  ) {
                    echo"<td><strong class='text-primary'> $diffEm->m mois</td>";
                }
                else{
                    echo"<td><strong class='text-dark'> $diffEm->d jours</td>";
                }
  

                if ($row['actifEmploye'] == 'OUI') {
                    echo"<td class='text-success'><strong><i class='nav-icon fas fa-check-circle'></i></strong></td>";
                }
                if ($row['actifEmploye'] == 'NON') {
                    echo"<td class='text-danger'><strong><i class='nav-icon fas fa-times-circle'></i></strong></td>";
                }echo"
                <td>";
                    if ($this->session->userdata('autoEmploye_voir') == 'true') {
                        echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"VoirEmploye('" . $row['id_employe'] . "','" . $row['codeEmploye'] . "','" . $row['nomEmploye'] . "' ,'" . $row['prenomEmploye'] . "','" . $row['dateNaiss'] . "' ,'" . $row['telEmploye'] . "','" . $row['cniEmploye'] . "' ,'" . $row['adresseEmploye'] . "','" . $row['dateEmbauche'] . "' ,'" . $row['id_fonction'] . "','" . $row['salaire'] . "' ,'".$row['actifEmploye']."')\" class=' ml-2'><i class='nav-icon fas fa-eye text-info'></i></a>";
                    }

                    if ($this->session->userdata('autoEmploye_modification') == 'true') {
                        echo "<a type='button' onclick=\"modiEmploye('" . $row['id_employe'] . "','" . $row['codeEmploye'] . "','" . $row['nomEmploye'] . "' ,'" . $row['prenomEmploye'] . "','" . $row['dateNaiss'] . "' ,'" . $row['telEmploye'] . "','" . $row['cniEmploye'] . "' ,'" . $row['adresseEmploye'] . "','" . $row['dateEmbauche'] . "' ,'" . $row['id_fonction'] . "','" . $row['salaire'] . "' ,'".$row['actifEmploye']."')\" class=' ml-2 '><i class='nav-icon 	fas fa-pen text-success'></i></a>";
                    }

                    if ($this->session->userdata('autoEmploye_suppression') == 'true') {
                        echo "<a type='button' class='ml-2' data-toggle='modal' data-target='#supprimer' table='employe' identifiant='" . $row['id_employe'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_employe\");'><i class='far fas fa-trash text-danger'></i></a>
                </td>
            </tr>"; }
            $i++;
        }
        $this->db->close();
    }

    public function ListeEmploye(){

        $requete = $this->db->query(
            
           "SELECT * 
            FROM employe 
            WHERE actifEmploye = 'OUI' 
            ORDER BY nomEmploye ASC"
            
        )->result_array();

        if (count($requete) >0) {
            
            foreach ($requete as $row) {
                
                echo "<option value='".$row["id_employe"]."'>".$row["nomEmploye"]."::". $row["prenomEmploye"]. "</option>";
            }
        }else{
            echo "<option disabled>Aucun Article actif trouvé</option>";
        }

        $this->db->close();
    }


    public function dropEmploye($a, $b, $c){

        $requete = $this->db->query(
            
           "SELECT * 
            FROM " . $a . " 
            WHERE " . $c . "=" . $b . ""
            
        )->row();

        if (count($requete) > 0) {
        
            $table = $a;

            $securiteS = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé l'employe <strong class='text-info'> '" . $requete->nomEmploye . "' </strong>  de salaire :  <strong class='text-danger'> '" . $requete->salaire . "'  </strong>";

            $drop = $this->db->query(
                
               "DELETE 
                FROM " . $a . " 
                WHERE " . $c . "=" . $b . ""
            );
            if ($drop == true) {
                
                echo "Suppression effectuée";
                $this->notificationAjout($table, addslashes($securiteS));
            } else {
                echo "Probleme pendant de la suppression";
            }
        }


        $this->db->close();
    }

 
}