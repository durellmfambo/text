<?php

    if (!defined('BASEPATH'))

    exit('No direct script access allowed');

    class ModelClient extends CI_Model {

        function __construct() {

            parent::__construct();  $this->load->database('default'); $this->load->library('session');  $this->load->helper('cookie'); $this->load->helper('url');
            
        }

        public function notificationAjout($table,$securite){

            $this->db->query(
               "INSERT 
                INTO notification 
                VALUE
                (
                    '',
                    '".php_uname('n')."',
                    ".$this->session->userdata('id_profil').",
                    '".$table."',
                    '".$securite."',
                    now(),now()
                )"
            );
            $this->db->close();
        }

        public function getUsername($id_profil){

            $query = $this->db->query(
               "SELECT * 
                FROM profil 
                WHERE id_profil=".$id_profil.""
            )->row();

            if (count($query)>0) {
                
                return $query->identifiant;
            }
            $this->db->close();
        }

        

        
        /* CLIENT */

        public function NewCodeClient(){ 

            $getCodeClient = $this->db->query(
               "SELECT * 
                FROM client 
                ORDER BY id_client desc limit 1"
            )->row();
            $codeClient =0;

            if (count($getCodeClient)>0) {
                $codeClient = $getCodeClient->codeClient;
            }else{
                $codeClient = 0;
            }

            $codeClient++;

            while (strlen($codeClient)<5) {
                $codeClient = "0".$codeClient;
            }
            return "CL".filter_var($codeClient, FILTER_SANITIZE_NUMBER_INT);
        }


        public function ajoutClient(){

            $choix = $_POST["choix"];    $codeClient = $this->NewCodeClient();

            $nomClient = $_POST["nomClient"];  $adresseClient = $_POST["adresseClient"];

            $telClient = $_POST["telClient"];   $soldeClient = preg_replace('/\s/', '', $_POST["soldeClient"]);

            $commentaireClient = $_POST['commentaireClient']; $dateClient = $_POST["dateClient"];

            $actifClient = $_POST["actifClient"];   $table = "client";

            $notification = "<strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a ajouté le Client <strong class='text-info'> '" . $nomClient . "' </strong> de solde :  <strong class='text-danger'> '" . $soldeClient . "' </strong> de Actif :  <strong class='text-success'> '" . $actifClient . "'</strong>";

            $notification1 = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>" . " a modifié le Client  <strong class='text-info'> '" . $nomClient . "' </strong> de solde :  <strong class='text-danger'> '" . $soldeClient . "' </strong> de Actif :  <strong class='text-success'> '" . $actifClient . "'</strong>";

            if ($choix == "ajouter") {
                
                $requeteTelClient = $this->db->query(
                   "SELECT * 
                    FROM client 
                    WHERE telClient ='" . $telClient . "' "
                )->result_array();

                $requeteNomClient = $this->db->query(
                   "SELECT * 
                    FROM client 
                    WHERE nomClient ='" . $nomClient . "' "
                )->result_array();

                if (count($requeteTelClient) > 0) {

                    echo "Ce contact '" . $telClient . "' apparaît déjà ";
                }
                elseif (count($requeteNomClient) > 0) {

                    echo "Ce client '" . $nomClient . "' apparaît déjà ";
                }
                else {
                    $query1 = $this->db->query(
                       "INSERT 
                        INTO client 
                        VALUE
                        (
                            '',
                            '".$codeClient."',
                            CAST('" . $dateClient . "' AS DATE),
                            '" . $nomClient . "',
                            '" . $adresseClient . "',
                            " . $telClient . ",
                            " . $soldeClient . ",
                            '" . $commentaireClient . "',
                            '".$actifClient."'
                        ) "
                    );
                    
                    if ($query1 == true) {
                        echo "Insertion éffectuée";
                        $this->notificationAjout($table, addslashes($notification));
                    } 
                    else {
                        echo "Erreur durant l'insertion";
                    }
                }
            } 
            elseif ($choix == "modifier") {
            
                $id_table  = $_POST["id_table"];
                
                $requete = $this->db->query(
                   "SELECT * 
                    FROM client 
                    WHERE  nomClient ='" . $nomClient . "' "
                )->result_array();

                if (count($requete) > 0) {

                    foreach ($requete as $row) {

                        if ($row["id_client"] == $id_table ) {
                    
                            $query1 = $this->db->query(
                               "UPDATE client 
                                SET 
                                    telClient ='" . $telClient . "', 
                                    adresseClient ='" . $adresseClient . "', 
                                    nomClient ='" . $nomClient . "',
                                    soldeClient = '" . $soldeClient . "', 
                                    commentaireClient = '" . $commentaireClient . "', 
                                    dateClient = CAST('" . $dateClient . "' AS DATE),
                                    actifClient='".$actifClient."' 
                                WHERE id_client  =" . $id_table  . ""
                            );
                            if ($query1 == true) {
                                echo "Modification éffectuée";
                                $this->notificationAjout($table, addslashes($notification1));
                            } 
                            else {
                                echo "Problème pendant la Modification";
                            }
                        } 
                        else {
                            echo "Ce client \"" . $nomClient . "\" apparaît déjà ";
                        }
                    }
                } 
                else {
                    $query1 = $this->db->query(
                       "UPDATE client 
                        SET 
                            telClient='" . $telClient . "', 
                            adresseClient ='" . $adresseClient . "', 
                            nomClient ='" . $nomClient . "', 
                            commentaireClient = '" . $commentaireClient . "' ,
                            soldeClient = '" . $soldeClient . "', 
                            dateClient = CAST('" . $dateClient . "' AS DATE) ,
                            actifClient='".$actifClient."'
                        WHERE id_client  =" . $id_table  . ""
                    );
                    
                    if ($query1 == true) {
                        echo "Modification éffectuée";
                        $this->notificationAjout($table, addslashes($notification1));
                    } 
                    else {
                        echo "Problème pendant la Modification";
                    }
                }
            } 
            else {
                echo "problème se trouvant dans l'ajoutClient";
            }
            $this->db->close();
        }


        public function afficheDataClient(){

            $query1 = $this->db->query(
               'SELECT * 
                FROM client 
                ORDER BY nomClient ASC'
            )->result_array();
            $compteur = 0;

            foreach ($query1 as $row) {
            
                echo 
                "<tr>
                    <td onclick=\"new();\">" . $compteur . "</td>
                    <td>" . $row['codeClient'] . "</td>
                    <td>" . $row['nomClient'] . "</td>
                    <td>" . $row['adresseClient'] . "</td>
                    <td> " . $row['telClient'] . "</td>
                    <td> <strong class='text-danger'>".number_format($row['soldeClient'],0,',',' ')."</strong></td>
                    <td> " . $row['dateClient'] . "</td>";

                    if ($row['actifClient'] == 'OUI') {
                        echo"<td class='text-success'><strong><i class='nav-icon fas fa-user-check'></i></strong></td>";
                    }
                    if ($row['actifClient'] == 'NON') {
                        echo"<td class='text-danger'><strong><i class='nav-icon fas fa-user-times'></i></strong></td>";
                    }echo"
                    <td>";
                        if ($this->session->userdata('autoClient_voir') == 'true') {
                            echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"voirClient('" . $row['id_client'] . "','" . $row['codeClient'] . "','" . $row['nomClient'] . "','" . $row['adresseClient'] . "','" . $row['telClient'] . "','" . $row['soldeClient'] . "','" . addslashes($row['commentaireClient']) . "','" . $row['dateClient']  . "','".$row['actifClient']."')\" class=' ml-2 '><i class='nav-icon fas fa-eye text-info'></i></a>";
                        }

                        if ($this->session->userdata('autoClient_modification') == 'true') {
                            echo "<a type='button' onclick=\"modiClient('" . $row['id_client'] . "','" . $row['codeClient'] . "','" . $row['nomClient'] . "','" . $row['adresseClient'] . "','" . $row['telClient'] . "','" . $row['soldeClient'] . "','" . addslashes($row['commentaireClient']) . "','" . $row['dateClient'] . "','".$row['actifClient']."')\" class=' ml-2'><i class='nav-icon 	fas fa-pen text-success'></i></a>";
                        }

                        if ($this->session->userdata('autoClient_suppression') == 'true') {
                            echo "<a type='button' class='ml-2 ' data-toggle='modal' data-target='#supprimer' table='client' identifiant='" . $row['id_client'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_client\");'><i class='far fas fa-trash text-danger'></i></a>
                    </td>
                </tr>"; }
                $compteur++;
            }
            $this->db->close();
        }


        public function dropClient($a, $b, $c){

            $Client = $this->db->query("SELECT * from " . $a . " where " . $c . "=" . $b . "")->row();

            if (count($Client) > 0) {
                
                $table = $a;

                $securiteS = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a supprimé le client <strong class='text-info'> '" . $Client->nomClient . "' </strong> de solde :  <strong class='text-danger'> '" . $Client->soldeClient . "'  </strong>";

                $drop = $this->db->query("delete from " . $a . " where " . $c . "=" . $b . "");

                if ($drop == true) {
                    
                    echo "Suppression effectuée";
                    $this->notificationAjout($table, addslashes($securiteS));
                } else {
                    echo "Pas supprimé";
                }
            }


            $this->db->close();
        }


        public function ListeClient(){

            $query = $this->db->query("SELECT * FROM client WHERE actifClient = 'OUI' ORDER BY nomClient ASC")->result_array();
            if (count($query) >0) {
                
                foreach ($query as $row) {
                    
                    echo "<option value='".$row["id_client"]."'>".$row["nomClient"]."</option>";
                }
            }else{
                echo "<option disabled>Aucun client actif trouvé</option>";
            }

            $this->db->close();
        }

        
        public function nbreActifClient(){
            $query = $this->db->query("SELECT COUNT(*) AS nombre_client FROM client WHERE actifClient = 'OUI'")->row_array();
            echo $query['nombre_client'];
        }

        public function nbreNonActifClient(){
            $query = $this->db->query("SELECT COUNT(*) AS nombre_client FROM client WHERE actifClient = 'NON'")->row_array();
            echo $query['nombre_client'];
        }



        public function codeFacture(){ 

            $requete = $this->db->query("SELECT * from facture_client order by id_facture desc limit 1")->row();
            $code =0;
            
            if (count($requete)>0) {
            
                $code = $requete->codeFact;

            }else{ 
                $code = 0;
            }
            
            $code++; 
            while (strlen($code)<4) { 
                $code = "0".$code;
            }

            return "FAC".filter_var($code, FILTER_SANITIZE_NUMBER_INT);
        }


        public function CodeClient(){

            $id_client = $_POST["id_client"];

            $Client = $this->db->query("SELECT * from client where id_client = ".$id_client."")->row();

            if(count($Client)>0){
                echo $Client->codeClient;
            }else{
                echo "Pas de code";
            }
            
            $this->db->close();
        }


        public function AdresseClient(){

            $id_client = $_POST["id_client"];

            $Client = $this->db->query("SELECT * from client where id_client = ".$id_client."")->row();

            if(count($Client)>0){
                echo $Client->adresseClient;
            }else{
            echo "Pas d'adresse";
            }
            
            $this->db->close();
        } 


        public function TelClient(){
            $id_client = $_POST["id_client"];

            $Client = $this->db->query("SELECT * from client where id_client = ".$id_client."")->row();

            if(count($Client)>0){
                echo $Client->telClient;
            }else{
            echo "Pas de numero de telephone";
            }
            
            $this->db->close();
        }


        public function getClient($id){
            $requete= $this->db->query("SELECT * from client where id_client = ".$id."")->row();

            if (count($requete)>0) {
                
                return $requete->nomClient;
            }
            $this->db->close();
        }



        
        /* FACTURE CLIENT */


        
        public function ajoutFacture(){

            $codeFact = $this->codeFacture();                          $id_client = $_POST['id_client'];
            $codeClient = $_POST['codeClient'];                       $adresseClient = $_POST['adresseClient'];
            $telClient = $_POST['telClient'];                   
            $dateFact= $_POST['dateFact'];                             $nbreLignes = $_POST["nbreLignes"];
            $valideFact = $_POST['valideFact'];                         $choix = $_POST["choix"];

            $id_article = json_decode($_POST['id_article']);            $referenceCom = json_decode($_POST['referenceCom']);
            $prixVenteCom = json_decode($_POST['prixVenteCom']);              $typeCom = json_decode($_POST['typeCom']);
            $id_facture = json_decode($_POST['id_facture']);             $qtiteCom = json_decode($_POST['qtiteCom']);
            
            
            
            

            $table = "facture_client"; 

            $securiteA =  " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a ajouté la facture  de N° <strong class='text-primary'>' " .$codeFact. " '</strong> du client <strong class='text-info'>' " .$this->getClient($id_client). " '</strong>  Valide :: <strong class='text-info'>' " .$valideFact. " '</strong>  ";

            $securiteM =  " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>" . " a modifié la facture de N° <strong class='text-primary'>' " .$codeFact. " '</strong>  du client <strong class='text-info'>' " .$this->getClient($id_client). " '</strong>  Valide :: <strong class='text-info'>' " .$valideFact. " '</strong>  ";


            if ($choix == "ajouter") {
                
        
                $i = 1;

                while ( $i<= $nbreLignes) {

                    $query = $this->db->query(" INSERT into facture_client value('','".$codeFact."',".$id_client.",CAST('". $dateFact."' AS DATE), ".$id_article[$i].",'".$referenceCom[$i]."',".intval(preg_replace('/\s/','', $prixVenteCom[$i])).",'".$qtiteCom[$i]."', '".$typeCom[$i]."','".$valideFact."','".$codeClient."','".$adresseClient."','".$telClient."')");

                    $i++; 
                }

                if ($query == true) {
                    
                    echo "Insertion éffectuée";
                    $this->notificationAjout($table,addslashes($securiteA));
                    
                }else{
                    echo "probleme pendant l'insertion";
                }

            }elseif ($choix == "modifier") {
                
                $i = 1;
                while ( $i<= $nbreLignes) { 

            $query = $this->db->query("UPDATE facture_client set id_client=".$id_client.", dateFact = CAST('". $dateFact."' AS DATE), id_article =".$id_article[$i].", qtiteCom =".$qtiteCom[$i].", prixVenteCom =".intval(preg_replace('/\s/','', $prixVenteCom[$i])).", referenceCom = '".addslashes($referenceCom[$i])."', typeCom='".$typeCom[$i]."',valideFact='".$valideFact."',codeClient='".$codeClient."',adresseClient='".$adresseClient."',telClient='".$telClient."' where id_facture =".$id_facture[$i]."");
            $i++; 
            }

                if ($query == true) {
                    
                    echo "Modification éffectuée";

                    $this->notificationAjout($table,addslashes($securiteM));

                }else{
                    echo "probleme pendant l'insertion";
                }

            }else{
                echo "Probleme de connexion";
            }

            $this->db->close();
        }


        public function afficheDataFacture(){

            if (isset($_POST["dateDebut"]) && isset($_POST["dateFin"]) && isset($_POST["id_nom"])) {
                
                $dateDebut = $_POST['dateDebut'];  $dateFin = $_POST['dateFin'];  $id_nom = $_POST['id_nom'];
                
                if (!empty($dateFin) && !empty($dateDebut) && isset($_POST["id_nom"])) {

                    $requete = $this->db->query("SELECT  * from facture_client where  id_client = '".$id_nom."' and dateFact between '".$dateDebut."' and '".$dateFin."'  order by dateFact DESC")->result_array();

                    if ($id_nom == 'ALL') {
                        
                        $requete = $this->db->query("SELECT  * from facture_client where  dateFact between '".$dateDebut."' and '".$dateFin."'  order by dateFact DESC")->result_array();
                    
                    }else {
                        
                        $requete = $this->db->query("SELECT  * from facture_client where id_client = '".$id_nom."' and  dateFact between '".$dateDebut."' and '".$dateFin."' order by dateFact DESC ")->result_array();
                        
                    }	
                
                }else{
                    
                    $requete = $this->db->query("SELECT  * from facture_client  order by id_facture DESC")->result_array();    
                }		
                
            }else{ 
                $requete = $this->db->query("SELECT * from facture_client order by id_facture desc")->result_array();
            }	
            
            if (count($requete) >0 ) {
                
                $i = 0;

                foreach ($requete as $row) {

                    $getArticle = $this->db->query("select * from article where id_article =".$row['id_article']."")->row();
                
                    $getClient = $this->db->query("select * from client where id_client=".$row['id_client']."")->row();
                    
                    echo 

                "<tr>
                        <td onclick=\"new();\">" .$i. "</td>
                        <td>".$row['codeFact']."</td> 
                        <td>".$getArticle->nomArticle."</td> 
                        <td> ".$row['referenceCom']."</td>
                        <td> <strong class='text-danger'>".number_format($row['prixVenteCom'],0,',',' ')."</strong></td>
                        <td> <strong class='text-dark'>".number_format($row['qtiteCom'],0,',',' ')."</strong></td>
                        <td> <strong class='text-danger'>".number_format($row['qtiteCom'] *$row['prixVenteCom'],0,',',' ')."</strong></td>
                        <td> ".$row['dateFact']."</td>

                        <td>"; 

                        $validation = $this->db->query("SELECT valideFact from facture_client where codeFact = '".$row['codeFact']."' and valideFact= 'oui' limit 1")->row(); 
        
                        
                        if (count($validation) >0 ) {
                            echo"<td'><a type='button'  class=' btn btn-sm' onclick='printFacture(\"".$row['codeFact']."\",\"".$getClient->nomClient."\",\"".$row['dateFact']."\",\"".$row['codeClient']."\",\"".$row['adresseClient']."\",\"".$row['telClient']."\", \"".number_format($this->MontantFacture($row['codeFact']),0,',',' ')." F\")'><i class='nav-icon fas fa-bell text-dark'></i></a></td>";
                        }echo"

                        
                        <td>";
                            if ($this->session->userdata('autoArticle_voir') == 'true') {
                                echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"voirFacture('"  . $row['id_facture'] . "','" . $row['codeFact'] . "','" . $row['id_client'] . "','" . $row['dateFact'] . "','" . $row['id_article'] . "','" . $row['referenceCom'] . "','" . $row['prixVenteCom'] . "','" . $row['qtiteCom'] . "','" . $row['typeCom'] . "','" . $row['valideFact'] . "','" . $row['codeClient'] . "','" . $row['adresseClient'] . "','" . $row['telClient'] . "')\" class=' ml-1'><i class='nav-icon  fas fa-eye text-info'></i></a>";
                            }

                            if ($this->session->userdata('autoArticle_modification') == 'true') {
                                echo "<a type='button' onclick=\"modiFacture('"  . $row['id_facture'] . "','" . $row['codeFact'] . "','" . $row['id_client'] . "','" . $row['dateFact'] . "','" . $row['valideFact'] . "','" . $row['codeClient'] . "','" . $row['adresseClient'] . "','" . $row['telClient'] . "')\" class=' ml-2'><i class='nav-icon fas fa-pencil-alt text-success'></i></a>";
                            } 

                            if ($this->session->userdata('autoArticle_suppression') == 'true') {
                                echo "<a type='button' class='ml-2' data-toggle='modal' data-target='#supprimer' table='facture_client' identifiant='" . $row['id_facture'] . "' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_facture\");'><i class='far fas fa-trash text-danger'></i></a>
                        </td>  
                    </tr>   ";}
                    $i++;
                }
            }
            $this->db->close();
        }


        public function ListeFactureClient(){

            $query = $this->db->query("

                SELECT * 
                FROM facture_client 
                WHERE valideFact = 'OUI' 
                ORDER BY id_facture DESC
                
            ")->result_array();

            if (count($query) >0) {
                
                foreach ($query as $row) {
                    
                    echo "<option value='".$row["codeFact"]."'>".$row["codeFact"]."</option>";
                }
            }else{
                echo "<option disabled>Aucune facture trouvée</option>";
            }

            $this->db->close();
        }

        public function MontantFacture($codeFact){

            $requete = $this->db->query('SELECT * from facture_client where codeFact = "'.$codeFact.'"')->result_array();
            $somme = 0;

            foreach ($requete as $row) {
                
                $total = $row["prixVenteCom"]*$row["qtiteCom"];
                $somme = $somme + $total;
            }
            return $somme;

            $this->db->close();
        }


        public function modifieDataFacture(){

            $codeFact = $_POST["codeFact"];
            $Commande = $this->db->query("SELECT * from facture_client where codeFact = '".$codeFact."' ")->result_array();
            $i=1;

            foreach ($Commande as $mod) {
                
                echo 
                '<div class="row">

                        <div class="col-md-1">
                            <div class="form-group">
                                <label>N°</label>
                                <input type="text" style="border-radius:20px;"class="form-control nbr'.$i.'" placeholder="" value = "'.$i.'" disabled="true" >
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Article</label>
                                <select style="border-radius:20px;" class="id_article'.$i.' form-control" onchange="getMontantArticle($(\'.id_article'.$i.'\').val(),\'montantCom'.$i.'\');getReferenceArticle($(\'.id_article'.$i.'\').val(),\'referenceCom'.$i.'\');">';
                                    $getArticle = $this->db->query("SELECT * from article where id_article = ".$mod['id_article']."")->row(); echo"
                                    <option value='".$mod['id_article']."'>".$getArticle->nomArticle."</option>";
                                    $this->ModelArticle->ListeArticle();echo '
                                </select>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group ">
                                <label>Référence</label>
                                <input type="text" style="border-radius:20px;" class="form-control referenceCom'.$i.'" disabled = "true" value="'.addslashes($mod["referenceCom"]).' ">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <label>Montant</label>
                            <input type="text" style="border-radius:20px;" class="form-control montantCom'.$i.'" disabled = "true" placeholder=" " value="'.$mod["montantCom"].'" onkeypress="chiffres(event);" >
                        </div>

                        <div class="col-md-1">
                            <label>Qtite</label>
                            <input type="text" style="border-radius:20px;" class="form-control qtiteCom'.$i.'" placeholder=" " value="'.$mod["qtiteCom"].'"  onkeypress="chiffres(event);">
                        </div> 
                        

                        <input type="hidden" class="form-control id_facture'.$i.'"  placeholder=" en FCFA" value="'.$mod["id_facture"].'" disabled="true" onkeypress="chiffres(event);">

                        <div class="col-md-1">
                            <div class="form-group">
                                <label>Fermer</label>
                                <select style="border-radius:20px;" class="typeCom'.$i.' form-control" onchange="activePrix(\'.typeCom'.$i.'\',\'.montantCom'.$i.'\');">';
                                    if ($mod['typeCom'] == 'oui') {
                                        echo '
                                        <option>oui</option>
                                        <option>non</option>';
                                    }
                                    else {
                                        echo '
                                        <option>non</option>
                                        <option>oui</option>';
                                    }echo '
                                </select>
                            </div>
                        </div>
                    </div>
                    <hr>';
                $i++;
            }
            $i = $i-1;

            echo '<input type="hidden" class="form-control compteur"  placeholder=" en FCFA" value="'.$i.'" disabled="true" onkeypress="chiffres(event);">';

            $this->db->close();
        }

        public function PrintFacture(){

            $codeFact = $_POST["codeFact"]; $c= 0;
            $requete = $this->db->query('SELECT * from facture_client where codeFact ="'.$codeFact.'" order by dateFact desc')->result_array();
            
            foreach ($requete as $row) { echo 
            
                "<tr style='border:none; text-align:center;font-size: 16px;padding:0px;'> ";

                    $getArticle = $this->db->query("SELECT * FROM article where id_article = ".$row['id_article']."")->row(); echo"
                    
                    <td colspan='2' style='border: none; text-align:center;padding:0px;'>".$getArticle->nomArticle."</td>";  echo"
        
                    <td colspan='2' style='border:none; text-align:center;padding:0px;'>".$row['referenceCom']."</td>

                    <td style='border: none; text-align:center;padding:0px;'><strong class='text-danger'>".number_format($row['prixVenteCom'],0,',',' ')."</td>
                    
                    <td  style='border:none; text-align:center;padding:0px;'><strong class='text-dark'>".$row['qtiteCom']."</td>
                
                    <td colspan='2' style='border:none; text-align:center;padding:0px;'><strong class='text-danger'>".number_format($row['prixVenteCom']*$row['qtiteCom'],0,',',' ')."</td>";
                
                    
                $c++;
            }

            $this->db->close();
        }


        public function nbreCommandeClient(){

            $query = $this->db->query(

                "SELECT COUNT(DISTINCT codeCom) AS nbre 
                FROM commande_client  "

                )->row_array();

            echo $query['nbre'];
        }


        public function nbrePrintCommandeClient(){

            $query = $this->db->query(

               "SELECT COUNT(DISTINCT codeCom) AS nbr 
                FROM commande_client 
                WHERE valideCom = 'oui'"
                
            )->row_array();

            echo $query['nbr'];
        }

        public function nbreNonPrintCommandeClient(){

            $query = $this->db->query(

              "SELECT COUNT(DISTINCT codeCom) AS nbr 
               FROM commande_client 
               WHERE valideCom = 'non'"
               
            )->row_array();

            echo $query['nbr'];
        }

        public function clientPlusUtilise(){

            $query = $this->db->query(

               "SELECT c.id_client, c.nomClient, COUNT(DISTINCT fc.codeFact) AS nb_factures
                FROM client c
                JOIN facture_client fc ON c.id_client = fc.id_client
                GROUP BY c.id_client, c.nomClient
                ORDER BY nb_factures DESC"

            )->row_array(); 

            if (!empty($query)) {

                echo $query['nomClient'];
            } else {

                echo "Aucun client trouvé.";
            }
        }


        public function nbrClientPlusUtilise(){

            $query = $this->db->query(

               "SELECT c.id_client, c.nomClient, COUNT(DISTINCT fc.codeFact) AS nb_factures
                FROM client c
                JOIN facture_client fc ON c.id_client = fc.id_client
                GROUP BY c.id_client, c.nomClient
                ORDER BY nb_factures DESC"

            )->row_array(); 

            if (!empty($query)) {

                echo $query['nb_factures'];
            } else {

                echo "Aucune.";
            }
            
        }


        public function clientMoinsUtilise(){

            $query = $this->db->query(

               "SELECT c.id_client, c.nomClient, COUNT(DISTINCT fc.codeFact) AS nb_factures
                FROM client c
                JOIN facture_client fc ON c.id_client = fc.id_client
                GROUP BY c.id_client, c.nomClient
                ORDER BY nb_factures ASC"

            )->row_array(); 

            if (!empty($query)) {

                echo $query['nomClient'];
            } else {

                echo "Aucun client trouvé.";
            }
        }


        public function nbrClientMoinsUtilise(){

            $query = $this->db->query(

               "SELECT c.id_client, c.nomClient, COUNT(DISTINCT fc.codeFact) AS nb_factures
                FROM client c
                JOIN facture_client fc ON c.id_client = fc.id_client
                GROUP BY c.id_client, c.nomClient
                ORDER BY nb_factures ASC"

            )->row_array(); 

            if (!empty($query)) {

                echo $query['nb_factures'];
            } else {

                echo "Aucune";
            }

        }


        public function clientMilieu(){

            $query = $this->db->query(

               "SELECT c.id_client, c.nomClient, COUNT(DISTINCT fc.codeFact) AS nb_factures
                FROM client c
                JOIN facture_client fc ON c.id_client = fc.id_client
                GROUP BY c.id_client, c.nomClient
                ORDER BY nb_factures ASC" 

            )->result_array(); 

            if (!empty($query)) {
                $count = count($query);
                $middleIndex = floor($count / 2); 

                $clientMilieu = $query[$middleIndex];

                echo  $clientMilieu['nomClient'] ;
            } else {
                echo "Aucun client trouvé.";
            }
        }


        public function nbrClientMilieu(){

            $query = $this->db->query(

               "SELECT c.id_client, c.nomClient, COUNT(DISTINCT fc.codeFact) AS nb_factures
                FROM client c
                JOIN facture_client fc ON c.id_client = fc.id_client
                GROUP BY c.id_client, c.nomClient
                ORDER BY nb_factures ASC" 

            )->result_array(); 

            if (!empty($query)) {
                $count = count($query);
                $middleIndex = floor($count / 2); 

                $clientMilieu = $query[$middleIndex];

                echo $clientMilieu['nb_factures'];
            } else {
                echo "Aucune.";
            }
        }



    }
?>