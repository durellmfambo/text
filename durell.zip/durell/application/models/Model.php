<?php

    if (!defined('BASEPATH'))

    exit('No direct script access allowed');

    class Model extends CI_Model {


        function __construct() {

            parent::__construct(); $this->load->library('session'); $this->load->helper('cookie');  $this->load->helper('url');
        }

            
        public function notificationAjout($table,$securite){

            $this->db->query(

               "INSERT 
                INTO notification 
                value('','".php_uname('n')."',".$this->session->userdata('id_profil').",'".$table."','".$securite."',now(),now())"
                
            );

            $this->db->close();
        }

        public function getUsername($id_profil){

            $query = $this->db->query(
                
               "SELECT * 
                FROM profil 
                WHERE id_profil=".$id_profil." "
                
            )->row();

            if (count($query)>0) {
                
                return $query->identifiant;
            }

            $this->db->close();
        }


        public function login(){

            $password = $_POST["password"]; $login = $_POST["login"];

            if(!filter_var($login,FILTER_VALIDATE_EMAIL)){
                $this->getConnexion(sha1($password),$login,"identifiant");
            }else{
                $this->getConnexion(sha1($password),$login,"email");
            }

            $this->db->close();
        }
        

        public function getConnexion($password,$login,$email){

            $requet = $this->db->query(
                
               "SELECT * 
                FROM profil 
                WHERE password='".$password."' and ".$email."='".$login."'AND dispoUser ='OUI' "
                
            )->result_array();

            $table = "profil";      $date_notif = date("d-m-Y");
    
            if (count($requet) > 0) {
                
                echo "Connexion réussie";
                foreach ($requet as $row) {
                    
                    $this->session->set_userdata("identifiant", $row["identifiant"]);
                    $this->session->set_userdata("id_profil", $row["id_profil"]);
                    $this->session->set_userdata("type_compte", $row["type"]);
                
                    $securite = "<strong class='text-dark'>". $this->getUsername($this->session->userdata('id_profil'))."  </strong>"."  </strong> s'est connecté le <strong>".$date_notif."  </strong>";

                    $this->notificationAjout($table,addslashes($securite));

                    
                    // privilege gestion article
                    $requete = $this->db->query(
                        
                       "SELECT * 
                        FROM auto_article 
                        WHERE id_profile=".$row["id_profil"].""
                        
                    )->row();

                    if (count($requete)>0) {
                        
                        $this->session->set_userdata("autoArticle_modification", $requete->modification);
                        $this->session->set_userdata("autoArticle_suppression", $requete->suppression);
                        $this->session->set_userdata("autoArticle_ajout", $requete->ajout);
                        $this->session->set_userdata("autoArticle_voir", $requete->voir);
                    }


                    // privilege gestion stock
                    $requete = $this->db->query(
                        
                       "SELECT * 
                        FROM auto_stock 
                        WHERE id_profile=".$row["id_profil"].""
                    
                    )->row();

                    if (count($requete)>0) {
                        
                        $this->session->set_userdata("autoStock_modification", $requete->modification);
                        $this->session->set_userdata("autoStock_suppression", $requete->suppression);
                        $this->session->set_userdata("autoStock_ajout", $requete->ajout);
                        $this->session->set_userdata("autoStock_voir", $requete->voir);
                    }




                    // privilege gestion fournisseur
                    $requete = $this->db->query(

                        "SELECT * 
                        FROM auto_fournisseur 
                        WHERE id_profile=".$row["id_profil"].""
                        
                    )->row();

                    if (count($requete)>0) {
                        
                        $this->session->set_userdata("autoFournisseur_modification", $requete->modification);
                        $this->session->set_userdata("autoFournisseur_suppression", $requete->suppression);
                        $this->session->set_userdata("autoFournisseur_ajout", $requete->ajout);
                        $this->session->set_userdata("autoFournisseur_voir", $requete->voir);
                    }


                    // privilege gestion client
                    $requete = $this->db->query(
                        
                       "SELECT * 
                        FROM auto_client 
                        WHERE id_profile=".$row["id_profil"].""
                        
                    )->row();

                    if (count($requete)>0) {
                        
                        $this->session->set_userdata("autoClient_modification", $requete->modification);
                        $this->session->set_userdata("autoClient_suppression", $requete->suppression);
                        $this->session->set_userdata("autoClient_ajout", $requete->ajout);
                        $this->session->set_userdata("autoClient_voir", $requete->voir);
                    }


                    // privilege gestion employe
                    $requete = $this->db->query(
                        
                       "SELECT * 
                        FROM auto_employe 
                        WHERE id_profile=".$row["id_profil"].""
                        
                    )->row();

                    if (count($requete)>0) {
                        
                        $this->session->set_userdata("autoEmploye_modification", $requete->modification);
                        $this->session->set_userdata("autoEmploye_suppression", $requete->suppression);
                        $this->session->set_userdata("autoEmploye_ajout", $requete->ajout);
                        $this->session->set_userdata("autoEmploye_voir", $requete->voir);
                    }

                    

                    

                    $requete = $this->db->query(
                        
                       "SELECT * 
                        FROM auto_users 
                        WHERE id_profile=".$row["id_profil"].""
                        
                    )->row();

                    if (count($requete)>0) {
                        
                        $this->session->set_userdata("autoUser_modification", $requete->modification);
                        $this->session->set_userdata("autoUser_suppression", $requete->suppression);
                        $this->session->set_userdata("autoUser_ajout", $requete->ajout);
                        $this->session->set_userdata("autoUser_voir", $requete->voir);
                    }
                }
                
            }else{
                echo "ERROR";
            }

            $this->db->close();
        }

    
    }
?>