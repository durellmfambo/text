<?php

if (!defined('BASEPATH'))
exit('No direct script access allowed');

class ModelUser extends CI_Model { 

  function __construct() {
    parent::__construct();
    $this->load->database('default');
    $this->load->library('session');
    
    $this->load->helper('cookie');
    $this->load->helper('url');
      
  }


  public function notificationAjout($table,$securite){

    $this->db->query(
     "INSERT 
      INTO notification 
      VALUE
      ( 
        '',
        '".php_uname('n')."',
        ".$this->session->userdata('id_profil').",
        '".$table."',
        '".$securite."',
        now(),now()
      )"
    );
    $this->db->close();
  }
  
  public function getUsername($id_profil){

    $query = $this->db->query(
     "SELECT * 
      FROM profil 
      WHERE id_profil=".$id_profil.""
    )->row();

    if (count($query)>0) {
      
      return $query->identifiant;
    }
    $this->db->close();
  }

  public function ajoutAutorisation(){

    $modification = $_POST['modification'];           $ajout = $_POST['ajout'];
    $voir = $_POST['voir'];                            $suppression = $_POST['suppression'];
    $table = $_POST['table'];

    $identifiant = $_POST['identifiant'];          $password = $_POST['password'];

    $query = $this->db->query(
     "SELECT * 
      FROM profil 
      WHERE identifiant = '".$identifiant."' and password = '".sha1($password)."'"
    )->row();

    $query1 = $this->db->query(
     "INSERT 
      INTO ".$table." 
      VALUE
      (
        '',
        ".$query->id_profil.",
        '".$ajout."',
        '".$voir."',
        '".$suppression."',
        '".$modification."'
      )"
    );

    if ($query1==0) {
      echo "Autorisarion éffectuée";
    }else{
      echo "éffectuée";
    }
  }

  public function ajoutUtilisateur(){

    $type = $_POST['type'];                   $commentaire = $_POST['commentaire'];
    $id_profil = $_POST['id_profil'];        $identifiant = $_POST['identifiant'];
    $password = $_POST['password'];            $choix = $_POST['choix']; 
    $dispoUser = $_POST['dispoUser'];           $table = "profil";

    $securiteA =  " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>"." a ajouté un  utilisateur <strong class='text-primary'> '".$identifiant."' </strong>";

    if ($choix == 'ajouter') {
      
      $requete = $this->db->query(
       "SELECT * 
        FROM profil 
        WHERE identifiant = '".$identifiant."' and password = '".sha1($password)."'"
      )->row();
      
      if (count($requete)>0) {
          
        echo "Cet utilisateur '".$identifiant."' apparait dejà";
      }else{
        $query = $this->db->query(
         "INSERT 
          INTO profil 
          VALUE
          (
            '',
            '".$type."',
            '".$identifiant."',
            '',
            '".sha1($password)."',
            '".$commentaire."',
            '".$dispoUser."'
          )"
        );
       
        if ($query == true) {
          echo "Insertion éffectuée";
          $this->notificationAjout($table, addslashes($securiteA));
        }else{
          echo "problème de connexion";
        }
      }
    }
    elseif ($choix === 'modAutorisation') {
        
      $this->updateAutorisation();
    }else{
      echo "problème de connexion";
    }
      
  }

  public function updateAutorisation(){

    $modification = $_POST['modification'];       $suppression = $_POST['suppression'];
    $table = $_POST['table'];                     $id_profil = $_POST['id_profil']; 
     $ajout = $_POST['ajout'];                    $voir = $_POST['voir'];

    
    $query = $this->db->query(
     "SELECT * 
      FROM ".$table." 
      WHERE id_profile = ".$id_profil.""
    )->row();
    
    if (count($query)>0) {
        
      $requete = $this->db->query(
       "UPDATE  ".$table." 
        SET 
          ajout = '".$ajout."',
          voir = '".$voir."',
          suppression = '".$suppression."', 
          modification ='".$modification."' 

        WHERE id_profile = ".$id_profil."");
      
      if ($requete == true) {
        echo $table;
      }else{
        echo "pas éffectuée";
      }
    }else{

      $this->db->query(
       "INSERT 
        INTO ".$table." 
        VALUE
        (
          '',
          ".$id_profil.",
          '".$ajout."',
          '".$voir."',
          '".$suppression."',
          '".$modification."'
        )"
      );
    }
      
  }

  public function modifUtilisateur(){

    $id_profil = $_POST['id_profil'];            $identifiant = $_POST['identifiant'];
    $password = $_POST['password'];              $table = "profil"; 

    $securiteM =  " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>"." a ajouté un nouveau utilisateur <strong class='text-primary'> '".$identifiant."'  </strong>";

    $query = $this->db->query(
     "UPDATE profil 
      SET 
        password ='".sha1($password)."', 
        identifiant ='".$identifiant."' 
        
      WHERE id_profil=".$id_profil.""
    );
    
    if ($query == true) {
        
      echo "Modification éffectuée";
      $this->notificationAjout($table, addslashes($securiteM));
    }else{
      echo "Problème se trouvant dans le modiUtilisateur";
    }
  }


  public function updateUtilisateur(){

    $identifiant = $_POST['identifiant'];            $password = $_POST['password'];
    $commentaire = $_POST['commentaire'];            $dispoUser = $_POST['dispoUser']; 
    $type = $_POST['type'];                         $id_profil = $_POST['id_profil'];       $table = "profil";

    $securiteM = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."  </strong>"." a modifié  l'utilisateur <strong class='text-primary'> '".$identifiant."' </strong>";

    $query = $this->db->query(
     "UPDATE profil 
      SET password ='".sha1($password)."', 
      identifiant ='".$identifiant."' , 
      dispoUser ='".$dispoUser."', 
      commentaire ='".$commentaire."', t
      ype ='".$type."' 
      
      WHERE id_profil=".$id_profil.""
    );

    if ($query == true) {
        
      echo "Modification éffectuée";
      $this->notificationAjout($table, addslashes($securiteM));
    }else{
      echo "Modification non éffectuée ";
    }
  }


  public function afficheDataUsers(){
    $query1 = $this->db->query(
      'SELECT * FROM profil 
      ORDER BY id_profil desc'
    )->result_array();
    $c = 0;
    foreach ($query1 as $row) {
      
      echo"
      <tr>
        <td onclick=\"new();\">".$c."</td>
        <td>".$row['identifiant']."</td>
        <td>".$row['type']."</td>
        <td> ".$row['commentaire']."</td>";

        if ($row['dispoUser'] == 'OUI') {
          echo"<td class='text-success'><strong><i class='nav-icon fas fa-user-check'></i></strong></td>";
        }
        if ($row['dispoUser'] == 'NON') {
          echo"<td class='text-danger'><strong><i class='nav-icon fas fa-user-times'></i></strong></td>";
        }echo"

        <td>";
          if($this->session->userdata('autoUser_voir')=='true'){
            echo "<a type='button' data-toggle='modal' data-target='#voir' onclick=\"VoirUtilisateur('".$row['id_profil']."','".$row['identifiant']."','".$row['type']."','".$row['commentaire']."','".$row['dispoUser']."')\" class=' ml-1'><i class='nav-icon fas fa-eye text-info'></i></a>" ;
          }
          if($this->session->userdata('autoUser_modification')=='true'){
            echo "<a type='button' onclick=\"modiUtilisateur('".$row['id_profil']."','".$row['identifiant']."','".$row['type']."','".$row['commentaire']."','".$row['dispoUser']."')\" class=' ml-2'><i class='nav-icon fas fa-pencil-alt text-success'></i></a>" ;
          }
          if($this->session->userdata('autoUser_suppression')=='true'){
            echo"<a type='button' class='ml-2' data-toggle='modal' data-target='#supprimer' table='profil' identifiant='".$row['id_profil']."' onclick='SuppressionData($(this).attr(\"table\"),$(this).attr(\"identifiant\"),\"id_profil\");'><i class='far	fas fa-trash text-danger'></i></a>
        </td>
      </tr> ";}
        $c++;
    }
  }


  public function dropUtilisateur($a, $b, $c) {

    $getProfile = $this->db->query(
     "SELECT * 
      FROM " . $a . " 
      WHERE " . $c . "=" . $b . ""
    )->row();

    if (count($getProfile) > 0) {
      
      $table = $a;
      
      $securiteS = " <strong class='text-dark'>".$this->getUsername($this->session->userdata('id_profil'))."</strong>"." a supprimé   le profil  <strong class='text-info'> '". $getProfile->identifiant ."' </strong>";


      $suppression = $this->db->query(
       "DELETE 
        FROM " . $a . " 
        WHERE " . $c . "=" . $b . ""
      );

      if ($suppression == true) {
        
        echo "Suppression  effectuée";
        $this->notificationAjout($table, addslashes($securiteS));
      } 
      else {
        echo "Pas supprimé";
      }
    }
    $this->db->close();
  }


  public function ListeUsers(){

    $requete = $this->db->query(
     "SELECT * 
      FROM profil 
      ORDER BY identifiant ASC"
    )->result_array();

    if (count($requete) >0) {
        
      foreach ($requete as $row) {
          
        echo "<option value='".$row["id_profil"]."'>".$row["identifiant"]."</option>";
      }
    }else{
      echo "<option disabled>Aucun identifiant  trouvé</option>";
    }

    $this->db->close();
  }




  public function allAutorisation(){

    $id_profil = $_POST['id_profil'];
	 

    $requete = $this->db->query(
     'SELECT * 
      FROM auto_article 
      WHERE id_profile = '.$id_profil.''
    )->result_array();

    if (count($requete)>0) {
      
      foreach ($requete as $row) {
        
        echo
       '<div class="card card-success col-md-3"style="background-color:rgba(221, 221, 229, 0.69);border-radius:50px; ">
          <div class="card-header "style=" border-radius:30px;text-align: center; ">
            <h3 class="card-title text-light"><b> <i>ARTICLE</i></b></h3>
            <div class="card-tools">
                <input type="checkbox" class="gestion3" id="auto_article" checked="true">
            </div>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="form-group">
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input ajout3" type="checkbox" id="ajout3"';
                    if ($row["ajout"] == 'true') {
                      
                      echo 'checked="'.$row["ajout"].'"';
                    }
                    echo'>
                  <label for="ajout3" class="custom-control-label "><i>Ajouter</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input voir3" type="checkbox" id="voir3"';
                    if ($row["voir"] == 'true') {
                      
                      echo 'checked="'.$row["voir"].'"';
                    }
                    echo'>
                  <label for="voir3" class="custom-control-label "><i>Voir</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input modification3" type="checkbox" id="modification3"';
                    if ($row["modification"] == 'true') {
                      
                      echo 'checked="'.$row["modification"].'"';
                    }
                    echo '>
                  <label for="modification3" class="custom-control-label"><i>Modifier</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input suppression3" type="checkbox" id="suppression3"';
                    if ($row["suppression"] == 'true') {
                        
                        echo 'checked="'.$row["suppression"].'"';
                    }
                    echo '>
                  <label for="suppression3" class="custom-control-label"><i>Supprimer</i></label>
                </div>  
              </div>
            </div>
          </div>
          
        </div>';
      }
    }else{
      echo
     '<div class="card card-success col-md-3"style="background-color:rgba(221, 221, 229, 0.69);border-radius:50px; ">
        <div class="card-header "style=" border-radius:30px;text-align: center; ">
          <h3 class="card-title text-light"><b>GESTION ARTICLE</b></h3>
          <div class="card-tools">
            <input type="checkbox" class="gestion3" id="auto_article">
          </div>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group">
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input ajout3" type="checkbox" id="ajout3" >
                <label for="ajout3" class="custom-control-label"><i>Ajouter</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input voir3" type="checkbox" id="voir3" >
                <label for="voir3" class="custom-control-label"><i>Voir</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input modification3" type="checkbox" id="modification3" >
                <label for="modification3" class="custom-control-label"><i>Modifier</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input suppression3" type="checkbox" id="suppression3" >
                <label for="suppression3" class="custom-control-label"><i>Supprimer</i></label>
              </div>
            </div>
          </div>
        </div>
        
      </div>'; 
    }

 
    $requete = $this->db->query(
     "SELECT * 
      FROM auto_stock 
      WHERE id_profile = '.$id_profil.'"
    )->result_array();

    if (count($requete)>0) {
      
      foreach ($requete as $row) { 

       echo
       '<div class="card card-info col-md-3"style="background-color:rgba(221, 221, 229, 0.69);border-radius:50px; ">
          <div class="card-header "style=" border-radius:30px;text-align: center; ">
            <h3 class="card-title text-light"><b> <i>STOCK</i></b></h3>
            <div class="card-tools">
                <input type="checkbox" class="gestion1" id="auto_stock" checked="true">
            </div>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="form-group">
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input ajout1" type="checkbox" id="ajout1"';
                    if ($row["ajout"] == 'true') {
                      
                      echo 'checked="'.$row["ajout"].'"';
                    }
                    echo'>
                  <label for="ajout1" class="custom-control-label "><i>Ajouter</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input voir1" type="checkbox" id="voir1"';
                    if ($row["voir"] == 'true') {
                      
                      echo 'checked="'.$row["voir"].'"';
                    }
                    echo'>
                  <label for="voir1" class="custom-control-label "><i>Voir</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input modification1" type="checkbox" id="modification1"';
                    if ($row["modification"] == 'true') {
                      
                      echo 'checked="'.$row["modification"].'"';
                    }
                    echo '>
                  <label for="modification1" class="custom-control-label"><i>Modifier</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input suppression1" type="checkbox" id="suppression1"';
                    if ($row["suppression"] == 'true') {
                        
                        echo 'checked="'.$row["suppression"].'"';
                    }
                    echo '>
                  <label for="suppression1" class="custom-control-label"><i>Supprimer</i></label>
                </div>  
              </div>
            </div>
          </div>
          
        </div>';
      }
    }else{
      echo
     '<div class="card card-info col-md-3"style="background-color:rgba(221, 221, 229, 0.69);border-radius:50px; ">
        <div class="card-header "style=" border-radius:30px;text-align: center; ">
          <h3 class="card-title text-light"><b><i> STOCK</i></b></h3>
          <div class="card-tools">
            <input type="checkbox" class="gestion1" id="auto_stock">
          </div>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group">
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input ajout1" type="checkbox" id="ajout1" >
                <label for="ajout1" class="custom-control-label"><i>Ajouter</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input voir1" type="checkbox" id="voir1" >
                <label for="voir1" class="custom-control-label"><i>Voir</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input modification1" type="checkbox" id="modification1" >
                <label for="modification1" class="custom-control-label"><i>Modifier</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input suppression1" type="checkbox" id="suppression1" >
                <label for="suppression1" class="custom-control-label"><i>Supprimer</i></label>
              </div>
            </div>
          </div>
        </div>
        
      </div>'; 
    }

 
    $requete = $this->db->query(
     "SELECT * 
      FROM auto_fournisseur 
      WHERE id_profile = '.$id_profil.'"
    )->result_array();

    if (count($requete)>0) {
      
      foreach ($requete as $row) {
        
        echo
       '<div class="card card-danger col-md-3"style="background-color:rgba(221, 221, 229, 0.69);border-radius:50px; ">
          <div class="card-header "style=" border-radius:30px;text-align: center; ">
          <h3 class="card-title text-light"><b> <i>FOURNISSEUR</i></b></h3>
            <div class="card-tools">
              <input type="checkbox" class="gestion4" id="auto_fournisseur" checked="true">
            </div>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="form-group">
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input ajout4" type="checkbox" id="ajout4"';
                    if ($row["ajout"] == 'true') {
                      
                      echo 'checked="'.$row["ajout"].'"';
                    }
                    echo'>
                  <label for="ajout4" class="custom-control-label "><i>Ajouter</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input voir4" type="checkbox" id="voir4"';
                    if ($row["voir"] == 'true') {
                      
                      echo 'checked="'.$row["voir"].'"';
                    }
                    echo'>
                  <label for="voir4" class="custom-control-label "><i>Voir</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input modification4" type="checkbox" id="modification4"';
                    if ($row["modification"] == 'true') {
                      
                      echo 'checked="'.$row["modification"].'"';
                    }
                    echo '>
                  <label for="modification4" class="custom-control-label"><i>Modifier</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input suppression4" type="checkbox" id="suppression4"';
                    if ($row["suppression"] == 'true') {
                      
                      echo 'checked="'.$row["suppression"].'"';
                    }
                    echo '>
                  <label for="suppression4" class="custom-control-label"><i>Supprimer</i></label>
                </div>  
              </div>
            </div>
          </div>
        </div>';
      }
    }else{
      echo
     '<div class="card card-danger col-md-3"style="background-color:rgba(221, 221, 229, 0.69);border-radius:50px; ">
        <div class="card-header "style=" border-radius:30px;text-align: center; ">
          <h3 class="card-title text-light"><b><i> FOURNISSEUR</i></b></h3>
          <div class="card-tools">
            <input type="checkbox" class="gestion4" id="auto_fournisseur">
          </div>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group">
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input ajout4" type="checkbox" id="ajout4" >
                <label for="ajout4" class="custom-control-label"><i>Ajouter</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input voir4" type="checkbox" id="voir4" >
                <label for="voir4" class="custom-control-label"><i>Voir</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input modification4" type="checkbox" id="modification4" >
                <label for="modification4" class="custom-control-label"><i>Modifier</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input suppression4" type="checkbox" id="suppression4" >
                <label for="suppression4" class="custom-control-label"><i>Supprimer</i></label>
              </div>
            </div>
          </div>
        </div>
      </div>'; 
    }



 
    $requete = $this->db->query(
     "SELECT * 
      FROM auto_client 
      WHERE id_profile = '.$id_profil.'"
    )->result_array();

    if (count($requete)>0) {
      
      foreach ($requete as $row) {
        
        echo
       '<div class="card card-dark col-md-3"style="background-color:rgba(221, 221, 229, 0.69);border-radius:50px; ">
          <div class="card-header "style=" border-radius:30px;text-align: center; ">
            <h3 class="card-title text-light"><b><i>CLIENT</i></b></h3>
            <div class="card-tools">
                <input type="checkbox" class="gestion5" id="auto_client" checked="true">
            </div>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="form-group">
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input ajout5" type="checkbox" id="ajout5"';
                    if ($row["ajout"] == 'true') {
                      
                      echo 'checked="'.$row["ajout"].'"';
                    }
                    echo'>
                  <label for="ajout5" class="custom-control-label "><i>Ajouter</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input voir5" type="checkbox" id="voir5"';
                    if ($row["voir"] == 'true') {
                      
                      echo 'checked="'.$row["voir"].'"';
                    }
                    echo'>
                  <label for="voir5" class="custom-control-label "><i>Voir</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input modification5" type="checkbox" id="modification5"';
                    if ($row["modification"] == 'true') {
                      
                      echo 'checked="'.$row["modification"].'"';
                    }
                    echo '>
                  <label for="modification5" class="custom-control-label"><i>Modifier</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input suppression5" type="checkbox" id="suppression5"';
                    if ($row["suppression"] == 'true') {
                        
                        echo 'checked="'.$row["suppression"].'"';
                    }
                    echo '>
                  <label for="suppression5" class="custom-control-label"><i>Supprimer</i></label>
                </div>  
              </div>
            </div>
          </div>
          
        </div>';
      }
    }else{
      echo
     '<div class="card card-dark col-md-3"style="background-color:rgba(221, 221, 229, 0.69);border-radius:50px; ">
        <div class="card-header "style=" border-radius:30px;text-align: center; ">
          <h3 class="card-title text-light"><b><i>CLIENT</i></b></h3>
          <div class="card-tools">
            <input type="checkbox" class="gestion5" id="auto_client">
          </div>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group">
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input ajout5" type="checkbox" id="ajout5" >
                <label for="ajout5" class="custom-control-label"><i>Ajouter</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input voir5" type="checkbox" id="voir5" >
                <label for="voir5" class="custom-control-label"><i>Voir</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input modification5" type="checkbox" id="modification5" >
                <label for="modification5" class="custom-control-label"><i>Modifier</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input suppression5" type="checkbox" id="suppression5" >
                <label for="suppression5" class="custom-control-label"><i>Supprimer</i></label>
              </div>
            </div>
          </div>
        </div>
        
      </div>'; 
    }


    $requete = $this->db->query(
     "SELECT * 
      FROM auto_employe 
      WHERE id_profile = '.$id_profil.'"
    )->result_array();

    if (count($requete)>0) {
      
      foreach ($requete as $row) {
        
        echo
       '<div class="card card-warning col-md-3"style="background-color:rgba(221, 221, 229, 0.69);border-radius:50px; ">
          <div class="card-header "style=" border-radius:30px;text-align: center; ">
            <h3 class="card-title text-light"><b><i>EMPLOYE</i></b></h3>
            <div class="card-tools">
                <input type="checkbox" class="gestion2" id="auto_employe" checked="true">
            </div>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="form-group">
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input ajout2" type="checkbox" id="ajout2"';
                    if ($row["ajout"] == 'true') {
                      
                      echo 'checked="'.$row["ajout"].'"';
                    }
                    echo'>
                  <label for="ajout2" class="custom-control-label "><i>Ajouter</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input voir2" type="checkbox" id="voir2"';
                    if ($row["voir"] == 'true') {
                      
                      echo 'checked="'.$row["voir"].'"';
                    }
                    echo'>
                  <label for="voir2" class="custom-control-label "><i>Voir</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input modification2" type="checkbox" id="modification2"';
                    if ($row["modification"] == 'true') {
                      
                      echo 'checked="'.$row["modification"].'"';
                    }
                    echo '>
                  <label for="modification2" class="custom-control-label"><i>Modifier</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input suppression2" type="checkbox" id="suppression2"';
                    if ($row["suppression"] == 'true') {
                        
                        echo 'checked="'.$row["suppression"].'"';
                    }
                    echo '>
                  <label for="suppression2" class="custom-control-label"><i>Supprimer</i></label>
                </div>  
              </div>
            </div>
          </div>
          
        </div>';
      }
    }else{
      echo
     '<div class="card card-warning col-md-3"style="background-color:rgba(221, 221, 229, 0.69);border-radius:50px; ">
        <div class="card-header "style=" border-radius:30px;text-align: center; ">
          <h3 class="card-title text-light"><b><i>EMPLOYE</i></b></h3>
          <div class="card-tools">
            <input type="checkbox" class="gestion2" id="auto_employe">
          </div>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group">
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input ajout2" type="checkbox" id="ajout2" >
                <label for="ajout2" class="custom-control-label"><i>Ajouter</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input voir2" type="checkbox" id="voir2" >
                <label for="voir2" class="custom-control-label"><i>Voir</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input modification2" type="checkbox" id="modification2" >
                <label for="modification2" class="custom-control-label"><i>Modifier</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input suppression2" type="checkbox" id="suppression2" >
                <label for="suppression2" class="custom-control-label"><i>Supprimer</i></label>
              </div>
            </div>
          </div>
        </div>
        
      </div>'; 
    }




    $requete = $this->db->query(
     "SELECT * 
      FROM auto_users 
      WHERE id_profile = '.$id_profil.'"
    )->result_array();

    if (count($requete)>0) {
      
      foreach ($requete as $row) {
        
        echo
       '<div class="card card-primary col-md-3"style="background-color:rgba(221, 221, 229, 0.69);border-radius:50px; ">
          <div class="card-header "style=" border-radius:30px;text-align: center; ">
            <h3 class="card-title text-light"><b> <i>USERS</i></b></h3>
            <div class="card-tools">
                <input type="checkbox" class="gestion6" id="auto_users" checked="true">
            </div>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="form-group">
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input ajout6" type="checkbox" id="ajout6"';
                    if ($row["ajout"] == 'true') {
                      
                      echo 'checked="'.$row["ajout"].'"';
                    }
                    echo'>
                  <label for="ajout6" class="custom-control-label "><i>Ajouter</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input voir6" type="checkbox" id="voir6"';
                    if ($row["voir"] == 'true') {
                      
                      echo 'checked="'.$row["voir"].'"';
                    }
                    echo'>
                  <label for="voir6" class="custom-control-label "><i>Voir</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input modification6" type="checkbox" id="modification6"';
                    if ($row["modification"] == 'true') {
                      
                      echo 'checked="'.$row["modification"].'"';
                    }
                    echo '>
                  <label for="modification6" class="custom-control-label"><i>Modifier</i></label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input suppression6" type="checkbox" id="suppression6"';
                    if ($row["suppression"] == 'true') {
                        
                        echo 'checked="'.$row["suppression"].'"';
                    }
                    echo '>
                  <label for="suppression6" class="custom-control-label"><i>Supprimer</i></label>
                </div>  
              </div>
            </div>
          </div>
          
        </div>';
      }
    }else{
      echo
     '<div class="card card-primary col-md-3"style="background-color:rgba(221, 221, 229, 0.69);border-radius:50px; ">
        <div class="card-header "style=" border-radius:30px;text-align: center; ">
          <h3 class="card-title text-light"><b><i>USERS</i></b></h3>
          <div class="card-tools">
            <input type="checkbox" class="gestion6" id="auto_users">
          </div>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group">
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input ajout6" type="checkbox" id="ajout6" >
                <label for="ajout6" class="custom-control-label"><i>Ajouter</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input voir6" type="checkbox" id="voir6" >
                <label for="voir6" class="custom-control-label"><i>Voir</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input modification6" type="checkbox" id="modification6" >
                <label for="modification6" class="custom-control-label"><i>Modifier</i></label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input suppression6" type="checkbox" id="suppression6" >
                <label for="suppression6" class="custom-control-label"><i>Supprimer</i></label>
              </div>
            </div>
          </div>
        </div>
        
      </div>'; 
    }
       


  } 


  public function afficheDataNotification(){

    if (isset($_POST["dateDebut"]) && isset($_POST["dateFin"]) && isset($_POST["id_nom"])) {
            
            $dateDebut = $_POST['dateDebut'];  $dateFin = $_POST['dateFin']; $id_nom = $_POST['id_nom'];
            
		      if (!empty($dateFin) && !empty($dateDebut) && isset($_POST["id_nom"])) {

            $requete = $this->db->query(
             "SELECT  * 
              FROM notification 
              WHERE  id_profil = '".$id_nom."' and date_notif between '".$dateDebut."' and '".$dateFin."'  
              ORDER BY date_notif DESC"
            )->result_array();

            if ($id_nom == 'ALL') {
                
                $requete = $this->db->query(
                 "SELECT  * 
                  FROM notification 
                  WHERE  date_notif between '".$dateDebut."' and '".$dateFin."'  
                  ORDER BY date_notif DESC"
                )->result_array();
            
            }else {
                
                $requete = $this->db->query(
                 "SELECT  * 
                  FROM notification 
                  WHERE id_profil = '".$id_nom."' and  date_notif between '".$dateDebut."' and '".$dateFin."' 
                  ORDER BY date_notif DESC "
                )->result_array();
                
            }	
          
          }else{
              
            $requete = $this->db->query(
             "SELECT  * 
              FROM notification  
              ORDER BY date_notif DESC"
            )->result_array();    
          }		
            
        }else{ 
          $requete = $this->db->query(
           "SELECT * 
            FROM notification 
            ORDER BY date_notif desc"
          )->result_array();
        }
        $c=0; 


        if (count($requete) >0) {
          
          foreach ($requete as $row) {
            
            echo "
            <tr>
              <td>".$c."</td>
              <td>".$row['poste']."</td>
              <td>".$row['date_notif']."</td>
              <td>".$row['heure_notif']."</td>
              <td>".$row['message']."</td>
            </tr>";
            $c++;
          }
        }
  }



}