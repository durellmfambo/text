<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property CI_Loader $load
 * @property CI_Input $input
 * @property CI_Output $output
 * @property CI_Session $session
 * @property CI_DB_query_builder $db
 * @property ModelArticle $ModelArticle
 */

class ControllerArticle extends CI_Controller{
	
	function __construct() {

        parent::__construct();
        
        global $URI, $CFG, $IN;  $config =& $CFG->config; $URI->uri_string = preg_replace("|^\/?|", '/', $URI->uri_string);
        
        $this->load->library('session');  $this->load->helper('app_gui_helper');  $this->load->helper('cookie'); $this->load->helper('url');
        
        $this->load->model('ModelArticle');


        if ($this->session->userdata('language_abbr')!==null) {}

        else{$this->session->set_userdata('language_abbr', $config['language_abbr']);}
        
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');  $this->output->set_header('Pragma: no-cache');
    }



    /* CATEGORIE ARTICLE */
 
    public function ajoutCategorieArticle(){

        $this->ModelArticle->ajoutCategorieArticle();
    }

    
    public function NewCodeCategorieArticle(){

       echo $this->ModelArticle->codeCategorieArticle();
    }


    public function afficheDataCategorieArticle(){

        $this->ModelArticle->afficheDataCategorieArticle();
    }

    public function dropCategorieArticle(){
        
        $a = $_POST["a"]; $b = $_POST["b"]; $c = $_POST["c"];
        $this->ModelArticle->dropCategorieArticle($a, $b, $c);
    }



    /*  ARTICLE */
     
    
    public function ajoutArticle(){

        $this->ModelArticle->ajoutArticle();
    }

    
    public function NewCodeArticle(){

        $this->ModelArticle->codeArticle();
    }


    public function afficheDataArticle(){

        $this->ModelArticle->afficheDataArticle();
    }

    public function dropArticle(){
        
        $a = $_POST["a"]; $b = $_POST["b"]; $c = $_POST["c"];
        $this->ModelArticle->dropArticle($a, $b, $c);
    }
    





    



    /* COMMANDE FOURNISSEUR */


    public function MontantArticle(){

        $this->ModelArticle->MontantArticle();
    }

    public function PrixDeVente(){

        $this->ModelArticle->PrixDeVente();
    }
    
    public function ReferenceArticle(){

        $this->ModelArticle->ReferenceArticle();
    }

     
    public function CodeFournisseur(){

        $this->ModelArticle->CodeFournisseur();
    }
    
    
    public function AdresseFournisseur(){

        $this->ModelArticle->AdresseFournisseur();
    } 
    
    
    public function TelFournisseur(){

        $this->ModelArticle->TelFournisseur();
    }

    public function allLigneCommande(){
        $this->ModelArticle->allLigneCommande();
    }

    
    public function allLigneFacture(){
        $this->ModelArticle->allLigneFacture();
    }


    public function codeCommande(){

       $this->ModelArticle->codeCommande();
    }


    public function ajoutCommande(){

        $this->ModelArticle->ajoutCommande();
    }


    public function modifieDataCommande(){
        
        $this->ModelArticle->modifieDataCommande();
    }


    public function afficheDataCommande(){

        $this->ModelArticle->afficheDataCommande();
    }


    public function PrintCommande(){

        $this->ModelArticle->PrintCommande();
    }


    public function dropCommande(){

        $a = $_POST["a"]; $b = $_POST["b"];$c = $_POST["c"];
        $this->ModelArticle->dropCommande($a, $b, $c);
    }


    


    
    

    /* COMMANDE CLIENT */


    public function CodeClient(){

        $this->ModelArticle->CodeClient();
    }
    
    
    public function AdresseClient(){

        $this->ModelArticle->AdresseClient();
    } 
    
    
    public function TelClient(){

        $this->ModelArticle->TelClient();
    }


    public function ajoutCommandeClient(){

        $this->ModelArticle->ajoutCommandeClient();
    }


    public function afficheDataCommandeClient(){

        $this->ModelArticle->afficheDataCommandeClient();
    }

    public function modifieDataCommandeClient(){
        
        $this->ModelArticle->modifieDataCommandeClient();
    }


    public function PrintCommandeClient(){

        $this->ModelArticle->PrintCommandeClient();
    }
    

    public function codeCommandeClient(){

       $this->ModelArticle->codeCommandeClient();
    }


    public function dropCommandeClient(){

        $a = $_POST["a"]; $b = $_POST["b"];$c = $_POST["c"];
        $this->ModelArticle->dropCommandeClient($a, $b, $c);
    }


    

    /* FACTURE CLIENT */

    public function modifieDataFacture(){
        
        $this->ModelArticle->modifieDataFacture();
    }


    public function dropFactureClient(){

        $a = $_POST["a"]; $b = $_POST["b"];$c = $_POST["c"];
        $this->ModelArticle->dropFactureClient($a, $b, $c);
    }

 

}