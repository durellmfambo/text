<?php

defined('BASEPATH') OR exit('No direct script access allowed');


/**
 * @property CI_Loader $load
 * @property CI_Input $input
 * @property CI_Output $output
 * @property CI_Session $session
 * @property CI_DB_query_builder $db
 * @property ModelStock $ModelStock
 * @property ModelStock $ModelStock
 */

class ControllerStock extends CI_Controller{
	
	function __construct() {

        parent::__construct();

        global $URI, $CFG, $IN;  $config =& $CFG->config;  $URI->uri_string = preg_replace("|^\/?|", '/', $URI->uri_string);


        $this->load->model('ModelStock');    

        
        $this->load->library('session');   $this->load->helper('app_gui_helper');   $this->load->helper('cookie');  $this->load->helper('url');
        
        if ($this->session->userdata('language_abbr')!==null) {}
        
        else{  $this->session->set_userdata('language_abbr', $config['language_abbr']); }
        
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0'); $this->output->set_header('Pragma: no-cache');

    }

    public function getPrixUnitaireArticle8(){

        $this->ModelStock->getPrixUnitaireArticle8();
    }
    
    public function MontantArticle(){

        $this->ModelStock->MontantArticle();
    }

    public function ReferenceArticle(){

        $this->ModelStock->ReferenceArticle();
    }

 
    public function ReferenceArticleM(){

        $this->ModelStock->ReferenceArticleM();
    }

    public function MontantArticleM(){

        $this->ModelStock->MontantArticleM();
    }

    public function prixDeVente(){

        $this->ModelStock->prixDeVente();
    }


    /*   INVENTAIRE  */
    
    public function ajoutInventaire(){

        $this->ModelStock->ajoutInventaire();
    }
    

    public function modiInventaire(){

        $this->ModelStock->modiInventaire();
    }


    public function tableInventaire(){

        $this->ModelStock->tableInventaire();
    }


    public function afficheDataInventaire(){

        $this->ModelStock->afficheDataInventaire();
    }


    public function DernierInventaire(){

        $this->ModelStock->DernierInventaire();
    }


    public function dropInventaire(){

        $a = $_POST["a"]; $b = $_POST["b"];$c = $_POST["c"];
        $this->ModelStock->dropInventaire($a, $b, $c);
    }


    /*   APPROVISIOONNEMENT  */
    public function ajoutApprovisionnement(){

        $this->ModelStock->ajoutApprovisionnement();
    }


    public function modiApprovisionnement(){

        $this->ModelStock->modiApprovisionnement();
    }


    public function tableApprovisionnement(){

        $this->ModelStock->tableApprovisionnement();
    }


    public function afficheDataApprovisionnement(){
        
        $this->ModelStock->afficheDataApprovisionnement();
    }


    public function afficheData(){
        
        $this->ModelStock->afficheData();
    }


    public function dropApprovisionnement(){

        $a = $_POST["a"]; $b = $_POST["b"];$c = $_POST["c"];
        $this->ModelStock->dropApprovisionnement($a, $b, $c);
    }


    /*   DEFECTUEUX  */
    public function ajoutDefectueux(){

        $this->ModelStock->ajoutDefectueux();
    }


    public function modiDefectueux(){

        $this->ModelStock->modiDefectueux();
    }


    public function tableDefectueux(){

        $this->ModelStock->tableDefectueux();
    }


    public function afficheDataDefectueux(){
        
        $this->ModelStock->afficheDataDefectueux();
    }


    public function dropDefectueux(){

        $a = $_POST["a"]; $b = $_POST["b"];$c = $_POST["c"];
        $this->ModelStock->dropDefectueux($a, $b, $c);
    }


    /* SORTIE */

    public function StockArticle(){

        $this->ModelStock->StockArticle();
    }


    public function ajoutSortie(){

        $this->ModelStock->ajoutSortie();
    }


    public function afficheDataSortie(){

        $this->ModelStock->afficheDataSortie();
    }


    public function dropSortie(){

        $a = $_POST["a"]; $b = $_POST["b"];$c = $_POST["c"];
        $this->ModelStock->dropSorti($a, $b, $c);
    }


}