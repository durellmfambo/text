<?php

defined('BASEPATH') OR exit('No direct script access allowed');


/**
 * @property CI_Loader $load
 * @property CI_Input $input
 * @property CI_Output $output
 * @property CI_Session $session
 * @property CI_DB_query_builder $db
 * @property Model $Model
 */

class Controller extends CI_Controller{
	
	function __construct() {

        parent::__construct();

        global $URI, $CFG, $IN;  $config =& $CFG->config;  $URI->uri_string = preg_replace("|^\/?|", '/', $URI->uri_string);
        
        
        $this->load->library('session');  $this->load->helper('app_gui_helper');  $this->load->helper('cookie');   $this->load->helper('url');

        $this->load->model('ModelArticle');   $this->load->model('ModelClient'); $this->load->model('ModelFournisseur');  

        $this->load->model('ModelStock');    $this->load->model('Model');    $this->load->model('ModelUser'); $this->load->model('ModelEmploye');
        
        if ($this->session->userdata('language_abbr')!==null) {}

        else{$this->session->set_userdata('language_abbr', $config['language_abbr']);}
        
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0'); 

        $this->output->set_header('Pragma: no-cache');
    }
    
   

    //LOGIN
    public function index(){

        $data['title'] = 'Login';
        $this->load->view('backend/login', $data);
    }


    // HOME
    public function home(){

        $data['title'] = 'Home';
        $this->load->view('backend/home',$data);
    }


    // DASHBOARD 1
    public function dashboard1(){
       
        $data['title'] = 'Dashboard 1';
        $this->load->view('backend/dashboard/dashboard1',$data);
    }
 
 
    // DASHBOARD 2
    public function dashboard2(){
    
        $data['title'] = 'Dashboard 2';
        $this->load->view('backend/dashboard/dashboard2',$data);
    }


    // DASHBOARD 3
    public function dashboard3(){
    
        $data['title'] = 'Dashboard 3';
        $this->load->view('backend/dashboard/dashboard3',$data);
    }


    // CLIENT
    public function client(){
       
        $data['title'] = 'Client';
        $this->load->view('backend/client/client',$data);
    }


    // FACTURE
    public function factureClient(){
       
        $data['title'] = 'Facture Client';
        $this->load->view('backend/client/facture',$data);
    }


    // FOURNISSEUR
    public function fournisseur(){
       
        $data['title'] = 'Fournisseur';
        $this->load->view('backend/fournisseur/fournisseur',$data);
    }



    // FACTURE
    public function facture(){
       
        $data['title'] = 'Facture';
        $this->load->view('backend/fournisseur/facture/facture',$data);
    }


   


    // CATEGORIE ARTICLE
    public function categorieArticle(){
       
        $data['title'] = 'Catégorie article';
        $this->load->view('backend/categorie/categorieArticle',$data);
    }


    // ARTICLE
    public function article(){
       
        $data['title'] = 'Article';
        $this->load->view('backend/article/article',$data);
    }


    // INVENTAIRE
    public function inventaire(){
       
        $data['title'] = 'Inventaire';
        $this->load->view('backend/stock/inventaire',$data);
    }


    // APPROVISIONNEMENT
    public function approsionnement(){
       
        $data['title'] = 'Approsionnement';
        $this->load->view('backend/stock/approsionnement',$data);
    } 

    // DEFECTUEUX
    public function defectueux(){
       
        $data['title'] = 'Defectueux';
        $this->load->view('backend/stock/defectueux',$data);
    } 

    // SORTIE
    public function sortie(){
       
        $data['title'] = 'sortie';
        $this->load->view('backend/stock/sortie',$data);
    } 

    // APPROVISIONNEMENT
    public function stock(){
       
        $data['title'] = 'Stock';
        $this->load->view('backend/stock/stock',$data);
    } 


    //COMMANDE FOURNISSEUR
    public function commandeFournisseur(){
       
        $data['title'] = 'Commande Fournisseur';
        $this->load->view('backend/fournisseur/commandeFournisseur',$data);
    }

    //COMMANDE CLIENT
    public function commandeClient(){
       
        $data['title'] = 'Commande Client';
        $this->load->view('backend/client/commandeClient',$data);
    }
    

    // FONCTION
    public function fonction(){
       
        $data['title'] = 'Fonction';
        $this->load->view('backend/employe/fonction',$data);
    }


    // EMPLOYE
    public function  employe(){
       
        $data['title'] = 'Employe';
        $this->load->view('backend/employe/employe',$data);
    }

    // SANCTION
    public function  sanction(){
       
        $data['title'] = 'Sanction';
        $this->load->view('backend/employe/sanction',$data);
    }

    // CATEGORIE LOGIN
    public function login(){
        $this->Model->login();
    }

   
    // UTILIATEURS
    public function users(){
       
        $data['title'] = 'Utilisateur';
        $this->load->view('backend/utilisateur/utilisateur',$data);
    }


     // SECURITE
    public function securite(){
       
        $data['title'] = 'Sécurité';
        $this->load->view('backend/utilisateur/securite',$data);
    }

    // DECONNEXION
    public function deconnexion(){

        $this->session->sess_destroy();$this->session->set_flashdata('logout_notification', 'logged_out');
        redirect(base_url()."controller/", 'refresh');
    }

   



}