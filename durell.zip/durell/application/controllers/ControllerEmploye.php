<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property CI_Loader $load
 * @property CI_Input $input
 * @property CI_Output $output
 * @property CI_Session $session
 * @property CI_DB_query_builder $db
 * @property ModelEmploye $ModelEmploye
 */
class ControllerEmploye extends CI_Controller{
	
	function __construct() {

        parent::__construct();

        global $URI, $CFG, $IN;  $config =& $CFG->config;   $URI->uri_string = preg_replace("|^\/?|", '/', $URI->uri_string);
        
        $this->load->model('ModelEmploye');

        
        $this->load->library('session');  $this->load->helper('app_gui_helper'); $this->load->helper('cookie'); $this->load->helper('url');

        
        
        if ($this->session->userdata('language_abbr')!==null) {} 

        else{
            $this->session->set_userdata('language_abbr', $config['language_abbr']);
        }
        
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');  
        
        $this->output->set_header('Pragma: no-cache');

    }


    /* FONCTION */
 
    public function ajoutFonction(){

        $this->ModelEmploye->ajoutFonction();
    }

    public function codeFonction(){

       echo $this->ModelEmploye->codeFonction();
    }


    public function afficheDataFonction(){

        $this->ModelEmploye->afficheDataFonction();
    }

    public function dropFonction(){

        $a = $_POST["a"]; $b = $_POST["b"];$c = $_POST["c"];
        $this->ModelEmploye->dropFonction($a, $b, $c);
    }


    /* EMPLOYE */
 
    public function nouveauCodeEmploye(){

        $this->ModelEmploye->codeEmploye();
    }

    public function getCodeEmploye(){

        $this->ModelEmploye->getCodeEmploye();
    }

    public function ajoutEmploye(){

        $this->ModelEmploye->ajoutEmploye();
    }

    public function afficheDataEmploye(){

        $this->ModelEmploye->afficheDataEmploye();
    }

    public function dropEmploye(){

        $a = $_POST["a"]; $b = $_POST["b"];$c = $_POST["c"];
        $this->ModelEmploye->dropEmploye($a, $b, $c);
    }
   


}