<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property CI_Loader $load
 * @property CI_Input $input
 * @property CI_Output $output
 * @property CI_Session $session
 * @property CI_DB_query_builder $db
 * @property ModelClient $ModelClient
 */

class ControllerClient extends CI_Controller{
	
	function __construct() {

        parent::__construct();
        
        global $URI, $CFG, $IN;    $config =& $CFG->config;  $URI->uri_string = preg_replace("|^\/?|", '/', $URI->uri_string);
        
        $this->load->library('session');   $this->load->helper('app_gui_helper'); $this->load->helper('cookie'); $this->load->helper('url');
       
        $this->load->model('ModelClient');

        if ($this->session->userdata('language_abbr')!==null) {} 

        else{$this->session->set_userdata('language_abbr', $config['language_abbr']);}
        
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');  $this->output->set_header('Pragma: no-cache');
    }




    /* CLIENT */

    public function ajoutClient(){

        $this->ModelClient->ajoutClient();
    }

    
    public function NewCodeClient(){

       echo $this->ModelClient->NewCodeClient();
    }


    public function afficheDataClient(){

        $this->ModelClient->afficheDataClient();
    }

    public function dropClient(){
        
        $a = $_POST["a"]; $b = $_POST["b"]; $c = $_POST["c"];
        $this->ModelClient->dropClient($a, $b, $c);
    }




    public function CodeClient(){

        $this->ModelClient->CodeClient();
    }
    
    
    public function AdresseClient(){

        $this->ModelClient->AdresseClient();
    } 
    
    
    public function TelClient(){

        $this->ModelClient->TelClient();
    }


    
    
    /* FACTURE CLIENT */


    public function ajoutFacture(){

        $this->ModelClient->ajoutFacture();
    }


    public function codeFacture(){

       $this->ModelClient->codeFacture();
    }


    public function afficheDataFacture(){

        $this->ModelClient->afficheDataFacture();
    }


    public function modifieDataFacture(){
        
        $this->ModelClient->modifieDataFacture();
    }


    public function PrintFacture(){

        $this->ModelClient->PrintFacture();
    }

}