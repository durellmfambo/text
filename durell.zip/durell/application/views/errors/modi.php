<?php 
  if($this->session->userdata('id_profil')==null){
    redirect(base_url()."controller/", 'refresh');
  }
 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
      <?php echo $title; $profile="";?>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link rel="stylesheet" href="<?php echo base_url(); ?>style/plugins/fontawesome-free/css/all.min.css">
    
    <link rel="shurtcut icon" href="<?php echo base_url(); ?>style/image/favicon.ico">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bbootstrap 4 -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>style/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    
    <link rel="stylesheet" href="<?php echo base_url(); ?>style/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    
    <link rel="stylesheet" href="<?php echo base_url(); ?>style/plugins/jqvmap/jqvmap.min.css">
   
    <link rel="stylesheet" href="<?php echo base_url(); ?>style/dist/css/adminlte.min.css">
    
    <link rel="stylesheet" href="<?php echo base_url(); ?>style/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    
    <link rel="stylesheet" href="<?php echo base_url(); ?>style/plugins/daterangepicker/daterangepicker.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>style/plugins/toastr/toastr.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>style/plugins/toastr/toastr.min.css">
    
    <link rel="stylesheet" href="<?php echo base_url(); ?>style/plugins/summernote/summernote-bs4.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>style/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  </head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    
    <?php include 'style/right_sidebar.php'; ?>

    
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
            <h4 class="m-0">
              <b class="text-primary">
                <?php echo $title; ?>
              </b>
            </h4>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><b class="text-warning"><?php echo $title; ?></b></li>
            </ol>
          </div>
        </div>
      </div>
    </div>

  
  <section class="content">
    <div class="container-fluid">
      <!-- Small boxes (Stat box) -->
      
      
      
     <div class="row">
      <div class="col-2 col-sm-2"></div>
        <div class="col-md-12">
          <div class="tab-content" >
            <div class="tab-pane fade show active"  aria-labelledby="custom-tabs-one-home-tab ">
              <div class="overlay-wrapper">

                <div class="overlay dark chargementCarteGrise1" style="display: none;">
                  <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                  <div class="text-bold pt-2">Loading...</div>
                </div>
                <h3 style="text-align: center; "><b class="text-info">Gestion compte</b></h3>
                <div class="card card-dark">
                  <div class="card-header">
                    <h3 class="card-title">saisissez tous les champs</h3>
                  </div>
                  <div class="card-body">
                    <div class="row">

                      <div class="col-md-4">
                        <input type="text" style="border-radius:20px;" class="form-control identifiant" placeholder="Identifiant" value="<?php echo $this->session->userdata('identifiant'); ?>">
                      </div>
                      
                      <div class="col-md-4">
                        <input type="password" class="form-control password" placeholder="Mot de passe" >
                      </div>
                          
                      <div class="col-md-4">
                        <input type="password" class="form-control confirmPassword" placeholder="Confirmer le mot de passe">
                      </div>
                       
                    </div>

                    <div class="row">

                      <div class="col-md-4">
                        <br><button type="button" class=" btn-primary btn-lg btnModifClient" style="display: none;"  onclick="addClient('update');">Modifier</button>
                      </div>

                      <div class="col-md-4 alertSucces"></div>
                      <div class="col-md-4"><br> <button type="button" class=" btn-primary btn-lg btnAnnulerModif" style="display: none;" onclick="annulerModifClient();">Annuler <i class="nav-icon  fas fa-times-circle"></i></button> 
                        <?php
                          echo '<button type="button" class="btn btn-dark btnAddClient"  onclick="modifUtilisateur();">Modifier <i class="nav-icon fas fa-pen"></i></button>'; 
                        ?>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <input type="hidden" class="id_table" name="" value="<?php echo $this->session->userdata('id_profil'); ?>">
			        <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">  
            </div>
          </div>
        </div>

        <div class="col-2 col-sm-4"></div>
      </div>
    </div>
    </div>
        
      </div>
    </section>
    
  </div>
  
  <?php 
include 'style/footer.php';
?>

  
  <aside class="control-sidebar control-sidebar-dark">
    
  </aside>
  <!-- /.control-sidebar -->
</div>


<!-- jQuery -->
<script src="<?php echo base_url(); ?>style/plugins/jquery/jquery.min.js"></script>

<script src="<?php echo base_url(); ?>style/plugins/jquery-ui/jquery-ui.min.js"></script>

<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>

<script src="<?php echo base_url(); ?>style/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

<script src="<?php echo base_url(); ?>style/plugins/chart.js/Chart.min.js"></script>

<script src="<?php echo base_url(); ?>style/plugins/sparklines/sparkline.js"></script>

<script src="<?php echo base_url(); ?>style/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>

<script src="<?php echo base_url(); ?>style/plugins/jquery-knob/jquery.knob.min.js"></script>

<script src="<?php echo base_url(); ?>style/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/daterangepicker/daterangepicker.js"></script>

<script src="<?php echo base_url(); ?>style/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>

<script src="<?php echo base_url(); ?>style/plugins/summernote/summernote-bs4.min.js"></script>

<script src="<?php echo base_url(); ?>style/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>

<script src="<?php echo base_url(); ?>style/plugins/datatables-buttons/js/dataTables.buttons.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/datatables-buttons/js/buttons.colVis.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/datatables-buttons/js/buttons.flash.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/datatables-buttons/js/buttons.html5.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/datatables-buttons/js/buttons.flash.min.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/datatables-buttons/js/buttons.print.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

<script src="<?php echo base_url(); ?>style/plugins/pdfmake/pdfmake.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/pdfmake/pdfmake.min.js"></script>

<script src="<?php echo base_url(); ?>style/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/jszip/jszip.js"></script>

<script src="<?php echo base_url(); ?>style/dist/js/adminlte.js"></script>

<script src="<?php echo base_url(); ?>style/dist/js/pages/dashboard.js"></script>

<script src="<?php echo base_url(); ?>style/plugins/sweetalert2/sweetalert2.min.js"></script>
<script src="<?php echo base_url(); ?>style/plugins/toastr/toastr.min.js"></script>
<script src="<?php echo base_url(); ?>style/dist/js/demo.js"></script>
<script src="<?php echo base_url(); ?>style/javascript/controller.js"></script>
<script src="<?php echo base_url(); ?>style/javascript/JsUser.js"></script>
<script>

  $(function () {
    // toastr.info("goooooo");
    $("#exportData").DataTable({
      "lengthChange": false,
      "searching": true,
      // "ordering": true,
      "info": true,
      "autoWidth": false,
      // "responsive": true,
      // "responsive": true,
      // "autoWidth": true,
      "autoPrint": true,
       dom: 'Bfrtip',
        buttons: [
         {
            extend: "print",
            text: "<i class='fa fa-print bigger-110 grey'></i> <b><i>PRINT</i>",
            className: "btn btn-white btn-danger btn-bold",
            autoPrint: true,
            message: 'DURELL :::: PROFILES'
            },
            {
            extend: "pdf",
            text: "<i class='fa fa-file-pdf-o bigger-110 red'></i> <b class='hidden'>PDF</b>",
            className: "btn btn-white btn-success btn-bold"
            },
            {
            extend: 'excelHtml5',
            autoFilter: true,
            sheetName: 'Exported data',
            text: "<i class='fa fa-file-excel-o bigger-110 green'></i> <b><i>EXCEL</i></b>",
            className: "btn btn-white btn-info btn-bold"
        }
        ],
           "language": {
    "sProcessing":     "Traitement en cours...",
    "sSearch":         "Rechercher&nbsp;:",
    "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
    "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
    "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
    "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
    "sInfoPostFix":    "",
    "sLoadingRecords": "actualisation en cours...",
    "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
    "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
    "oPaginate": {
        "sFirst":      "Premier",
        "sPrevious":   "Pr&eacute;c&eacute;dent",
        "sNext":       "Suivant",
        "sLast":       "Dernier"
    },
    "oAria": {
        "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
        "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
    },
    "select": {
            "rows": {
                _: "%d lignes sÃ©lÃ©ctionnÃ©es",
                0: "Aucune ligne sÃ©lÃ©ctionnÃ©e",
                1: "1 ligne sÃ©lÃ©ctionnÃ©e"
            } 
    }
}
      
    });
    $('#exportData1').DataTable({
     
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
    //Initialize Select2 Elements
   
  })

</script>
</body>
</html>
