<?php 
  if($this->session->userdata('id_profil')==null){
    redirect(base_url()."controller/", 'refresh');
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
      <?php 
        echo $title;   $employe = "";  $menuEmploye = "";  $activeEmploye = "";
      ?>
    </title>
    
    <?php include 'style/css.php'; ?>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('style/vendors/styles/style.css'); ?>" /> 
  </head>
  <body class="hold-transition sidebar-mini layout-fixed">

    <div class="wrapper">
      
      <?php include 'style/right_sidebar.php'; ?>
      
      <div class="content-wrapper">
        
        <div class="content-header" >
          <div class="container-fluid">
            <div class="row mb-3">
              <div class="col-sm-12">
                <h4 style="text-align: center;"><b class="text-primary">Ajouter un Employe  <i class='nav-icon fas fa-user-tie'></i></b></h4>
              </div>
            
            </div>

            <div class="row mb-1">
              <div class="col-sm-12">
                <ol class="breadcrumb float-sm-left">
                  <a href="<?php echo base_url('controller/home'); ?>"><li><b class="text-primary "> Home <i class='nav-icon fas fa-angle-right'></i>  </b></li></a></li>
                  <li ><b class="text-success">  <?php echo $title; ?></b></li>
                </ol>
              </div>
            
            </div>
            
          </div>
        </div>
        

        <section class="content">

          <div class="container-fluid">

            <div class="row">

              <div class="col-md-12 col-sm-12">

                <div class="tab-content" >

                  <div class="tab-pane fade show active" aria-labelledby="custom-tabs-one-home-tab ">

                    <div class="overlay-wrapper">

                      <div class="overlay light actualisation" style="display: none;">
                        <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                      </div>
                    
                      <div class="card-body">
                        
                        <div class="row"> 

                          <div class="col-md-2" >
                            <div class="form-group">
                              <label>N°Employe</label>
                              <input type="text" style="border-radius:20px;" class="form-control codeEmploye"   value="<?php echo $this->ModelEmploye->codeEmploye();?>" disabled="true">
                            </div>
                          </div>
                          
                          <div class="col-md-3">
                            <label>Nom</label>
                            <input type="text" style="border-radius:20px;" class="form-control nomEmploye" placeholder="nom">
                          </div>

                          <div class="col-md-3">
                            <label>Prenom</label>
                            <input type="text" style="border-radius:20px;" class="form-control prenomEmploye" placeholder="prenom">
                          </div> 

                          <div class="col-md-2">
                            <label>Date de Naissance</label>
                            <div class="input-group ">
                              <input type="date" style="border-radius:20px;" class="form-control  dateNaiss" value="<?php echo date('Y-m-d'); ?>" />
                            </div>
                          </div>

                          <div class="col-md-2">
                            <label>Téléphone</label>
                            <input type="text" style="border-radius:20px;" class="form-control telEmploye" onkeypress="chiffres(event);" placeholder="Telephone">
                          </div>

                          

                        </div>

                        <div class="row">

                          <div class="col-md-2">
                            <label>N°CNI</label>
                            <input type="text" style="border-radius:20px;" class="form-control cniEmploye" placeholder="cni">
                          </div>
                          
                          <div class="col-md-3">
                            <label>Adresse</label>
                            <input type="text" style="border-radius:20px;" class="form-control adresseEmploye" placeholder="adresse">
                          </div> 

                          <div class="col-md-2">
                            <label>Date d'embauche</label>
                            <div class="input-group ">
                              <input type="date" style="border-radius:20px;" class="form-control  dateEmbauche" value="<?php echo date('Y-m-d'); ?>" />
                            </div>
                          </div>

                          <div class="col-md-2">
                            <label> Fonction</label>
                            <select style="border-radius:20px;" class="id_fonction form-control" >
                              <option></option>
                              <?php $this->ModelEmploye->ListeFonction(); ?>
                            </select>
                          </div>

                          <div class="col-md-2">
                            <label>Salaire de Base</label>
                            <input type="text" style="border-radius:20px;" class="form-control salaire" onkeypress="chiffres(event);" placeholder="salaire">
                          </div>

                          <div class="col-md-1">
                            <label>Disponible</label>
                            <input type="checkbox" class="form-control actifEmploye">
                          </div> 

                        </div> 
 

                        <div class="row">

                          <div class="col-md-10"></div>

                          <div class="col-md-2">
                            <br>
                            <?php
                              if($this->session->userdata('autoEmploye_ajout') == "true") {
                                echo '<button type="button" class="btn btn-dark buttonA" onclick="ajoutEmploye(\'ajouter\');">Ajouter <i class="nav-icon fas fa-plus-circle"></i></button>';
                              }
                            ?>
                            <button type="button" class="btn btn-info buttonM" style="display: none;" onclick="ajoutEmploye('modifier');">Modifier <i class="nav-icon 	fas fa-pen"></i></button>
                          </div>

                        </div>

                      </div>

                    </div>

                    <input type="hidden" class="id_table">
                    <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">

                  </div>

                  
                </div>

              </div>

              <div class="col-12 col-sm-12">
                
                 <!-- supprimer -->
                <div class="modal fade" id="supprimer">
                  <div class="modal-dialog">
                    <div class="modal-content bg-light">
                      <div class="modal-header">
                        <h4 class="modal-title text-danger"><b><i class='nav-icon fas fa-trash'></i>Suppression</b></h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span></button>
                      </div>
                      <div class="modal-body">
                      <h6  style="text-align: center;"> <b class="text-danger"> Validez la suppression </b></h6>
                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler <i class="nav-icon  fas fa-times-circle"></i></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"
                          onclick="dropEmploye();">Valider <i class="nav-icon fas fa-check-double"></i>
                        </button>
                        <input type="hidden" class="a" >  <input type="hidden" class="b" >  <input type="hidden" class="c" >
                      </div>
                    </div>
                  </div>
                </div>

                

                <!-- voir 
                <div class="modal fade" id="voir">
                  <div class="modal-dialog modal-lg modal-dialog-top">
                    <div class="modal-content bg-light">
                      <div class="modal-header">
                        <h4 class="modal-title text-info"><b><i class='nav-icon fas fa-eye'></i>Voir les informations</b></h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">

                        <div class="row">

                          <div class="col-md-8">
                            <label>Fonction</label>
                            <input type="text" style="border-radius:20px;" class="form-control fonctionV" disabled="true">
                          </div>
                          
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>N°Fonction</label>
                              <input type="text" style="border-radius:20px;" class="form-control codeFoncV" disabled="true">
                            </div>
                          </div>

                        </div>

                        <div class="row">

                          <div class="col-md-8 mt-4">
                            <label>Commantaire</label>
                            <input type="text" style="border-radius:20px;" class="form-control commentaireFoncV"disabled="true">
                          </div>

                          <div class="col-md-3 mt-4">
                            <label>Date  </label>
                            <div class="input-group ">
                              <input type="date" style="border-radius:20px;" class="form-control  dateFoncV" data-target="#reservationdate" disabled="true"/>
                              <div class="input-group-append" data-target="#reservationdate" data-toggle="datetimepicker">
                              </div>
                            </div>
                          </div>

                          <div class="col-md-1 mt-4">
                            <label>DISPO</label>
                            <input type="checkbox" class="form-control actifFoncV"disabled="true">
                          </div>

                        </div>

                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-light" data-dismiss="modal"></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"> Annuler <i class="nav-icon  fas fa-times-circle"></i> </button>
                        <input type="hidden" class="id_profil" >
                        <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">
                      </div>
                    </div>
                  </div>
                  
                </div> -->

                <!-- voir -->
                <div class="modal fade" id="voir">
                  <div class="modal-dialog modal-lg modal-dialog-top">
                    <div class="modal-content bg-light">
                      <div class="modal-header">
                        <h4 class="modal-title text-info"><b><i class='nav-icon fas fa-eye'></i>Voir les informations</b></h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">

                        <div class="col-md-12 col-sm-12">
                          <div class="overflow-hidden">
                            <div class="profile-tab ">
                              <div class="tab ">

                                <ul class="nav nav-tabs customtab" role="tablist">
                                  <li class="nav-item">
                                    <a class="nav-link active" data-toggle="tab" href="#timeline" role="tab">Information</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" data-toggle="tab" href="#tasks" role="tab">Photo</a>
                                  </li>
                                </ul>

                                <div class="tab-content">
                                  
                                  <div class="tab-pane fade show active" id="timeline" role="tabpanel">
                                    <div class="pd-20">

                                      <div class="profile-timeline">

                                        <div class="row">

                                          <div class="col-md-6">
                                            <div class="form-group">
                                              <label>N°Employe</label>
                                              <input type="text" style="border-radius:20px;" class="form-control codeEmployeV"   value="<?php echo $this->ModelEmploye->codeEmploye();?>" disabled="true">
                                            </div>
                                          </div>
                                          
                                          <div class="col-md-6">
                                            <label>Nom</label>
                                            <input type="text" style="border-radius:20px;" class="form-control nomEmployeV" disabled="true">
                                          </div>

                                        </div>

                                        <div class="row">

                                          <div class="col-md-6">
                                            <label>Prenom</label>
                                            <input type="text" style="border-radius:20px;" class="form-control prenomEmployeV" disabled="true">
                                          </div> 

                                          <div class="col-md-6">
                                            <label>Date de Naissance</label>
                                            <div class="input-group ">
                                              <input type="date" style="border-radius:20px;" class="form-control  dateNaissV" disabled="true" />
                                            </div>
                                          </div> 

                                        </div>

                                        <div class="row">

                                          <div class="col-md-6">
                                            <label>Téléphone</label>
                                            <input type="text" style="border-radius:20px;" class="form-control telEmployeV" disabled="true">
                                          </div>
                                          
                                          <div class="col-md-6">
                                            <label>N°CNI</label>
                                            <input type="text" style="border-radius:20px;" class="form-control cniEmployeV" disabled="true">
                                          </div>

                                        </div>

                                        <div class="row">

                                          <div class="col-md-6">
                                            <label>Adresse</label>
                                            <input type="text" style="border-radius:20px;" class="form-control adresseEmployeV"disabled="true">
                                          </div> 

                                          <div class="col-md-6">
                                            <label>Date d'embauche</label>
                                            <div class="input-group ">
                                              <input type="date" style="border-radius:20px;" class="form-control  dateEmbaucheV" disabled="true" />
                                            </div>
                                          </div>  

                                        </div>

                                        <div class="row">

                                          <div class="col-md-6">
                                            <label> Fonction</label>
                                            <select style="border-radius:20px;" class="id_fonctionV form-control" disabled="true">
                                              <option></option>
                                              <?php $this->ModelEmploye->ListeFonction(); ?>
                                            </select>
                                          </div> 

                                          <div class="col-md-4">
                                            <label>Salaire de Base</label>
                                            <input type="text" style="border-radius:20px;" class="form-control salaireV"disabled="true">
                                          </div>

                                          <div class="col-md-2">
                                            <label>Disponible</label>
                                            <input type="checkbox" class="form-control actifEmployeV"disabled="true">
                                          </div>

                                        </div>

                                      </div>

                                    </div>
                                  </div> 

                                  <div class="tab-pane fade show "  id="tasks"role="tabpanel">
                                    <div class="pd-20">

                                      <div class="profile-timeline">

                                        <div class="row clearfix">

                                          <div class="row">

                                            <div class="col-md-6">							    				   
                                              <img class='border-radius-100 box-shadow photoEmployeV' src="" style="width:400px; height:350px;" />
                                            </div> 

                                            <div class="col-md-6">

                                              <div class="col-md-12">
                                                <div class="form-group">
                                                  <label>N°Employe</label>
                                                  <input type="text" style="border-radius:20px;" class="form-control codeEmployeV"   value="<?php echo $this->ModelEmploye->codeEmploye();?>" disabled="true">
                                                </div>
                                              </div>

                                              <div class="col-md-12 mt-3">
                                                <label>Nom</label>
                                                <input type="text" style="border-radius:20px;" class="form-control nomEmployeV" disabled="true">
                                              </div> 

                                              <div class="col-md-12 mt-3">
                                                <label> Fonction</label>
                                                <select style="border-radius:20px;" class="id_fonctionV form-control" disabled="true">
                                                  <option></option>
                                                  <?php $this->ModelEmploye->ListeFonction(); ?>
                                                </select>
                                              </div> 

                                              <div class="col-md-12 mt-3">
                                                <label>Salaire</label>
                                                <input type="text" style="border-radius:20px;" class="form-control salaireV" disabled="true">
                                              </div>  

                                            </div>

                                          </div>
                                        </div> 

                                      </div>

                                    </div>
                                  </div>

                                  

                                   

                                </div>
                                
                              </div>
                            </div>
                          </div>
                        </div> 

                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-light" data-dismiss="modal"></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"> Annuler <i class="nav-icon  fas fa-times-circle"></i> </button>
                        <input type="hidden" class="id_profil" >
                        <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">
                      </div>
                    </div>
                  </div>
                  
                </div>

                <div class="tab-content">
                  <div>
                    <div class="overlay-wrapper">
                      <div class="card-body">
                        <div class="overlay-wrapper" >
                          <div class="overlay light actualisationData" style="display: none;">
                            <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                          </div>

                          <table id="exportData" class="table table-bordered table-striped">
                            <thead>
                              <tr>
                                <th></th>
                                <th class="col-md-3"><i>Nom</i></th>
                                <th class="col-md-2"><i>Prénom</i> </th>
                                <th class="col-md-1"><i>Age</i> </th>
                                <th class="col-md-2"><i>Fonction</i> </th> 
                                <th class="col-md-1"><i>Salaire</i> </th>
                                <th class="col-md-1"><i>Date</i></th> 
                                <th class="col-md-1"><i>Durée</i> </th>
                                <th></th>
                                <th class="col-md-1"><i>Action</i></th>
                              </tr>
                            </thead>
                            <tbody class="tableData">
                              <?php $this->ModelEmploye->afficheDataEmploye(); ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div> 

              </div>

            </div>

          </div>

        </section>
        
      </div>
      
      <?php include 'style/footer.php'; ?>
      <?php include 'style/js.php'; ?>

    </div>
      
    <script src="<?php echo base_url('style/dist/js/adminlte.js'); ?>"></script>
    <script src="<?php echo base_url('style/javascript/JsEmploye.js'); ?>"></script> 
    
    <script>
      $(function () {

        $("#exportData").DataTable
        ({
          "searching": true,dom: 'Bfrtip',
          buttons: 
          [
            { extend:'excelHtml5', autoFilter:true,sheetName:'Exported data',text:"<i class='fab fa-canadian-maple-leaf text-light'></i><b><i>EXCEL</i></b>",
              className: "btn btn-white btn-success btn-bold"
            },
            { extend: "print",text: "<i class='fas fa-archive text-light'></i> <b><i>PRINT</i>",
              className: "btn btn-white btn-danger btn-bold", autoPrint: true,message: 'DURELL :::: FONCTION'
            }
          ]
        });
        $('#exportData1').DataTable;
      })
    </script>

  </body>
</html>
