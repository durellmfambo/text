<?php 
  if ($this->session->userdata('id_profil') == null) {
    redirect(base_url() . "controller/", 'refresh');
  }
?>
<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
      <?php 
        echo $title;  $inventaire = ""; $menuStock=""; $activeGestionStock="";
      ?>
    </title>

    <?php include 'style/css.php'; ?>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('style/vendors/styles/style.css'); ?>" /> 
 
  </head>

  <body class="hold-transition sidebar-mini layout-fixed" >
    <div class="wrapper">
      
      <?php include 'style/right_sidebar.php'; ?>

      
      <div class="content-wrapper">
        
        <div class="content-header" >
          <div class="container-fluid">
            <div class="row mb-3">
              <div class="col-sm-12">
                <h4 style="text-align: center;"><b class="text-primary">Inventaire <i class='nav-icon  fab fa-hotjar'></i></b></h4>
              </div>
            </div>

            <div class="row mb-1">
              <div class="col-md-6">
                <ol class="breadcrumb float-sm-left">
                  <a href="<?php echo base_url('controller/home'); ?>"><li><b class="text-primary "> Home <i class='nav-icon fas fa-angle-right'></i>  </b></li></a></li>
                  <li ><b class="text-success">  <?php echo $title; ?></b></li>
                </ol>
              </div>  
            </div> 
          </div>
        </div> 
        
        <section class="content">

          <div class="container-fluid"> 
            
            <div class="row">
              
              <div class="row">
                <div class="col-md-12 col-sm-12">
                  <div class="tab-content" >
                    <div class="tab-pane fade show active"  aria-labelledby="custom-tabs-one-home-tab ">
                      <div class="overlay-wrapper">
                        <div class="overlay light actualisation" style="display: none;">
                          <i class="fas fa-3x fas fa-spinner fa-spin"></i> 
                        </div> 

                        <div class="card-body">
                          <div class="row">

                            <div class="col-md-2">
                              <label>Date inventaire</label>
                              <input type="text" style="border-radius:20px;" class="dernierInv"  value="<?php echo $this->ModelStock->DernierInventaire(); ?>" disabled="true">
                            </div>

                            <div class="col-md-2">
                              <label>Date</label>
                              <div class="input-group">
                                <input type="date" style="border-radius:20px;" class="form-control  dateInv"  value="<?php echo date('Y-m-d'); ?>">
                                
                              </div>
                            </div> 

                            <div class="col-md-5">
                              <label>Fournisseur</label>
                              <select style="border-radius:20px;" class="id_fournisseur form-control">
                                <option></option>
                                <?php $this->ModelFournisseur->ListeFournisseur(); ?>
                              </select>
                            </div>

                            <div class="col-md-2" >
                              <div class="form-group">
                                <label>Responsable</label>
                                <input type="text" style="border-radius:20px;" class="form-control auteurInv" value="Durell" disabled="true">
                              </div>
                            </div>

                            

                          </div>

                          <div class="row">
                            <div class=" col-md-12">
                              <table class="table">
                                <thead >
                                  <th class="col-md-4"><i>Article</i></th>
                                  <th class="col-md-3"><i>Reférence</i></th>
                                  <th class="col-md-2"><i>Montant</i></th>
                                  <th class="col-md-1"><i>Quantité</i></th>
                                  <th class="col-md-1"><i>Action</i></th>
                                </thead>
                                <tbody class="tableInv">
                                  <?php
                                    $this->ModelStock->tableInventaire();
                                  ?>
                                </tbody>
                              </table>
                            </div>
                          </div>

                        </div>
                      </div>
                      <input type="hidden" class="id_table">
                      <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">

                    </div>

                    
                  </div>
                </div>

                    

                


                <div class="col-md-12 col-sm-12">
                  <div>
                    <div    >
                      <div class="overlay-wrapper">
                        <div class="overlay light actualisationM" style="display: none;">
                          <i class="fas fa-3x fas fa-spinner fa-spin"></i> 
                        </div>
                        <div class="card-body">
                          <div class="row">

                            <div class="col-md-2"></div>
                            
                            <div class="col-md-2">
                              <label>Date</label>
                              <div class="input-group " >
                                <input type="date" style="border-radius:20px;" class="form-control  dateInvM"> 
                              </div>
                            </div>

                            <div class="col-md-4">
                              <label>Fournisseur</label>
                              <select style="border-radius:20px;" class="id_fournisseurM form-control" >
                                <option></option>
                                <?php $this->ModelFournisseur->ListeFournisseur(); ?>
                              </select>
                            </div>

                            <div class="col-md-2">
                              <label>Auteur</label>
                              <input type="text" style="border-radius:20px;" class="form-control auteurInvM"  >
                            </div>
                          </div>

                          <div class="row">

                            <div class="col-md-1"></div>

                            <div class="col-md-4 mt-2">
                              <label>Article</label>
                              <select style="border-radius:20px;" class="id_articleM form-control" onchange="ReferenceArticleM();MontantArticleM();">
                                <option></option>
                                <?php $this->ModelArticle->ListeArticle(); ?>
                              </select>
                            </div>

                            <div class="col-md-3 mt-2">
                              <label>Reference</label>
                              <input type="text" style="border-radius:20px;" class="form-control referenceInvM"  >
                            </div>

                            <div class="col-md-2 mt-2">
                              <label>Prix</label>
                              <input type="text" style="border-radius:20px;" class="form-control prixInvM" >
                            </div>

                            <div class="col-md-1 mt-2">
                              <label>Quantite</label>
                              <input type="text" style="border-radius:20px;" class="form-control qtiteInvM" >
                            </div>

                          </div>

                          <div class="row">
                            <div class="col-md-10"></div> 

                            <div class="col-md-2"><br>
                              <button type="button" class="btn btn-info buttonM" style="display: none;" onclick="modiInventaire('update');">Modifier <i class="nav-icon 	fas fa-pen"></i></button>
                            </div>
                          </div>

                        </div>

                      </div>
                      <input type="hidden" class="id_modi">
                      <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">

                    </div>

                    
                  </div>
                </div>


                <div class="col-md-12"> 
                  <div class="card-body">
                    <div class="row">

                      <div class="col-md-3"></div>

                      <div class="col-md-2">
                        <div class="form-group"> 
                          <label><i>Date debut</i> </label>
                          <div class="input-group " >
                            <input type="date" style="border-radius:20px;" class="form-control  dateDebut "  onchange="triDateInventaire();" />
                            
                          </div>
                        </div>
                      </div>

                      <div class="col-md-2">
                        <div class="form-group">          
                          <label><i>Date fin </i></label>
                          <div class="input-group " >
                            <input type="date" style="border-radius:20px;" class="form-control  dateFin"  value="<?php echo date('Y-m-d'); ?>"onchange="triDateInventaire();" />
                            
                          </div>
                        </div>
                      </div>
                
                      <div class="col-md-3">
                        <div class="form-group">
                          <label><i>Fournisseur</i></label>
                          <select style="border-radius:20px;" class="id_nom form-control" onchange="triDateInventaire();" >
                            <option>ALL</option>
                            <?php $this->ModelFournisseur->ListeFournisseur(); ?>
                          </select>
                        </div>
                      </div>

                      <div class="col-md-3"></div>
                    </div>
                  </div>
                </div>

                <div class="col-12 col-sm-12"> 

                  <div class="card card-primary card-tabs">

                    <!-- supprimer -->
                    <div class="modal fade" id="supprimer">
                      <div class="modal-dialog">
                        <div class="modal-content bg-light">
                          <div class="modal-header">
                            <h4 class="modal-title text-danger"><b><i class='nav-icon fas fa-trash'></i>Suppression</b></h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span></button>
                          </div>
                          <div class="modal-body">
                            <b class="text-danger"> Validez la suppression</b>
                          </div>
                          <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler <i class="nav-icon  fas fa-times-circle"></i></button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal"onclick="dropInventaire();">
                              Validez<i class="nav-icon fas fa-check-double"></i>
                            </button>
                            <input type="hidden" class="a">  <input type="hidden" class="b"> <input type="hidden" class="c">
                          </div>
                        </div>
                      </div>
                      
                    </div>
        
                    <!-- voir -->
                    <div class="modal fade" id="voir">
                      <div class="modal-dialog modal-lg modal-dialog-top">
                        <div class="modal-content bg-light">
                          <div class="modal-header">
                            <h4 class="modal-title text-info"><b><i class='nav-icon fas fa-eye'></i>Voir les informations</b></h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <div class="row">

                              <div class="col-md-6">
                                <label>Fournisseur</label>
                                <select style="border-radius:20px;" class="id_fournisseurV form-control" disabled="true">
                                  <option></option>
                                  <?php $this->ModelFournisseur->ListeFournisseur(); ?>
                                </select>
                              </div>

                              <div class="col-md-6">
                                <label>Date </label>
                                <div class="input-group " >
                                  <input type="date" style="border-radius:20px;" class="form-control  dateInvV"disabled="true"> 
                                </div>
                              </div>

                            </div>
 
                            <div class="row">

                              <div class="col-md-6 mt-2">
                                <label>Article</label>
                                <select style="border-radius:20px;" class="id_articleV form-control" disabled="true">
                                  <option></option>
                                  <?php $this->ModelArticle->ListeArticle(); ?>
                                </select>
                              </div>

                              <div class="col-md-6 mt-2">
                                <label>Reference</label>
                                <input type="text" style="border-radius:20px;" class="form-control referenceInvV" disabled="true">
                              </div>

                            </div>

                            <div class="row">
 
                              <div class="col-md-6 mt-2">
                                <label>Auteur </label>
                                <input type="text" style="border-radius:20px;" class="form-control auteurInvV"  disabled="true">
                              </div>

                              <div class="col-md-3 mt-2">
                                <label>Prix</label>
                                <input type="text" style="border-radius:20px;" class="form-control prixInvV" disabled="true">
                              </div>

                              <div class="col-md-3 mt-2">
                                <label>Quantite</label>
                                <input type="text" style="border-radius:20px;" class="form-control qtiteInvV" disabled="true">
                              </div>

                            </div>

                            
                          </div>
                          <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-light" data-dismiss="modal"></button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal"> Annuler <i class="nav-icon  fas fa-times-circle"></i> </button>
                            <input type="hidden" class="id_profil">
                            <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">
                          </div>
                        </div>
                      </div>
                      
                    </div>  
                  </div> 

                  <div class="tab-content">
                    <div>
                      <div class="overlay-wrapper">

                        <div class="card-body">
                          <div class="overlay-wrapper">
                            <div class="overlay light actualisationData" style="display: none;">
                              <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                            </div>
                            <table id="exportData" class="table table-bordered table-striped"> 

                              <thead>
                                <tr>
                                  <th></th>
                                  <th class="col-md-2"><i>Fournisseur</i></th>
                                  <th class="col-md-3"><i>Nom Article</i></th>
                                  <th class="col-md-3"><i>Refence</i></th>
                                  <th class="col-md-1"><i>Montant</i></th>
                                  <th class="col-md-1"><i>Qtite</i></th>
                                  <th class="col-md-1"><i>Date</i></th>
                                  <th class="col-md-1"><i>Action</i></th>
                                </tr>
                              </thead>
                              <tbody class="tableData">
                                <?php $this->ModelStock->afficheDataInventaire(); ?>
                              </tbody>
                            </table>
                          </div>
                        </div>
                        
                      </div>
                    </div> 
                  </div>

                </div>

                
              </div>

            </div>
            
          </div>
        </section>
      
      </div>
    
      <?php include 'style/footer.php'; ?> 
      <?php include 'style/js.php'; ?>
    </div> 

    <script src="<?php echo base_url('style/dist/js/adminlte.js'); ?>"></script> 
    <script src="<?php echo base_url(); ?>style/javascript/jsStock.js"></script>
    
    <script>
      $(function () {

        $("#exportData").DataTable
        ({
          "searching": true,dom: 'Bfrtip',
          buttons: 
          [
            
            { extend:'excelHtml5', autoFilter:true,sheetName:'Exported data',text:"<i class='fab fa-canadian-maple-leaf text-light'></i><b><i>EXCEL</i></b>",
              className: "btn btn-white btn-success btn-bold"
            },
            { extend: "print",text: "<i class='fas fa-archive bigger-110 text-light'></i> <b><i>PRINT</i>",
              className: "btn btn-white btn-danger btn-bold", autoPrint: true,message: 'DURELL :::: Inventaire'
            }
          ]
        });
        $('#exportData1').DataTable;
      })
    </script>
     
  </body>

</html>