<?php 
  if($this->session->userdata('id_profil')==null){
    redirect(base_url()."controller/", 'refresh');
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
      <?php 
        echo $title;   $sortie = ""; $menuStock="";  $activeGestionStock="";
      ?>
    </title>
    
    <?php include 'style/css.php'; ?>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('style/vendors/styles/style.css'); ?>" /> 
  </head>
  <body class="hold-transition sidebar-mini layout-fixed">

    <div class="wrapper">
      
      <?php include 'style/right_sidebar.php'; ?>
      
      <div class="content-wrapper">
        
        <div class="content-header" >
          <div class="container-fluid">
            <div class="row mb-1">
              <div class="col-sm-12">
                <h4 style="text-align: center;"><b class="text-primary">Ajouter une Sortie  <i class='nav-icon fab fa-buysellads'></i></b></h4>
              </div>
            
            </div>

            <div class="row">
              <div class="col-sm-12">
                <ol class="breadcrumb float-sm-left">
                  <a href="<?php echo base_url('controller/home'); ?>"><li><b class="text-primary "> Home <i class='nav-icon fas fa-angle-right'></i>  </b></li></a></li>
                  <li ><b class="text-success">  <?php echo $title; ?></b></li>
                </ol>
              </div>
            
            </div>
            
          </div>
        </div>
        

        <section class="content">

          <div class="container-fluid">

            <div class="row">

              <div class="col-md-12 col-sm-12">

                <div class="tab-content" >

                  <div class="tab-pane fade show active" aria-labelledby="custom-tabs-one-home-tab ">

                    <div class="overlay-wrapper">

                      <div class="overlay light actualisation" style="display: none;">
                        <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                      </div>
                    
                      <div class="card-body">
                        
                        <div class="row">

                          <div class="col-md-2">
                            <label>Date </label>
                            <div class="input-group ">
                              <input type="date" style="border-radius:20px;" class="form-control  date" value="<?php echo date('Y-m-d'); ?>" />
                            </div>
                          </div>

                          <div class="col-md-2">
                            <div class="form-group">
                              <label>N°Facture</label>
                              <select style="border-radius:20px;" class="numero form-control">
                                <option></option>
                                <?php $this->ModelClient->ListeFactureClient(); ?>
                              </select>
                            </div>
                            
                          </div>

                          <div class="col-md-4">
                            <label> Client</label>
                            <select style="border-radius:20px;" class="id_client form-control"  >
                              <option></option>
                              <?php $this->ModelClient->ListeClient(); ?>
                            </select>
                          </div>
 
                          <div class="col-md-4">
                            <label>Article</label>
                            <select style="border-radius:20px;" class="id_article form-control"  onchange="MontantArticleM();ReferenceArticleM();StockArticle();prixDeVente(); ">
                              <option></option>
                              <?php $this->ModelArticle->ListeArticle(); ?>
                            </select>
                          </div>

                          <div class="col-md-3 mt-1">
                            <label>Reference</label>
                            <input type="text" style="border-radius:20px;" class="form-control referenceArticle " placeholder="reference"disabled="true">
                          </div>

                          <div class="col-md-2 mt-1">
                            <label>Montant</label>
                            <input type="text" style="border-radius:20px;" class="form-control montantArticle" placeholder="Montant" onkeypress="chiffres(event);" onkeyup="separateurMIllier('montantArticle');"disabled="true">
                          </div> 

                          <div class="col-md-2 mt-1">
                            <label>Prix Vente</label>
                            <input type="text" style="border-radius:20px;" class="form-control prixVente" placeholder="prixVente" onkeypress="chiffres(event);" onkeyup="separateurMIllier('prixVente');"disabled="true">
                          </div> 

                          <div class="col-md-1 mt-1">
                            <label>Stock</label>
                            <input type="text" style="border-radius:20px;" class="form-control stock" placeholder="0"disabled="true">
                          </div>

                          <div class="col-md-1 mt-1">
                            <label>Qte</label>
                            <input type="text" style="border-radius:20px;" class="form-control qtite " onkeypress="chiffres(event);" placeholder="0" >
                          </div>

                          <div class="col-md-1 mt-1"> 
                            <label>TVA</label>
                            <select style="border-radius:20px;" class="tva form-control"onchange="TVA();">
                              <option></option>
                              <option>NON</option> 
                              <option>OUI</option>
                            </select>
                          </div>
                          <div class="col-md-2 mt-1">
                            <label>montantTva</label>
                            <input type="text" style="border-radius:20px;" class="form-control montantTva " placeholder="Montant"  onkeyup="separateurMIllier('newMontant');"disabled="true">
                          </div>

                          

                        </div>

                        <div class="row">

                          <div class="col-md-10"></div>

                          <div class="col-md-2">
                            <br>
                            <?php
                              if($this->session->userdata('autoStock_ajout') == "true") {
                                echo '<button type="button" class="btn btn-dark buttonA" onclick="ajoutSortie(\'ajouter\');">Ajouter <i class="nav-icon fas fa-plus-circle"></i></button>';
                              }
                            ?>
                            <button type="button" class="btn btn-info buttonM" style="display: none;" onclick="ajoutSortie('modifier');">Modifier <i class="nav-icon 	fas fa-pen"></i></button>
                          </div>

                        </div>

                      </div>

                    </div>

                    <input type="hidden" class="id_table" >
                    <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">

                  </div>

                  
                </div>

              </div>

              <div class="col-md-12"> 
                <div class="card-body">
                  <div class="row">

                    <div class="col-md-3"></div>

                    <div class="col-md-2">
                      <div class="form-group"> 
                        <label><i>Date debut</i> </label>
                        <div class="input-group " >
                          <input type="date" style="border-radius:20px;" class="form-control  dateDebut "  onchange="triDateSortie();" />
                          
                        </div>
                      </div>
                    </div>

                    <div class="col-md-2">
                      <div class="form-group">          
                        <label><i>Date fin </i></label>
                        <div class="input-group " >
                          <input type="date" style="border-radius:20px;" class="form-control  dateFin"  value="<?php echo date('Y-m-d'); ?>"onchange="triDateSortie();" />
                          
                        </div>
                      </div>
                    </div>
              
                    <div class="col-md-3">
                      <div class="form-group">
                        <label><i>Fournisseur</i></label>
                        <select style="border-radius:20px;" class="id_nom form-control" onchange="triDateSortie();" >
                          <option>ALL</option>
                          <?php $this->ModelClient->ListeClient(); ?>
                        </select>
                      </div>
                    </div>

                    <div class="col-md-3"></div>
                  </div>
                </div>
              </div>
              
              <div class="col-12 col-sm-12">
                
                <!-- supprimer -->
                <div class="modal fade" id="supprimer">
                  <div class="modal-dialog">
                    <div class="modal-content bg-light">
                      <div class="modal-header">
                        <h4 class="modal-title text-danger"><b><i class='nav-icon fas fa-trash'></i>Suppression</b></h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span></button>
                      </div>
                      <div class="modal-body">
                      <h6  style="text-align: center;"> <b class="text-danger"> Validez la suppression </b></h6>
                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler <i class="nav-icon  fas fa-times-circle"></i></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"
                          onclick="dropSortie();">Valider <i class="nav-icon fas fa-check-double"></i>
                        </button>
                        <input type="hidden" class="a" >  <input type="hidden" class="b" > <input type="hidden" class="c" >
                      </div>
                    </div>
                  </div>
                  
                </div>

                <!-- voir -->
                <div class="modal fade" id="voir">
                  <div class="modal-dialog modal-lg modal-dialog-center">
                    <div class="modal-content bg-light">
                      <div class="modal-header">
                        <h4 class="modal-title text-info"><b><i class='nav-icon fas fa-eye'></i>Voir les informations</b></h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">

                        <div class="row">

                          <div class="col-md-6">
                            <label>Date </label>
                            <div class="input-group ">
                              <input type="date" style="border-radius:20px;" class="form-control  dateArticleV" value="<?php echo date('Y-m-d'); ?>" disabled="true"/>
                            </div>
                          </div>

                          <div class="col-md-6" >
                            <div class="form-group">
                              <label>N°Facture</label>
                              <input type="text" style="border-radius:20px;" class="form-control numeroV"   value="<?php echo $this->ModelArticle->codeArticle();?>" disabled="true">
                            </div>
                          </div> 
                          
                        </div>

                        <div class="row">

                          <div class="col-md-6 mt-1">
                            <label>Client</label>
                            <select style="border-radius:20px;" class="id_clientV form-control" disabled="true">
                              <option></option>
                              <?php $this->ModelClient->ListeClient(); ?>
                            </select>
                          </div>
                          
                          <div class="col-md-6 mt-1">
                            <label>Article</label>
                            <select style="border-radius:20px;" class="id_articleV form-control" disabled="true">
                              <option></option>
                              <?php $this->ModelArticle->ListeArticle(); ?>
                            </select>
                          </div> 

                        </div>

                        <div class="row">

                          <div class="col-md-4 mt-1">
                            <label>Montant</label>
                            <input type="text" style="border-radius:20px;" class="form-control montantArticleV " disabled="true" >
                          </div>

                          <div class="col-md-2 mt-1">
                            <label>Quantite</label>
                            <input type="text" style="border-radius:20px;" class="form-control qtiteV " disabled="true" >
                          </div> 

                          <div class="col-md-2 mt-1">
                            <label>Tva</label>
                            <input type="text" style="border-radius:20px;" class="form-control tvaV " disabled="true" >
                          </div> 

                          <div class="col-md-4 mt-1">
                            <label>Montant Total</label>
                            <input type="text" style="border-radius:20px;" class="form-control montantTvaV " disabled="true" >
                          </div>

                        </div>

                        <div class="row">
                          
                          <div class="col-md-12 mt-1">
                            <label>Reference</label>
                            <input type="text" style="border-radius:20px;" class="form-control referenceArticleV "disabled="true">
                          </div>

                        </div>

                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-light" data-dismiss="modal"></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"> Annuler <i class="nav-icon  fas fa-times-circle"></i> </button>
                        <input type="hidden" class="id_profil" >
                        <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">
                      </div>
                    </div>
                  </div>
                  
                </div>

                <div class="tab-content">
                  <div>
                    <div class="overlay-wrapper">
                      <div class="card-body">
                        <div class="overlay-wrapper" >
                          <div class="overlay light actualisationData" style="display: none;">
                            <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                          </div>

                          <table id="exportData" class="table table-bordered table-striped">
                            <thead>
                              <tr>
                                <th></th>
                                <th class="col-md-1"><i>Facture</i></th> 
                                <th class="col-md-3"><i>Nom Article</i></th>
                                <th class="col-md-2"><i>Montant</i></th>
                                <th class="col-md-1"><i>Qtité</i></th>
                                <th class="col-md-2"><i>PrixTotal</i></th> 
                                <th class="col-md-1"><i>tva</i></th>
                                <th class="col-md-2"><i>Total Tva</i></th>
                                <th class="col-md-1"><i>Date</i></th> 
                                <th><i>Action</i></th>
                              </tr>
                            </thead>
                            <tbody class="tableData">
                              <?php $this->ModelStock->afficheDataSortie(); ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div> 

                

              </div>

            </div>

          </div>

        </section>
        
      </div>
      
      <?php include 'style/footer.php'; ?>
      <?php include 'style/js.php'; ?>

    </div>
      
    <script src="<?php echo base_url('style/dist/js/adminlte.js'); ?>"></script>
    <script src="<?php echo base_url(); ?>style/javascript/jsStock.js"></script>
    
    <script>
      $(function () {

        $("#exportData").DataTable
        ({
          "searching": true,dom: 'Bfrtip',
          buttons: 
          [
            
            { extend:'excelHtml5', autoFilter:true,sheetName:'Exported data',text:"<i class='fab fa-canadian-maple-leaf text-light'></i><b><i>EXCEL</i></b>",
              className: "btn btn-white btn-success btn-bold"
            },
            { extend: "print",text: "<i class='fas fa-archive bigger-110 text-light'></i> <b><i>PRINT</i>",
              className: "btn btn-white btn-danger btn-bold", autoPrint: true,message: 'DURELL :::: Sortie'
            }
          ]
        });
        $('#exportData1').DataTable;
      })
    </script>

  </body>
</html>
