<?php 
  if($this->session->userdata('id_profil')==null){
    redirect(base_url()."controller/", 'refresh');
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
      <?php 
        echo $title; $securite=""; $menuUtilisateur=""; $activeUtilisateur="";
      ?>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php include 'style/css.php'; ?>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('style/vendors/styles/style.css'); ?>" /> 

  </head>

  <body class="hold-transition sidebar-mini layout-fixed">

    <div class="wrapper">
      
      <?php include 'style/right_sidebar.php';?>
      
      <div class="content-wrapper">

        <div class="content-header" >
          <div class="container-fluid">
            <div class="row mb-3">
              <div class="col-sm-12">
                <h4 style="text-align: center;"><b class="text-primary">Selectionner une periode <i class='nav-icon fas fas fa-calendar-alt'></i></b></h4>
              </div>
            
            </div>

            <div class="row mb-1">
              <div class="col-sm-12">
                <ol class="breadcrumb float-sm-left">
                  <a href="<?php echo base_url('controller/home'); ?>"><li><b class="text-primary "> Home <i class='nav-icon fas fa-angle-right'></i>  </b></li></a></li>
                  <li ><b class="text-success">  <?php echo $title; ?></b></li>
                </ol>
              </div>
            
            </div>
            
          </div>
        </div>
        

        
        <section class="content">
          <div class="container-fluid">

            <div class="row">

              <div class="col-md-12"> 
                  <div class="card-body">
                    <div class="row">

                      <div class="col-md-3"></div>

                      <div class="col-md-2">
                        <div class="form-group"> 
                          <label><i>Date debut</i> </label>
                          <div class="input-group " >
                            <input type="date" style="border-radius:20px;" class="form-control  dateDebut "  onchange="triDateNotification();" />
                            
                          </div>
                        </div>
                      </div>

                      <div class="col-md-2">
                        <div class="form-group">          
                          <label><i>Date fin </i></label>
                          <div class="input-group " >
                            <input type="date" style="border-radius:20px;" class="form-control  dateFin"  value="<?php echo date('Y-m-d'); ?>"onchange="triDateNotification();" />
                            
                          </div>
                        </div>
                      </div>
                
                      <div class="col-md-3">
                        <div class="form-group">
                          <label><i>Utilisateur</i></label>
                          <select style="border-radius:20px;" class="id_nom form-control" onchange="triDateNotification();" >
                            <option>ALL</option>
                            <?php $this->ModelUser->ListeUsers(); ?>
                          </select>
                        </div>
                      </div>

                      <div class="col-md-3"></div>
                    </div>
                  </div>
                </div>

              
              <div class="col-12 col-sm-12" style="overflow: auto;">
 

                <div class="tab-content" >
                  <div>
                    <div class="overlay-wrapper">
                      <input type="hidden">

                        <div class="card-body">
                          <div class="overlay-wrapper">
                            <div class="overlay light InitialisationData" style="display: none;">
                              <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                            </div>
                            <table id="exportData" class="table table-bordered table-striped">
                            <thead>
                              <tr>
                                <th class="col-md-1"></th>
                                <th class="col-md-2"><i>Machine</i></th>
                                <th class="col-md-1"><i>Date</i></th>
                                <th class="col-md-1"><i>Heure</i></th>
                                <th class="col-md-8"><i>Message</i></th>
                              </tr>
                            </thead>
                            <tbody class="tableData"><?php ?></tbody>
                          </table>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
      </div>

      <?php include 'style/footer.php'; ?>

      <?php include 'style/js.php'; ?>

    </div>

    <script src="<?php echo base_url('style/dist/js/adminlte.js'); ?>"></script>
    <script src="<?php echo base_url('style/javascript/jsUser.js'); ?>"></script>
    
    <script>
      $(function () {

        $("#exportData").DataTable
        ({
          "searching": true,dom: 'Bfrtip',
          buttons: 
          [
            
            { extend:'excelHtml5', autoFilter:true,sheetName:'Exported data',text:"<i class='fab fa-canadian-maple-leaf text-light'></i><b><i>EXCEL</i></b>",
              className: "btn btn-white btn-success btn-bold"
            },
            { extend: "print",text: "<i class='fas fa-archive bigger-110 text-light'></i> <b><i>PRINT</i>",
              className: "btn btn-white btn-danger btn-bold", autoPrint: true,message: 'DURELL :::: Securite'
            }
          ]
        });
        $('#exportData1').DataTable;
      })
    </script>

  </body>
</html>
