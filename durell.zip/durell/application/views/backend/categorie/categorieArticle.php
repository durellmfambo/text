<?php 
  if($this->session->userdata('id_profil')==null){
    redirect(base_url()."controller/", 'refresh');
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
      <?php 
        echo $title;   $categorieArticle = "";  $menuArticle = "";  $activeArticle = "";
      ?>
    </title>
    
    <?php include 'style/css.php'; ?>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('style/vendors/styles/style.css'); ?>" /> 
  </head>
  <body class="hold-transition sidebar-mini layout-fixed">

    <div class="wrapper">
      
      <?php include 'style/right_sidebar.php'; ?>
      
      <div class="content-wrapper">
        
        <div class="content-header" >
          <div class="container-fluid">
            <div class="row mb-3">
              <div class="col-sm-12">
                <h4 style="text-align: center;"><b class="text-primary">Ajouter un  categorie  <i class='nav-icon fas fa-tasks'></i></b></h4>
              </div>
            
            </div>

            <div class="row mb-1">
              <div class="col-sm-12">
                <ol class="breadcrumb float-sm-left">
                  <a href="<?php echo base_url('controller/home'); ?>"><li><b class="text-primary "> Home <i class='nav-icon fas fa-angle-right'></i>  </b></li></a></li>
                  <li ><b class="text-success">  <?php echo $title; ?></b></li>
                </ol>
              </div>
            
            </div>
            
          </div>
        </div>
        

        <section class="content">

          <div class="container-fluid">

            <div class="row">

              <div class="col-md-12 col-sm-12">

                <div class="tab-content" >

                  <div class="tab-pane fade show active" aria-labelledby="custom-tabs-one-home-tab ">

                    <div class="overlay-wrapper">

                      <div class="overlay light actualisation" style="display: none;">
                        <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                      </div>
                    
                      <div class="card-body">
                        
                        <div class="row">

                          <div class="col-md-2" >
                            <div class="form-group">
                              <label>N°Categorie</label>
                              <input type="text" style="border-radius:20px;" class="form-control codeCatego"   value="<?php echo $this->ModelArticle->codeCategorieArticle();?>" disabled="true">
                            </div>
                          </div>
                          
                          <div class="col-md-4">
                            <label>Nom categorie</label>
                            <input type="text" style="border-radius:20px;" class="form-control nomCatego" placeholder="Nom">
                          </div>

                          <div class="col-md-3 ">
                            <label>Commentaire</label>
                            <input type="text" style="border-radius:20px;" class="form-control commentaireCatego" placeholder="Commentaire">
                          </div>

                          <div class="col-md-2">
                            <label>Date  </label>
                            <div class="input-group ">
                              <input type="date" style="border-radius:20px;" class="form-control  dateCatego" value="<?php echo date('Y-m-d'); ?>" />
                              
                            </div>
                          </div>

                          <div class="col-md-1">
                            <label>DISPONIBLE</label>
                            <input type="checkbox" class="form-control actifCatego">
                          </div>

                        </div>

                        <div class="row">

                          <div class="col-md-10"></div>

                          <div class="col-md-2">
                            <br>
                            <?php
                              if($this->session->userdata('autoArticle_ajout') == "true") {
                                echo '<button type="button" class="btn btn-dark buttonA" onclick="ajoutCategorieArticle(\'ajouter\');">Ajouter <i class="nav-icon fas fa-plus-circle"></i></button>';
                              }
                            ?>
                            <button type="button" class="btn btn-info buttonM" style="display: none;" onclick="ajoutCategorieArticle('modifier');">Modifier <i class="nav-icon 	fas fa-pen"></i></button>
                          </div>

                        </div>

                      </div>

                    </div>

                    <input type="hidden" class="id_table" >
                    <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">

                  </div>

                  
                </div>

              </div>

              <div class="col-12 col-sm-12">
                
                 <!-- supprimer -->
                <div class="modal fade" id="supprimer">
                  <div class="modal-dialog">
                    <div class="modal-content bg-light">
                      <div class="modal-header">
                        <h4 class="modal-title text-danger"><b><i class='nav-icon fas fa-trash'></i>Suppression</b></h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span></button>
                      </div>
                      <div class="modal-body">
                      <h6  style="text-align: center;"> <b class="text-danger"> Validez la suppression </b></h6>
                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler <i class="nav-icon  fas fa-times-circle"></i></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"
                          onclick="dropCategorieArticle();">Valider <i class="nav-icon fas fa-check-double"></i>
                        </button>
                        <input type="hidden" class="a" >  <input type="hidden" class="b" >  <input type="hidden" class="c" >
                      </div>
                    </div>
                  </div>
                </div>

                

                <!-- voir -->
                <div class="modal fade" id="voir">
                  <div class="modal-dialog modal-lg modal-dialog-top">
                    <div class="modal-content bg-light">
                      <div class="modal-header">
                        <h4 class="modal-title text-info"><b><i class='nav-icon fas fa-eye'></i>Voir les informations</b></h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">

                        <div class="row">

                          <div class="col-md-8">
                            <label>Nom Categorie</label>
                            <input type="text" style="border-radius:20px;" class="form-control nomCategoV" disabled="true">
                          </div>
                          
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>N°Categorie</label>
                              <input type="text" style="border-radius:20px;" class="form-control codeCategoV" disabled="true">
                            </div>
                          </div>

                        </div>

                        <div class="row">

                          <div class="col-md-8 mt-4">
                            <label>Commantaire</label>
                            <input type="text" style="border-radius:20px;" class="form-control commentaireCategoV"disabled="true">
                          </div>

                          <div class="col-md-3 mt-4">
                            <label>Date  </label>
                            <div class="input-group ">
                              <input type="date" style="border-radius:20px;" class="form-control  dateCategoV" data-target="#reservationdate" disabled="true"/>
                              <div class="input-group-append" data-target="#reservationdate" data-toggle="datetimepicker">
                              </div>
                            </div>
                          </div>

                          <div class="col-md-1 mt-4">
                            <label>DISPO</label>
                            <input type="checkbox" class="form-control actifCategoV"disabled="true">
                          </div>

                        </div>

                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-light" data-dismiss="modal"></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"> Annuler <i class="nav-icon  fas fa-times-circle"></i> </button>
                        <input type="hidden" class="id_profil" >
                        <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">
                      </div>
                    </div>
                  </div>
                  
                </div>

                <div class="tab-content">
                  <div>
                    <div class="overlay-wrapper">
                      <div class="card-body">
                        <div class="overlay-wrapper" >
                          <div class="overlay light actualisationData" style="display: none;">
                            <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                          </div>

                          <table id="exportData" class="table table-bordered table-striped">
                            <thead>
                              <tr>
                                <th></th>
                                <th class="col-md-1"><i>Code</i></th>
                                <th class="col-md-7"><i>Nom</i></th>
                                <th class="col-md-2"><i>Date</i></th>
                                <th></th>
                                <th class="col-md-1"><i>Action</i></th>
                              </tr>
                            </thead>
                            <tbody class="tableData">
                              <?php $this->ModelArticle->afficheDataCategorieArticle(); ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div> 

              </div>

            </div>

          </div>

        </section>
        
      </div>
      
      <?php include 'style/footer.php'; ?>
      <?php include 'style/js.php'; ?>

    </div>
      
    <script src="<?php echo base_url('style/dist/js/adminlte.js'); ?>"></script>
    <script src="<?php echo base_url('style/javascript/JsArticle.js'); ?>"></script> 
    
    <script>
      $(function () {

        $("#exportData").DataTable
        ({
          "searching": true,dom: 'Bfrtip',
          buttons: 
          [
            { extend:'excelHtml5', autoFilter:true,sheetName:'Exported data',text:"<i class='fab fa-canadian-maple-leaf text-light'></i><b><i>EXCEL</i></b>",
              className: "btn btn-white btn-success btn-bold"
            },
            { extend: "print",text: "<i class='fas fa-archive bigger-110 text-light'></i> <b><i>PRINT</i>",
              className: "btn btn-white btn-danger btn-bold", autoPrint: true,message: 'DURELL :::: CATEGORIE'
            }
          ]
        });
        $('#exportData1').DataTable;
      })
    </script>

  </body>
</html>
