<?php 
  if ($this->session->userdata('id_profil') == null) {
    redirect(base_url() . "controller/", 'refresh');
  }
?>
<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
      <?php 
        echo $title;  $commandeFournisseur = "";  $menuFournisseur = "";  $activeFournisseur = "";
      ?>
    </title>
    
    
    <?php include 'style/css.php'; ?>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('style/vendors/styles/style.css'); ?>" /> 

  </head>

  <body class="hold-transition sidebar-mini layout-fixed" >
    <div class="wrapper">
      
      <?php include 'style/right_sidebar.php'; ?>

      
      <div class="content-wrapper">
        
        <div class="content-header" >
          <div class="container-fluid">
            <div class="row mb-3">
              <div class="col-sm-12">
                <h4 style="text-align: center;"><b class="text-primary">Ajouter une commande  <i class='nav-icon fas fa-cart-plus'></i></b></h4>
              </div>
            
            </div>

            <div class="row mb-1">
              <div class="col-sm-12">
                <ol class="breadcrumb float-sm-left">
                  <a href="<?php echo base_url('controller/home'); ?>"><li><b class="text-primary "> Home <i class='nav-icon fas fa-angle-right'></i>  </b></li></a></li>
                  <li><b class="text-success">  <?php echo $title; ?></b></li>
                </ol>
              </div>
            
            </div>
            
          </div>
        </div>
        

        
        <section class="content">

          <div class="container-fluid">

            <div class="row">
              <div class="row">
                
                <div class="col-md-12 col-sm-12">
                  <div class="tab-content" >
                    <div class="tab-pane fade show active" aria-labelledby="custom-tabs-one-home-tab ">
                      <div class="overlay-wrapper">

                        <div class="overlay light actualisation" style="display: none;">
                          <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                        </div>
                        
                        <a href="#modi"></a>

                          <div class="card-body">

                            <h5 id="modi"></h5>
                            <div class="row">

                              <div class="col-md-2" >
                                <div class="form-group">
                                  <label>N°Commande</label>
                                  <input type="text" style="border-radius:20px;" class="form-control codeCom" disabled="true"  value="<?php echo $this->ModelArticle->codeCommande();?>">
                                </div>
                              </div>

                              <div class="col-md-4" >
                                <div class="form-group">
                                  <label>Fournisseur</label>
                                  <select style="border-radius:20px;" class="id_fournisseur form-control" onchange ="CodeFournisseur();AdresseFournisseur();TelFournisseur();">
                                    <option></option>
                                    <?php $this->ModelFournisseur->ListeFournisseur(); ?>
                                  </select>
                                </div>
                              </div>

                              <div class="col-md-2">
                                <div class="form-group">
                                  <label>CodeFour</label>
                                  <input type= "text" style="border-radius:20px;" class="form-control codeFour"disabled = "true"  disabled="true">
                                </div>
                              </div>

                              <div class="col-md-2">
                                <div class="form-group">
                                  <label>Adresse</label>
                                  <input type= "text" style="border-radius:20px;" class="form-control adresseFour" disabled = "true"  disabled="true">
                                </div>
                              </div>
                              
                              <div class="col-md-2">
                                <label>Telephone</label>
                                <input type="text" style="border-radius:20px;" class="form-control telFour"  disabled="true">
                              </div>

                              <div class="col-md-2">
                                <label>Date création:</label>
                                <div class="input-group " >
                                  <input type="date" style="border-radius:20px;" class="form-control  dateCrea"  value="<?php echo date('Y-m-d'); ?>"  >
                                  
                                </div>
                              </div>

                              <div class="col-md-2">
                                <label>Date commande:</label>
                                <div class="input-group " >
                                  <input type="date" style="border-radius:20px;" class="form-control  dateCom"  value="<?php echo date('Y-m-d'); ?>" >
                                  
                                </div>
                              </div>


                              <?php 					
					                      if ($this->session->userdata('identifiant')=='durell' ) {

                                  echo '
                                  <div class="col-md-1">
                                    <label>Valide </label>
                                    <input type="checkbox"  class="form-control valideCom" >
                                  </div> ';
						                    }
                              ?> 
                              
                            </div>

                            <h5 id="modi"></h5>
  
                            <div class="row mb-2">

                              <div class="col-md-8"></div>
                              <div class="col-md-3"></div>
                              <div class="col-md-1">
                                <select style="border-radius:20px;" class="form-control nbreLigne" onchange="allLigneCommande();">
                                  <option></option>
                                  <option>1</option>                         <option>2</option>         
                                  <option>3</option>                         <option>4</option>
                                  <option>5</option>                         <option>6</option>
                                  <option>7</option>                         <option>8</option>
                                  <option>9</option>                         <option>10</option>
                                  <option>11</option>                        <option>12</option>
                                  <option>13</option>                        <option>14</option>
                                </select>
                              </div> 
                               
                            </div>

                            <div class="allLigne"></div>

                             

                            <div class="row">

                              <div class="col-md-7"></div>

                              <div class="col-md-2">
                                <br>
                                <?php
                                  if($this->session->userdata('autoArticle_ajout') == "true") {
                                    echo '<button type="button" class="btn btn-dark buttonA" onclick="ajoutCommande(\'ajouter\');">Ajouter <i class="nav-icon fas fa-plus-circle"></i></button>';
                                  }
                                ?>
                                <button type="button" class="btn btn-info buttonM" style="display: none;" onclick="ajoutCommande('modifier');">Modifier <i class="nav-icon 	fas fa-pen"></i></button>
                              </div>

                              <div class="col-md-3 "></div>

                            </div>

                          </div>
                      </div>
                      
                      <input type="hidden" class="id_table" >
                      <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">

                    </div>

                    
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="card-body">
                    <div class="row">

                      <div class="col-md-3"></div>

                      <div class="col-md-2">
                        <div class="form-group">          
                          <label><i>Date debut </i> </label>
                          <div class="input-group " >
                            <input type="date" style="border-radius:20px;" class="form-control  dateDebut"  onchange="triCommandeDate();"/>
                            
                          </div>
                        </div>
                      </div>

                      <div class="col-md-2">
                        <div class="form-group">          
                          <label><i>Date fin </i> </label>
                          <div class="input-group " >
                            <input type="date" style="border-radius:20px;" class="form-control  dateFin"  value="<?php echo date('Y-m-d'); ?>"  onchange="triCommandeDate();"/>
                            
                          </div>
                        </div>
                      </div>
                
                      <div class="col-md-3">
                        <div class="form-group">
                          <label><i>Fournisseur </i></label>
                            <select style="border-radius:20px;" class="id_nom form-control" onchange="triCommandeDate();">
                              <option value="TOUT">TOUT</option>
                              <?php $this->ModelFournisseur->ListeFournisseur(); ?>
                            </select>
                          </div>
                        </div>
                    </div>
                  </div>
                </div>

                

                <div class="col-12 col-sm-12">
                 
                  <div class="card card-primary card-tabs">

                    <!-- supprimer -->
                    <div class="modal fade" id="supprimer">
                      <div class="modal-dialog">
                        <div class="modal-content bg-light">
                          <div class="modal-header">
                            <h4 class="modal-title text-danger"><b><i class='nav-icon fas fa-trash'></i>Suppression</b></h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span></button>
                          </div>
                          <div class="modal-body">
                            <b class="text-danger"> Validez la suppression</b>
                          </div>
                          <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler <i class="nav-icon  fas fa-times-circle"></i></button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal"
                              onclick="dropCommande();">Valider <i class="nav-icon fas fa-check-double"></i></button>
                            <input type="hidden" class="a" > <input type="hidden" class="b" > <input type="hidden" class="c" >
                          </div>
                        </div>
                      </div>
                      
                    </div>

                    


                    <!-- voir -->
                    <div class="modal fade" id="voir">
                      <div class="modal-dialog modal-lg modal-dialog-top">
                        <div class="modal-content bg-light">
                          <div class="modal-header">
                            <h4 class="modal-title text-info"><b><i class='nav-icon fas fa-eye'></i>Voir les informations</b></h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">

                            <div class="row">

                              <div class="col-md-6" >
                                <div class="form-group">
                                  <label>N°Commande</label>
                                  <input type="text" style="border-radius:20px;" class="form-control codeComV" disabled="true"  value="<?php echo $this->ModelArticle->codeCommande();?>">
                                </div>
                              </div>

                              <div class="col-md-6" >
                                <div class="form-group">
                                  <label>Fournisseur</label>
                                  <select style="border-radius:20px;" class="id_fournisseurV form-control"disabled="true" onchange="">
                                    <?php $this->ModelFournisseur->ListeFournisseur(); ?>
                                  </select>
                                </div>
                              </div>

                            </div>

                            <div class="row"> 

                              <div class="col-md-6">
                                <label>Date créa:</label>
                                <div class="input-group ">
                                  <input type="date" style="border-radius:20px;" class="form-control  date_creaV"  value="<?php echo date('Y-m-d'); ?>"disabled="true" >
                                </div>
                              </div>

                              <div class="col-md-6">
                                <label>Date com:</label>
                                <div class="input-group " >
                                  <input type="date" style="border-radius:20px;" class="form-control  date_comV"  value="<?php echo date('Y-m-d'); ?>" disabled="true">
                                  
                                </div>
                              </div>

                            </div>

                            <div class="row">

                              <div class="col-md-6">
                                <div class="form-group">
                                  <label>Article</label>
                                  <select style="border-radius:20px;" class="id_articleV form-control" autocomplete='on' disabled="true" onchange="getPrixUnitaireArticle8($('.id_article1').val(),'prixArticle1');getReferenceArticle8($('.id_article1').val(),'referenceArticle1');">
                                    <?php $this->ModelArticle->ListeArticle();?>
                                  </select>
                                </div>
                              </div>

                              <div class="col-md-6">
                                <div class="form-group">
                                  <label>Référence</label>
                                  <input type= "text"   style="border-radius:20px;" class="form-control referenceComV " disabled = "true">
                                </div>
                              </div>

                            </div>

                            <div class="row"> 

                              <div class="col-md-6">
                                <label>Montant</label>
                                <input type="text" style="border-radius:20px;" class="form-control montantComV"  disabled="true" onkeypress="chiffres(event);" onkeyup ="separateurMIllier('prixArticle1');">
                              </div>

                              <div class="col-md-2">
                                <label>Qtite </label>
                                <input type="text" style="border-radius:20px;" class="form-control qtiteComV "disabled="true" placeholder=" " onkeypress="chiffres(event);" onkeyup ="separateurMIllier('montant');">
                              </div>

                              <div class="col-md-1">
                                <label>VALIDE</label>
                                <input type="checkbox"  class="form-control valideComV" disabled="true" >
                              </div>

                              

                              <div class="col-md-3">
                                <div class="form-group">
                                  <label>CodeFour</label>
                                  <input type= "text" style="border-radius:20px;" class="form-control codeFourV"disabled = "true"  disabled="true">
                                </div>
                              </div>

                            </div>

                            <div class="row"> 

                              <div class="col-md-6">
                                <div class="form-group">
                                  <label>Adresse</label>
                                  <input type= "text" style="border-radius:20px;" class="form-control adresseFourV"disabled = "true"  disabled="true">
                                </div>
                              </div>

                              <div class="col-md-6">
                                <label>Telephone </label>
                                <input type="text" style="border-radius:20px;" class="form-control telFourV "disabled="true" placeholder=" " onkeypress="chiffres(event);" >
                              </div> 

                              

                            </div>

                          </div>
                          <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-light" data-dismiss="modal"></button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal"> Annuler <i class="nav-icon  fas fa-times-circle"></i> </button>
                             
                          </div>
                        </div>
                      </div>
                      
                    </div> 

                  </div>

                  <div class="tab-content" >
                    <div    >
                      <div class="overlay-wrapper">

                        <div class="card-body">
                          <div class="overlay-wrapper">
                            <div class="overlay light actualisationData" style="display: none;">
                              <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                            </div>
                            <table id="exportData" class="table table-bordered table-striped">
                              <thead>
                                <tr>
                                  <th></th>
                                  <th class="col-md-1"><i>Numero</th>
                                  <th class="col-md-3"><i>Nom Article</i></th> 
                                  <th class="col-md-3"><i>Reference</i></th>
                                  <th class="col-md-1"><i>Montant</i></th>
                                  <th class="col-md-1"><i>Qtite</i></th>
                                  <th class="col-md-1"><i>Total</i></th>
                                  <th class="col-md-1"><i>Date</i></th>
                                  <th></th>
                                  <th class="col-md-1"><i>Action</i></th>
                                </tr>
                              </thead>
                              <tbody class="tableData">
                                <?php $this->ModelArticle->afficheDataCommande(); ?>
                              </tbody>
                            </table>
                          </div>
                        </div> 
                      </div>
                    </div>


                  </div>
 
                  <div class="tab-content" >
                    <div class="tab-pane fade show active" id="custom-tabs-one-carte">
                      
                      <div class="overlay-wrapper">
                        <input type="hidden" >
                          <div class="card-body">

                            <div class="overlay-wrapper" >

                              <div class="overlay light actualisationPrint" style="display: none;">
                                <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                              </div> 
                              
                              

                              <div id="imprimer"> 
                                <br/>
                                <table id="" class="table table-bordered table-striped" style="border: none;" cellpadding="0" cellspacing="0">
                                  <thead>

                                    <tr style=" margin: 0px;"> 

                                      <td  colspan="3" style=" margin: 0px;border: none; "></td>  
                                      
                                      

                                      <td  colspan="4" style=" margin: 0px;border: none; "> 
                                        <span style="font-size: 25px;font-weight: bold; " class=" text-success">Bon de Commande</span>
                                      </td>  

                                      <td  colspan="4" style=" margin: 0px;border: none; "></td>   

                                    </tr>

                                    <tr style=" margin: 0px;">

                                      <td  colspan="2" style=" margin: 0px;border: none; ">  

                                        <span style="margin: 0px; padding: 0px;border: none; ">ID Four:</span>
                                        <b class="codeFourP text-danger" style="margin: 0px; padding: 0px;border: none;   width: 10% "></b><br/>

                                        <span style="margin: 0px; padding: 0px;border: none; ">Fournisseur :</span>
                                        <b class="id_fournisseurP text-success" style="margin: 0px; padding: 0px;border: none;   width: 10% "></b><br/>

                                        <span style="margin: 0px; padding: 0px;border: none; ">Adresse :</span>
                                        <b class="adresseFourP text-success" style="margin: 0px; padding: 0px;border: none;   width: 10% "></b><br/>

                                        <span style="margin: 0px; padding: 0px;border: none; ">Telephone :</span>
                                        <b class="telFourP text-success" style="margin: 0px; padding: 0px;border: none;   width: 10% "></b><br/>

                                        <span style="margin: 0px; padding: 0px;border: none; ">Date :</span>
                                        <b class="dateComP" style="margin: 0px; padding: 0px;border: none;   width: 10% "></b>
                                        
                                         
                                      </td>  

                                      <td  colspan="1" style=" margin: 0px;border: none;"></td>

                                      <td colspan="2" style="font-size: 20px; margin: 0px;border: none;  font-weight: bold; ">
                                        <b><?php echo date('d/m/y');?></b>
                                        <span  id="heure"></span>
                                      </td>
                                      
                                      <td  colspan="1" style=" margin: 0px;border: none;"></td>

                                      <td colspan="2" style=" text-align: center; margin: 0px; border: none;  ">
                                        <b style="font-size: 20px;"class="text-primary">DURELL SARL</b><br/>
                                        <b class="text-info">durellmfambo@gmail.com </b><br/> 
                                        <b class="text-dark">Situé à Bépanda </b> <br/> 
                                        <b class="text-dark">Ville : Douala</b> <br/> 
                                        <b class="text-dark">6 58 56 04 56</b> 
                                      </td>

                                    </tr>

                                    <tr> 
                                      <td colspan="6" style="margin: 0px; padding: 0px;border: none;"><br/></td>
                                    </tr>

                                    <tr style="background: white; color: black; font-size: 18px; font-weight: bold; " >
                                      <td colspan='1' style="border-bottom: 1px solid black;width: 13%; text-align: center;border-bottom: 1px solid black; ">Code</td>
                                      <td colspan='2' style="border-left: 1px solid white;width: 30%;  text-align: center;border-bottom: 1px solid black; ">Article</td>
                                    
                                      <td colspan='2' style="border-left: 1px solid white; text-align: center;border-bottom: 1px solid black; ">Référence</td>
                                      <td style="border-left: 1px solid white; text-align: center;width: 10%;border-bottom: 1px solid black; ">Montant</td>
                                      <td style="border-left: 1px solid white; text-align: center;width: 5%;border-bottom: 1px solid black; ">Quantité </td>
                                      <td colspan='2'style="border-left: 1px solid white;width: 10%; text-align: center;border-bottom: 1px solid black; "> Total</td>
                                    </tr>

                                  </thead><br/>

                                  <tbody class="printData" id="printData"></tbody>

                                  <tr style="background: white; color: black; font-size: 13px; font-weight: bold; " >
                                    <td colspan="4" style=" text-align: center;font-weight: bold;">
                                  </td>
              
                                  <td colspan="4" style="text-align: center;font-weight: bold;"></td></tr>

                                </table>
                                <a href="#printData"></a>
                              </div>
                            </div>

                            <div class="row">

                              <div class="col-md-4"></div>

                              <div class="col-md-6"></div>

                              <div class="col-md-2">
                                <button onclick="Imprimer('imprimer')" class="btn btn-white btn-dark btn-bold">
                                  <i class='fas fa-check-circle '></i>
                                  <span class='hidden'><b><i>PRINT</i></span>
                                </button>
                              </div>
                            </div>

                          </div>

                          
                      </div>
                    </div>
                  </div>


                </div>

                
              </div>

            </div>
            
          </div>
        </section>
      
      </div>
      
      <?php include 'style/footer.php'; ?>
      <?php include 'style/js.php'; ?>

    </div>
     
    <script src="<?php echo base_url('style/dist/js/adminlte.js'); ?>"></script>
    <script src="<?php echo base_url('style/javascript/JsArticle.js'); ?>"></script> 

    <script>
      function afficherHeure() {
        let maintenant = new Date();
        let heures = maintenant.getHours().toString().padStart(2, '0');
        let minutes = maintenant.getMinutes().toString().padStart(2, '0');
        let secondes = maintenant.getSeconds().toString().padStart(2, '0');
        
        document.getElementById("heure").textContent = `${heures}:${minutes}:${secondes}`;
      }

      setInterval(afficherHeure, 1000); 
      afficherHeure(); 
    </script>
    
    <script>
      $(function () {

        $("#exportData").DataTable
        ({
          "searching": true,dom: 'Bfrtip',
          buttons: 
          [
            
            { extend:'excelHtml5', autoFilter:true,sheetName:'Exported data',text:"<i class='fab fa-canadian-maple-leaf text-light'></i><b><i>EXCEL</i></b>",
              className: "btn btn-white btn-success btn-bold"
            },
            { extend: "print",text: "<i class='fas fa-archive bigger-110 text-light'></i> <b><i>PRINT</i>",
              className: "btn btn-white btn-danger btn-bold", autoPrint: true,message: 'DURELL :::: Commande Fournisseur'
            }
          ]
        });
        $('#exportData1').DataTable;
      })
    </script>


  </body>

</html>