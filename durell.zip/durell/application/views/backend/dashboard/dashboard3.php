<?php 
  if ($this->session->userdata('id_profil') == null) {
    redirect(base_url() . "controller/", 'refresh');
  }
?>
<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
      <?php 
        echo  $title;   $dashboard3 = "";  $menuDashboard= "";  $activeDashboard= "";
		 ?>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
   
    <?php include 'style/css.php'; ?> 

    <link rel="stylesheet" type="text/css" href="<?php echo base_url('style/vendors/styles/icon-font.min.css'); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('style/src/plugins/datatables/css/dataTables.bootstrap4.min.css'); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('style/src/plugins/datatables/css/responsive.bootstrap4.min.css'); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('style/vendors/styles/style.css'); ?>" />


  </head>

  <body class="hold-transition sidebar-mini layout-fixed">

  	<?php include 'style/right_sidebar.php'; ?>
    
    <div class="main-container">

      <div class="col-xl-2 col-lg-3 col-md-1 mb-20 text-center">
        <div class="card-box ">
          <div class="d-flex text-center ">
            <h3 id="heure"class="text-success"></h3>
          </div>
        </div>
      </div>

      <div class="title">
        <h2 class="h3  text-primary"><?php echo $title; ?></h2>
      </div>

      

      <div class="row pb-10">
        <div class="col-xl-3 col-lg-3 col-md-6 mb-20">
          <div class="card-box height-100-p widget-style3">
            <div class="d-flex flex-wrap">
              <div class="widget-data">
                <div class="weight-700 font-24 text-dark"><?php $this->ModelFournisseur->nbreActifFournisseur(); ?> </div>
                <div class="font-14 text-secondary weight-500">
                  Appointment
                </div>
              </div>
              <div class="widget-icon">
                <div class="icon" data-color="#00eccf">
                  <i class="icon-copy dw dw-calendar1"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-xl-3 col-lg-3 col-md-6 mb-20">
          <div class="card-box height-100-p widget-style3">
            <div class="d-flex flex-wrap">
              <div class="widget-data">
                <div class="weight-700 font-24 text-dark">124,551</div>
                <div class="font-14 text-secondary weight-500">
                    Total Patient
                </div>
              </div>
              <div class="widget-icon">
                <div class="icon" data-color="#ff5b5b">
                  <span class="icon-copy ti-heart"></span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="col-xl-3 col-lg-3 col-md-6 mb-20">
          <div class="card-box height-100-p widget-style3">
            <div class="d-flex flex-wrap">
              <div class="widget-data">
                <div class="weight-700 font-24 text-dark">400+</div>
                <div class="font-14 text-secondary weight-500">
                  Total Doctor
                </div>
              </div>
              <div class="widget-icon">
                <div class="icon">
                  <i class="icon-copy fa fa-stethoscope" aria-hidden="true"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-xl-3 col-lg-3 col-md-6 mb-20">
            <div class="card-box height-100-p widget-style3">
                <div class="d-flex flex-wrap">
                    <div class="widget-data">
                        <div class="weight-700 font-24 text-dark">$50,000</div>
                        <div class="font-14 text-secondary weight-500">Earning</div>
                    </div>
                    <div class="widget-icon">
                        <div class="icon" data-color="#09cc06">
                            <i class="icon-copy fa fa-money" aria-hidden="true"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>







      <div class="xs-pd-20-10 pd-ltr-20">

        <div class="pb-10 row">
          <div class="col-md-4 mb-20">
            <div class="card-box min-height-200px pd-20 mb-20" data-bgcolor="#455a64">
              <div class="d-flex justify-content-between pb-20 text-white">
                <div class="icon h1 text-white">
                  <i class="fa fa-calendar" aria-hidden="true"></i>
                  <!-- <i class="icon-copy fa fa-stethoscope" aria-hidden="true"></i> -->
                </div>
                <div class="font-14 text-right">
                  <div><i class="icon-copy ion-arrow-up-c"></i> 2.69%</div>
                  <div class="font-12">Since last month</div>
                  <div><?php echo date('d-m-Y'); ?></div>
                </div>
              </div>
              <div class="d-flex justify-content-between align-items-end">
                <div class="text-white">
                <div class="font-14">Appointment</div>
                <div class="font-24 weight-500">1865</div>
                </div>
                <div class="max-width-150">
                <div id="appointment-chart"></div>
                </div>
              </div>
            </div>
            <div class="card-box min-height-200px pd-20" data-bgcolor="#265ed7">
              <div class="d-flex justify-content-between pb-20 text-white">
                <div class="icon h1 text-white">
                  <i class="fa fa-stethoscope" aria-hidden="true"></i>
                </div>
                <div class="font-14 text-right">
                  <div><i class="icon-copy ion-arrow-down-c"></i> 3.69%</div>
                  <div class="font-12">Since last month</div>
                </div>
              </div>
              <div class="d-flex justify-content-between align-items-end">
                <div class="text-white">
                  <div class="font-14">Surgery</div>
                  <div><?php echo date('d-m-Y'); ?></div>
                </div>
                <div class="max-width-150">
                  <p id="heure"></p>
                </div>
              </div>
            </div>
          </div>

          
        </div> 

        <div class="pt-20 pb-20 title">
          <h2 class="mb-0 h3">Quick Start</h2>
        </div>

        <div class="row">

          <div class="mb-20 col-md-4">
            <a href="#" class="mx-auto card-box d-block pd-20 text-secondary">
              <div class="img pb-30">
                <!-- <img src="<?php echo base_url(); ?>style/vendors/images/medicine-bro.svg" alt="" /> -->
              </div>
              <div class="content">
                <h3 class="h4">Services</h3>
                <p class="max-width-200">
                  We provide superior health care in a compassionate maner
                </p>
              </div>
            </a>
          </div>

          <div class="mb-20 col-md-4">
            <a href="#" class="mx-auto card-box d-block pd-20 text-secondary">
              <div class="img pb-30">
                <!-- <img src="<?php echo base_url(); ?>style/vendors/images/remedy-amico.svg" alt="" /> -->
              </div>
              <div class="content">
                <h3 class="h4">Medications</h3>
                <p class="max-width-200">
                  Look for prescription and over-the-counter drug information.
                </p>
              </div>
            </a>
          </div>

          <div class="mb-20 col-md-4">
            <a href="#" class="mx-auto card-box d-block pd-20 text-secondary">
              <div class="img pb-30">
                <!-- <img src="<?php echo base_url(); ?>style/vendors/images/paper-map-cuate.svg" alt="" /> -->
              </div>
              <div class="content">
                <h3 class="h4">Locations</h3>
                <p class="max-width-200">
                  Convenient locations when and where you need them.
                </p>
              </div>
            </a>
          </div>
          
        </div>


      </div>
    </div>
    
    
    <?php include 'style/footer.php'; ?>
    <?php include 'style/js.php'; ?>

    <script>
      function afficherHeure() {
        let maintenant = new Date();
        let heures = maintenant.getHours().toString().padStart(2, '0');
        let minutes = maintenant.getMinutes().toString().padStart(2, '0');
        let secondes = maintenant.getSeconds().toString().padStart(2, '0');
        
        document.getElementById("heure").textContent = `${heures}:${minutes}:${secondes}`;
      }

      setInterval(afficherHeure, 1000); 
      afficherHeure(); 
    </script>

      
    <script src="<?php echo base_url('style/dist/js/adminlte.js'); ?>"></script> 
    <script src="<?php echo base_url('style/vendors/scripts/core.js'); ?>"></script>
    <script src="<?php echo base_url('style/vendors/scripts/script.min.js'); ?>"></script>
    <script src="<?php echo base_url('style/vendors/scripts/process.js'); ?>"></script>
    <script src="<?php echo base_url('style/vendors/scripts/layout-settings.js'); ?>"></script>
    <script src="<?php echo base_url('style/src/plugins/apexcharts/apexcharts.min.js'); ?>"></script>
    <script src="<?php echo base_url('style/src/plugins/datatables/js/jquery.dataTables.min.js'); ?>"></script>
    <script src="<?php echo base_url('style/src/plugins/datatables/js/dataTables.bootstrap4.min.js'); ?>"></script>
    <script src="<?php echo base_url('style/src/plugins/datatables/js/dataTables.responsive.min.js'); ?>"></script>
    <script src="<?php echo base_url('style/src/plugins/datatables/js/responsive.bootstrap4.min.js'); ?>"></script>
    <script src="<?php echo base_url('style/vendors/scripts/dashboard3.js'); ?>"></script>


	

   
  </body>

</html>