<?php 
  if ($this->session->userdata('id_profil') == null) {
    redirect(base_url() . "controller/", 'refresh');
  }
?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>
		<?php
			echo  $title;   $dashboard3 = "";  $menuDashboard= "";  $activeDashboard= "";
		?>
		</title>
		
		<?php include 'style/css.php'; ?> 
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('style/vendors/styles/core.css'); ?>" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('style/vendors/styles/icon-font.min.css'); ?>" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('style/src/plugins/datatables/css/dataTables.bootstrap4.min.css'); ?>" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('style/src/plugins/datatables/css/responsive.bootstrap4.min.css'); ?>" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('style/vendors/styles/style.css'); ?>" /> 
	</head>

	<body class="hold-transition sidebar-mini layout-fixed"  > 

		<?php include 'style/right_sidebar.php'; ?>
		
		<div class="main-container">

			<div class="pd-ltr-20">

  				 
				<div class="row">
					<div class="title">
						<h2 class="h3  text-primary"><?php echo $title; ?></h2>
					</div>
					
  					<div class="col-xl-2 col-lg-3 col-md-1 mb-20 text-center">
						<div class="card-box ">
							<div class="d-flex text-center ">
								<h3 id="heure"class="text-success"></h3>
							</div>
						</div>
					</div>

					
				</div>
				 	

				<div class="row">
					<div class="col-xl-3 mb-30">
						<div class="card-box height-100-p widget-style1"data-bgcolor="#2011f0db">
							<div class="d-flex flex-wrap align-items-center">
								<div class="progress-data">
									<div id="chart"></div>
								</div>
								<div class="widget-data">
									<div class="h2 mb-0 text-light">+<?php $this->ModelClient->nbreActifClient(); ?>  <i class='nav-icon fas fa-user-check'></i></div>
									<div class="weight-700 font-20 text-light"><a class=" text-light" href="<?php echo base_url('controller/client'); ?>">Client</a><br><?php $this->ModelClient->nbreNonActifClient(); ?> <i class='nav-icon fas fa-user-times'></i></div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xl-3 mb-30">
						<div class="card-box height-100-p widget-style1"data-bgcolor="#2f9137e3">
							<div class="d-flex flex-wrap align-items-center">
								<div class="progress-data">
									<div id="chart3"></div>
								</div>
								<div class="widget-data">
									<div class="h2 mb-0 text-light">
										+<?php $this->ModelClient->nbrePrintCommandeClient(); ?>
										<i class='nav-icon fas fa-check-circle'></i>
									</div>
									<div class="weight-700 font-18 text-light">
										<a class=" text-light" href="<?php echo base_url('controller/commandeClient'); ?>">
											Command Client
										</a><br>
										<?php $this->ModelClient->nbreNonPrintCommandeClient(); ?>
										<i class="nav-icon fas fa-bell"></i>
									</div> 
								</div>
							</div>
						</div>
					</div> 
					<div class="col-xl-3 mb-30">
						<div class="card-box height-100-p widget-style1"data-bgcolor="#d81919d5">
							<div class="d-flex flex-wrap align-items-center">
								<div class="progress-data">
									<div id="chart2"></div>
								</div>
								<div class="widget-data">
									<div class="h2 mb-0 text-light">+<?php $this->ModelFournisseur->nbreActifFournisseur(); ?> <i class='nav-icon fas fa-user-check'></i></div>
									<div class="weight-700 font-18 text-light"><a class=" text-light" href="<?php echo base_url('controller/Fournisseur'); ?>">Fournisseur</a><br><?php $this->ModelFournisseur->nbreNonActifFournisseur(); ?> <i class='nav-icon fas fa-user-times'></i></div>
								</div>
							</div>
						</div>
					</div> 
					<div class="col-xl-3 mb-30">
						<div class="card-box height-100-p widget-style1"data-bgcolor="#d2c809ff">
							<div class="d-flex flex-wrap align-items-center">
								<div class="progress-data">
									<div id="chart4"></div>
								</div>
								<div class="widget-data">
									<div class="h2 mb-0 text-light">
										+<?php $this->ModelArticle->nbrePrintCommande(); ?>
										<i class='nav-icon fas fa-check-circle'></i>
									</div>
									<div class="weight-700 font-18 text-light">
										<a class=" text-light" href="<?php echo base_url('controller/commandeFournisseur'); ?>">
											Commande Four
										</a><br>
										<?php $this->ModelArticle->nbreNonPrintCommande(); ?>
										<i class="nav-icon fas fa-bell"></i>
									</div> 
								</div>
							</div>
						</div>
					</div>

				</div> 

					
				<div class="row">

					<div class=" col-md-6 mb-20">
						<div class="card-box height-100-p pd-20 min-height-200px">
							<div class="d-flex justify-content-between pb-10">
								<div class="h5 mb-0">#Facture Client 
									<i class='nav-icon fas fa-clipboard text-dark'></i>
								</div>
								<div class="dropdown">
									<a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" data-color="#1b3133" href="#" role="button" data-toggle="dropdown">
										<i class="dw dw-more"></i>
									</a> 
								</div>
							</div>
							<div class="user-list">
								<ul>
									<li class="d-flex align-items-center justify-content-between">
										<div class="name-avatar d-flex align-items-center pr-2">
											<div class="avatar mr-2 flex-shrink-0">
												<i class='nav-icon fas fa-user-plus text-success'></i>
											</div>
											<div class="txt">
												<span class="font-5 weight-60 text-success" >
													<?php $this->ModelClient->nbrClientPlusUtilise(); ?>
												</span>
												<div class="font-14 weight-600 text-success">
													<?php $this->ModelClient->clientPlusUtilise(); ?>
												</div>
												<div class="font-12 weight-500" data-color="#b2b1b6">
													Le Client le plus utilisé
												</div>
											</div>
										</div>
										<div class="cta flex-shrink-0">
											<a href="<?php echo base_url('controller/factureClient'); ?>" class="btn btn-sm btn-outline-success">
												Voir
											</a>
										</div>
									</li>
									<li class="d-flex align-items-center justify-content-between">
										<div class="name-avatar d-flex align-items-center pr-2">
											<div class="avatar mr-2 flex-shrink-0">
												<i class='nav-icon fas fa-user-plus text-primary'></i>
											</div>
											<div class="txt">
												<span class="font-5 weight-60 text-primary" >
													<?php $this->ModelClient->nbrClientMilieu(); ?>
												</span>
												<div class="font-14 weight-600 text-primary">
													<?php $this->ModelClient->clientMilieu(); ?>
												</div>
												<div class="font-12 weight-500" data-color="#b2b1b6">
													Le Client moyennement Utilsée
												</div>
											</div>
										</div>
										<div class="cta flex-shrink-0">
											<a href="<?php echo base_url('controller/factureClient'); ?>" class="btn btn-sm btn-outline-primary">
												Voir
											</a>
										</div>
									</li> 
									<li class="d-flex align-items-center justify-content-between">
										<div class="name-avatar d-flex align-items-center pr-2">
											<div class="avatar mr-2 flex-shrink-0">
												<i class='nav-icon fas fa-user-plus text-danger'></i>
											</div>
											<div class="txt">
												<span class="font-5 weight-60 text-danger" >
													<?php $this->ModelClient->nbrClientMoinsUtilise(); ?>
												</span>
												<div class="font-14 weight-600 text-danger">
													<?php $this->ModelClient->clientMoinsUtilise(); ?>
												</div>
												<div class="font-12 weight-500" data-color="#b2b1b6">
													Le Client le moins  Utilsée
												</div>
											</div>
										</div>
										<div class="cta flex-shrink-0">
											<a href="<?php echo base_url('controller/factureClient'); ?>" class="btn btn-sm btn-outline-danger">
												Voir
											</a>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>

					<div class=" col-md-6 mb-20">
						<div class="card-box height-100-p pd-20 min-height-200px">
							<div class="d-flex justify-content-between pb-10">
								<div class="h5 mb-0">#Facture Fournisseur 
									<i class='nav-icon fas fa-clipboard text-dark'></i>
								</div>
								<div class="dropdown">
									<a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" data-color="#1b3133" href="#" role="button" data-toggle="dropdown">
										<i class="dw dw-more"></i>
									</a> 
								</div>
							</div>
							<div class="user-list">
								<ul>
									<li class="d-flex align-items-center justify-content-between">
										<div class="name-avatar d-flex align-items-center pr-2">
											<div class="avatar mr-2 flex-shrink-0">
												<i class='nav-icon fas fa-user-tag text-success'></i>
											</div>
											<div class="txt">
												<span class="font-5 weight-60 text-success" >
													<?php $this->ModelFournisseur->nbrFournisseurPlusUtilise(); ?>
												</span>
												<div class="font-14 weight-600 text-success">
													<?php $this->ModelFournisseur->fournisseurPlusUtilise(); ?>
												</div>
												<div class="font-12 weight-500" data-color="#b2b1b6">
													Le fournisseur le plus utilisé
												</div>
											</div>
										</div>
										<div class="cta flex-shrink-0">
											<a href="<?php echo base_url('controller/facture'); ?>" class="btn btn-sm btn-outline-success">
												Voir
											</a>
										</div>
									</li>
									<li class="d-flex align-items-center justify-content-between">
										<div class="name-avatar d-flex align-items-center pr-2">
											<div class="avatar mr-2 flex-shrink-0">
												<i class='nav-icon fas fa-user-tag text-primary'></i>
											</div>
											<div class="txt">
												<span class="font-5 weight-60 text-primary" >
													<?php $this->ModelFournisseur->nbrFournisseurMilieu(); ?>
												</span>
												<div class="font-14 weight-600 text-primary">
													<?php $this->ModelFournisseur->fournisseurMilieu(); ?>
												</div>
												<div class="font-12 weight-500" data-color="#b2b1b6">
													Le fournisseur moyennement Utilsée
												</div>
											</div>
										</div>
										<div class="cta flex-shrink-0">
											<a href="<?php echo base_url('controller/facture'); ?>" class="btn btn-sm btn-outline-primary">
												Voir
											</a>
										</div>
									</li> 
									<li class="d-flex align-items-center justify-content-between">
										<div class="name-avatar d-flex align-items-center pr-2">
											<div class="avatar mr-2 flex-shrink-0">
												<i class='nav-icon fas fa-user-tag text-danger'></i>
											</div>
											<div class="txt">
												<span class="font-5 weight-60 text-danger" >
													<?php $this->ModelFournisseur->nbrFournisseurMoinsUtilise(); ?>
												</span>
												<div class="font-14 weight-600 text-danger">
													<?php $this->ModelFournisseur->fournisseurMoinsUtilise(); ?>
												</div>
												<div class="font-12 weight-500" data-color="#b2b1b6">
													Le Fournisseur le moins  Utilsée
												</div>
											</div>
										</div>
										<div class="cta flex-shrink-0">
											<a href="<?php echo base_url('controller/facture'); ?>" class="btn btn-sm btn-outline-danger">
												Voir
											</a>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
					
				</div> 

				<div class="row">

					<div class=" col-md-6 mb-20">
						<div class="card-box height-100-p pd-20 min-height-200px">
							<div class="d-flex justify-content-between pb-10">
								<div class="h5 mb-0">#Facture Client 
									<i class='nav-icon fas fa-clipboard text-dark'></i>
								</div>
								<div class="dropdown">
									<a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" data-color="#1b3133" href="#" role="button" data-toggle="dropdown">
										<i class="dw dw-more"></i>
									</a> 
								</div>
							</div>
							<div class="user-list">
								<ul>
									<li class="d-flex align-items-center justify-content-between">
										<div class="name-avatar d-flex align-items-center pr-2">
											<div class="avatar mr-2 flex-shrink-0">
												<i class='nav-icon fas fa-user-plus text-success'></i>
											</div>
											<div class="txt">
												<span class="font-5 weight-60 text-success" >
													<?php $this->ModelClient->nbrClientPlusUtilise(); ?>
												</span>
												<div class="font-14 weight-600 text-success">
													<?php $this->ModelClient->clientPlusUtilise(); ?>
												</div>
												<div class="font-12 weight-500" data-color="#b2b1b6">
													Le Client le plus utilisé
												</div>
											</div>
										</div>
										<div class="cta flex-shrink-0">
											<a href="<?php echo base_url('controller/factureClient'); ?>" class="btn btn-sm btn-outline-success">
												Voir
											</a>
										</div>
									</li>
									<li class="d-flex align-items-center justify-content-between">
										<div class="name-avatar d-flex align-items-center pr-2">
											<div class="avatar mr-2 flex-shrink-0">
												<i class='nav-icon fas fa-user-plus text-primary'></i>
											</div>
											<div class="txt">
												<span class="font-5 weight-60 text-primary" >
													<?php $this->ModelClient->nbrClientMilieu(); ?>
												</span>
												<div class="font-14 weight-600 text-primary">
													<?php $this->ModelClient->clientMilieu(); ?>
												</div>
												<div class="font-12 weight-500" data-color="#b2b1b6">
													Le Client moyennement Utilsée
												</div>
											</div>
										</div>
										<div class="cta flex-shrink-0">
											<a href="<?php echo base_url('controller/factureClient'); ?>" class="btn btn-sm btn-outline-primary">
												Voir
											</a>
										</div>
									</li> 
									<li class="d-flex align-items-center justify-content-between">
										<div class="name-avatar d-flex align-items-center pr-2">
											<div class="avatar mr-2 flex-shrink-0">
												<i class='nav-icon fas fa-user-plus text-danger'></i>
											</div>
											<div class="txt">
												<span class="font-5 weight-60 text-danger" >
													<?php $this->ModelClient->nbrClientMoinsUtilise(); ?>
												</span>
												<div class="font-14 weight-600 text-danger">
													<?php $this->ModelClient->clientMoinsUtilise(); ?>
												</div>
												<div class="font-12 weight-500" data-color="#b2b1b6">
													Le Client le moins  Utilsée
												</div>
											</div>
										</div>
										<div class="cta flex-shrink-0">
											<a href="<?php echo base_url('controller/factureClient'); ?>" class="btn btn-sm btn-outline-danger">
												Voir
											</a>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>

					<div class=" col-md-6 mb-20">
						<div class="card-box height-100-p pd-20 min-height-200px">
							<div class="d-flex justify-content-between pb-10">
								<div class="h5 mb-0">#Facture Fournisseur 
									<i class='nav-icon fas fa-clipboard text-dark'></i>
								</div>
								<div class="dropdown">
									<a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" data-color="#1b3133" href="#" role="button" data-toggle="dropdown">
										<i class="dw dw-more"></i>
									</a> 
								</div>
							</div>
							<div class="user-list">
								<ul>
									<li class="d-flex align-items-center justify-content-between">
										<div class="name-avatar d-flex align-items-center pr-2">
											<div class="avatar mr-2 flex-shrink-0">
												<i class='nav-icon fas fa-user-tag text-success'></i>
											</div>
											<div class="txt">
												<span class="font-5 weight-60 text-success" >
													<?php $this->ModelFournisseur->nbrFournisseurPlusUtilise(); ?>
												</span>
												<div class="font-14 weight-600 text-success">
													<?php $this->ModelFournisseur->fournisseurPlusUtilise(); ?>
												</div>
												<div class="font-12 weight-500" data-color="#b2b1b6">
													Le fournisseur le plus utilisé
												</div>
											</div>
										</div>
										<div class="cta flex-shrink-0">
											<a href="<?php echo base_url('controller/facture'); ?>" class="btn btn-sm btn-outline-success">
												Voir
											</a>
										</div>
									</li>
									<li class="d-flex align-items-center justify-content-between">
										<div class="name-avatar d-flex align-items-center pr-2">
											<div class="avatar mr-2 flex-shrink-0">
												<i class='nav-icon fas fa-user-tag text-primary'></i>
											</div>
											<div class="txt">
												<span class="font-5 weight-60 text-primary" >
													<?php $this->ModelFournisseur->nbrFournisseurMilieu(); ?>
												</span>
												<div class="font-14 weight-600 text-primary">
													<?php $this->ModelFournisseur->fournisseurMilieu(); ?>
												</div>
												<div class="font-12 weight-500" data-color="#b2b1b6">
													Le fournisseur moyennement Utilsée
												</div>
											</div>
										</div>
										<div class="cta flex-shrink-0">
											<a href="<?php echo base_url('controller/facture'); ?>" class="btn btn-sm btn-outline-primary">
												Voir
											</a>
										</div>
									</li> 
									<li class="d-flex align-items-center justify-content-between">
										<div class="name-avatar d-flex align-items-center pr-2">
											<div class="avatar mr-2 flex-shrink-0">
												<i class='nav-icon fas fa-user-tag text-danger'></i>
											</div>
											<div class="txt">
												<span class="font-5 weight-60 text-danger" >
													<?php $this->ModelFournisseur->nbrFournisseurMoinsUtilise(); ?>
												</span>
												<div class="font-14 weight-600 text-danger">
													<?php $this->ModelFournisseur->fournisseurMoinsUtilise(); ?>
												</div>
												<div class="font-12 weight-500" data-color="#b2b1b6">
													Le Fournisseur le moins  Utilsée
												</div>
											</div>
										</div>
										<div class="cta flex-shrink-0">
											<a href="<?php echo base_url('controller/facture'); ?>" class="btn btn-sm btn-outline-danger">
												Voir
											</a>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
					
				</div> 

			</div>
		</div>
		
		
		<?php include 'style/footer.php'; ?>
	
		<?php include 'style/js.php'; ?>


		<script>
			var a = <?php $this->ModelStock->afficheData(); ?>;
			var b = <?php $this->ModelClient->nbreActifClient(); ?>;
			var c = <?php $this->ModelClient->nbreCommandeClient(); ?>;
			var d = <?php $this->ModelArticle->nbrePrintCommande(); ?>;
		</script> 

		<script>
			function afficherHeure() {
				let maintenant = new Date();
				let heures = maintenant.getHours().toString().padStart(2, '0');
				let minutes = maintenant.getMinutes().toString().padStart(2, '0');
				let secondes = maintenant.getSeconds().toString().padStart(2, '0');
				
				document.getElementById("heure").textContent = `${heures}:${minutes}:${secondes}`;
			}

			setInterval(afficherHeure, 1000); 
			afficherHeure(); 
		</script>


		<script src="<?php echo base_url('style/vendors/scripts/core.js'); ?>"></script>
		<script src="<?php echo base_url('style/vendors/scripts/script.min.js'); ?>"></script>
		<script src="<?php echo base_url('style/vendors/scripts/process.js'); ?>"></script>
		<script src="<?php echo base_url('style/vendors/scripts/layout-settings.js'); ?>"></script>
		<script src="<?php echo base_url('style/src/plugins/apexcharts/apexcharts.min.js'); ?>"></script>
		<script src="<?php echo base_url('style/src/plugins/datatables/js/jquery.dataTables.min.js'); ?>"></script>
		<script src="<?php echo base_url('style/src/plugins/datatables/js/dataTables.bootstrap4.min.js'); ?>"></script>
		<script src="<?php echo base_url('style/src/plugins/datatables/js/dataTables.responsive.min.js'); ?>"></script>
		<script src="<?php echo base_url('style/src/plugins/datatables/js/responsive.bootstrap4.min.js'); ?>"></script> 
		
		<script src="<?php echo base_url('style/dist/js/adminlte.js'); ?>"></script>
		<script src="<?php echo base_url('style/vendors/scripts/dashboard.js'); ?>"></script>

		<script>
			$(function () {

				$("#exportData").DataTable
				({
					"searching": true,dom: 'Bfrtip',
					buttons: 
					[
						
						{ extend:'excelHtml5', autoFilter:true,sheetName:'Exported data',text:"<i class='fab fa-canadian-maple-leaf text-light'></i><b><i>EXCEL</i></b>",
						className: "btn btn-white btn-success btn-bold"
						},
						{ extend: "print",text: "<i class='fas fa-archive bigger-110 text-light'></i> <b><i>PRINT</i>",
						className: "btn btn-white btn-danger btn-bold", autoPrint: true,message: 'DURELL :::: DASHBOARD 3'
						}
					]
				});
				$('#exportData1').DataTable;
			})
		</script>

	</body>

</html>