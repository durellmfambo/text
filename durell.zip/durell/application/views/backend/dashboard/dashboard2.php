<?php 
  if ($this->session->userdata('id_profil') == null) {
    redirect(base_url() . "controller/", 'refresh');
  }
?>
<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
      <?php 
		echo  $title;   $dashboard2 = "";  $menuDashboard= "";  $activeDashboard= "";
      ?>
    </title>

    <?php include 'style/css.php'; ?>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('style/vendors/styles/style.css'); ?>" /> 
 
  </head>

  <body class="hold-transition sidebar-mini layout-fixed" >
    <div class="wrapper">
      
      <?php include 'style/right_sidebar.php'; ?>

      
      <div class="content-wrapper">
        
        <div class="content-header" >
          <div class="container-fluid">
            <div class="row mb-3">
              <div class="col-sm-12">
                <h4 style="text-align: center;"><b class="text-primary">Stock <i class='nav-icon  fas fa-arrow-alt-circle-down'></i></b></h4>
              </div>
            </div>

            <div class="row mb-1">
              <div class="col-md-6">
                <ol class="breadcrumb float-sm-left">
                  <a href="<?php echo base_url('controller/home'); ?>"><li><b class="text-primary "> Home <i class='nav-icon fas fa-angle-right'></i>  </b></li></a></li>
                  <li ><b class="text-success">  <?php echo $title; ?></b></li>
                </ol>
              </div>  
            </div> 
          </div>
        </div> 
        

        
        <section class="content">

          <div class="container-fluid"> 
             
            <div class="row">
              
              <div class="row">  

                <div class="col-md-12"> 
                  <div class="card-body">
                    <div class="row">

                      <div class="col-md-3"></div> 

                      <div class="col-md-2">
                        <div class="form-group">           
                          <div class="input-group " >
                            <input type="" style="border-radius:20px;" class="form-control ">
                            
                          </div>
                        </div>
                      </div>

                      <div class="col-md-2">
                        <div class="form-group">           
                          <div class="input-group ">
                            <input type="" style="border-radius:20px;" class="form-control ">
                            
                          </div>
                        </div>
                      </div>
                
                      <div class="col-md-3">
                        <div class="form-group"> 
                          <input type="" style="border-radius:20px;" class="form-control  ">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-12 col-sm-12"> 

                  <div class="tab-content" >
                      <div class="tab-pane fade show active"  aria-labelledby="custom-tabs-one-home-tab ">
                        <div class="overlay-wrapper">

                          <div class="card-body">
                            <div class="overlay-wrapper">
                              <div class="overlay light actualisationData" style="display: none;">
                                <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                              </div>
                              <table id="exportData" class="table table-bordered table-striped">
                                    
                                <thead>
                                  <tr>
                                    <th></th> 
                                    <th class="col-md-2"><i>Article</i></th> 
                                    <th class="col-md-2"><i>Prix Achat</i></th> 
                                    <th class="col-md-1"><i>Entree</i></th>
                                    <th class="col-md-2"><i>Total Achat</i></th> 
                                    <th class="col-md-2"><i>Prix Vente</i></th>
                                    <th class="col-md-1"><i>sortie</i></th>
                                    <th class="col-md-2"><i>Total Vente</i></th>
                                    <th class="col-md-1"><i>Bénéfice</i></th> 
                                  </tr>
                                </thead>
                                <tbody class="tableData">
                                  <?php $this->ModelStock->afficheStockDasboard(); ?>
                                </tbody>
                              </table>
                            </div>
                          </div>

                        </div>
                      </div>


                    </div>
                  
                </div>
              </div>

            </div>
            
          </div>
        </section>
      
      </div>
      
      <?php include 'style/footer.php'; ?>
      <?php include 'style/js.php'; ?> 
      
    </div>
     
    <script src="<?php echo base_url('style/dist/js/adminlte.js'); ?>"></script> 
    <script src="<?php echo base_url(); ?>style/javascript/jsStock.js"></script>

    <script>
      $(function () {

        $("#exportData").DataTable
        ({
          "searching": true,dom: 'Bfrtip',
          buttons: 
          [
            
            { extend:'excelHtml5', autoFilter:true,sheetName:'Exported data',text:"<i class='fab fa-canadian-maple-leaf text-light'></i><b><i>EXCEL</i></b>",
              className: "btn btn-white btn-success btn-bold"
            },
            { extend: "print",text: "<i class='fas fa-archive bigger-110 text-light'></i> <b><i>PRINT</i>",
              className: "btn btn-white btn-danger btn-bold", autoPrint: true,message: 'DURELL :::: Dashboard 2'
            }
          ]
        });
        $('#exportData1').DataTable;
      })
    </script>

  </body>

</html>