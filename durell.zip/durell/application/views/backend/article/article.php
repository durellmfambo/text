<?php 
  if($this->session->userdata('id_profil')==null){
    redirect(base_url()."controller/", 'refresh');
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
      <?php 
        echo $title;   $article = "";   $menuArticle = "";  $activeArticle = ""; 
      ?>
    </title>
    
    <?php include 'style/css.php'; ?>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('style/vendors/styles/style.css'); ?>" /> 
  </head>
  <body class="hold-transition sidebar-mini layout-fixed">

    <div class="wrapper">
      
      <?php include 'style/right_sidebar.php'; ?>
      
      <div class="content-wrapper">
        
        <div class="content-header" >
          <div class="container-fluid">
            <div class="row mb-1">
              <div class="col-sm-12">
                <h4 style="text-align: center;"><b class="text-primary">Ajouter un article  <i class='nav-icon fab fa-buysellads'></i></b></h4>
              </div>
            
            </div>

            <div class="row">
              <div class="col-sm-12">
                <ol class="breadcrumb float-sm-left">
                  <a href="<?php echo base_url('controller/home'); ?>"><li><b class="text-primary "> Home <i class='nav-icon fas fa-angle-right'></i>  </b></li></a></li>
                  <li ><b class="text-success">  <?php echo $title; ?></b></li>
                </ol>
              </div>
            
            </div>
            
          </div>
        </div>
        

        <section class="content">

          <div class="container-fluid">

            <div class="row">

              <div class="col-md-12 col-sm-12">

                <div class="tab-content" >

                  <div class="tab-pane fade show active" aria-labelledby="custom-tabs-one-home-tab ">

                    <div class="overlay-wrapper">

                      <div class="overlay light actualisation" style="display: none;">
                        <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                      </div>
                    
                      <div class="card-body">
                        
                        <div class="row">

                          <div class="col-md-2" >
                            <div class="form-group">
                              <label>N°Article</label>
                              <input type="text" style="border-radius:20px;" class="form-control numeroArticle" value="<?php echo $this->ModelArticle->codeArticle();?>" disabled="true">
                            </div>
                          </div>

                          <div class="col-md-3">
                            <label> Categorie Article</label>
                            <select style="border-radius:20px;" class="id_categorie form-control" >
                              <option></option>
                              <?php $this->ModelArticle->ListeCategorieArticle(); ?>
                            </select>
                          </div>

                          <div class="col-md-3">
                            <label>Fournisseur</label>
                            <select style="border-radius:20px;" class="id_fournisseur form-control">
                              <option></option>
                              <?php $this->ModelFournisseur->ListeFournisseur(); ?>
                            </select>
                          </div>

                          <div class="col-md-2">
                            <label>Date </label>
                            <div class="input-group ">
                              <input type="date" style="border-radius:20px;" class="form-control  dateArticle" value="<?php echo date('Y-m-d'); ?>" />
                            </div>
                          </div>

                          <div class="col-md-2">
                            <label>Etat</label> 
                            <select style="border-radius:20px;" class="commentaireArticle form-control" >
                              <option></option>
                              <option>NEUF</option>
                              <option>OCCASION</option>
                            </select>
                          </div>

                          <div class="col-md-3 mt-1">
                            <label>Nom Article</label>
                            <input type="text" style="border-radius:20px;" class="form-control nomArticle" placeholder="Nom">
                          </div> 

                          <div class="col-md-4 mt-1">
                            <label>Reference</label>
                            <input type="text" style="border-radius:20px;" class="form-control referenceArticle " placeholder="reference">
                          </div>

                          <div class="col-md-2 mt-1">
                            <label>Prix Achat</label>
                            <input type="text" style="border-radius:20px;" class="form-control montantArticle " placeholder="Montant" onkeypress="chiffres(event);" onkeyup="separateurMIllier('montantArticle');">
                          </div>

                          <div class="col-md-2 mt-1">
                            <label>Prix Vente</label>
                            <input type="text" style="border-radius:20px;" class="form-control prixVente " placeholder="PrixVente" onkeypress="chiffres(event);" onkeyup="separateurMIllier('prixVente');">
                          </div>

                          

                          <div class="col-md-1 mt-1">
                            <label>DISPONIBLE</label>
                            <input type="checkbox" class="form-control statusArticle">
                          </div>

                        </div>

                        <div class="row">

                          <div class="col-md-10"></div>

                          <div class="col-md-2">
                            <br>
                            <?php
                              if($this->session->userdata('autoArticle_ajout') == "true") {
                                echo '<button type="button" class="btn btn-dark buttonA" onclick="ajoutArticle(\'ajouter\');">Ajouter <i class="nav-icon fas fa-plus-circle"></i></button>';
                              }
                            ?>
                            <button type="button" class="btn btn-info buttonM" style="display: none;" onclick="ajoutArticle('modifier');">Modifier <i class="nav-icon 	fas fa-pen"></i></button>
                          </div>

                        </div>

                      </div>

                    </div>

                    <input type="hidden" class="id_table" >
                    <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">

                  </div>

                  
                </div>

              </div>

              <div class="col-12 col-sm-12">
                
                <!-- supprimer -->
                <div class="modal fade" id="supprimer">
                  <div class="modal-dialog">
                    <div class="modal-content bg-light">
                      <div class="modal-header">
                        <h4 class="modal-title text-danger"><b><i class='nav-icon fas fa-trash'></i>Suppression</b></h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span></button>
                      </div>
                      <div class="modal-body">
                      <h6  style="text-align: center;"> <b class="text-danger"> Validez la suppression </b></h6>
                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler <i class="nav-icon  fas fa-times-circle"></i></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"
                          onclick="dropArticle();">Valider <i class="nav-icon fas fa-check-double"></i>
                        </button>
                        <input type="hidden" class="a" >  <input type="hidden" class="b" > <input type="hidden" class="c" >
                      </div>
                    </div>
                  </div>
                  
                </div>

                <!-- voir -->
                <div class="modal fade" id="voir">
                  <div class="modal-dialog modal-lg modal-dialog-top">
                    <div class="modal-content bg-light">
                      <div class="modal-header">
                        <h4 class="modal-title text-info"><b><i class='nav-icon fas fa-eye'></i>Voir les informations</b></h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">

                        <div class="row">

                          <div class="col-md-6" >
                            <div class="form-group">
                              <label>N°Article</label>
                              <input type="text" style="border-radius:20px;" class="form-control numeroArticleV"   value="<?php echo $this->ModelArticle->codeArticle();?>" disabled="true">
                            </div>
                          </div>

                          <div class="col-md-6">
                            <label> Categorie Article</label>
                            <select style="border-radius:20px;" class="id_categorieV form-control" disabled="true">
                              <option></option>
                              <?php $this->ModelArticle->ListeCategorieArticle(); ?>
                            </select>
                          </div>
                          
                        </div>

                        <div class="row">
                          
                          <div class="col-md-6">
                            <label>Fournisseur</label>
                            <select style="border-radius:20px;" class="id_fournisseurV form-control" disabled="true">
                              <option></option>
                              <?php $this->ModelFournisseur->ListeFournisseur(); ?>
                            </select>
                          </div>

                          <div class="col-md-6">
                            <label>Date </label>
                            <div class="input-group ">
                              <input type="date" style="border-radius:20px;" class="form-control  dateArticleV" value="<?php echo date('Y-m-d'); ?>" disabled="true"/>
                            </div>
                          </div>

                        </div>

                        <div class="row">
                          
                          <div class="col-md-6 mt-1">
                            <label>Nom Article</label>
                            <input type="text" style="border-radius:20px;" class="form-control nomArticleV" disabled="true" >
                          </div>

                          <div class="col-md-2 mt-1">
                            <label>Montant</label>
                            <input type="text" style="border-radius:20px;" class="form-control montantArticleV " disabled="true" >
                          </div>

                          <div class="col-md-2 mt-1">
                            <label>prix Vente</label>
                            <input type="text" style="border-radius:20px;" class="form-control prixVenteV " disabled="true" >
                          </div>

                          <div class="col-md-1 mt-1">
                            <label>DISPO</label>
                            <input type="checkbox" class="form-control statusArticleV" disabled="true">
                          </div>

                        </div>

                        <div class="row">
                          
                          <div class="col-md-6 mt-1">
                            <label>Reference</label>
                            <input type="text" style="border-radius:20px;" class="form-control referenceArticleV "disabled="true">
                          </div>

                          <div class="col-md-6 mt-1">
                            <label>Commentaire</label>
                            <input type="text" style="border-radius:20px;" class="form-control commentaireArticleV" disabled="true">
                          </div>

                        </div>

                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-light" data-dismiss="modal"></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"> Annuler <i class="nav-icon  fas fa-times-circle"></i> </button>
                        <input type="hidden" class="id_profil" >
                        <input type="hidden" class="compte" value="<?php echo $this->session->userdata('identifiant') ?>">
                      </div>
                    </div>
                  </div>
                  
                </div>

                <div class="tab-content">
                  <div>
                    <div class="overlay-wrapper">
                      <div class="card-body">
                        <div class="overlay-wrapper" >
                          <div class="overlay light actualisationData" style="display: none;">
                            <i class="fas fa-3x fas fa-spinner fa-spin"></i>
                          </div>

                          <table id="exportData" class="table table-bordered table-striped">
                            <thead>
                              <tr>
                                <th></th>
                                <th class="col-md-1"><i>Code</i></th>
                                <th class="col-md-3"><i>Nom Article</i></th>
                                <th class="col-md-1"><i>Fournisseur</i></th>
                                <th class="col-md-2"><i>Reference</i></th>
                                <th class="col-md-1"><i>Montant</i></th>
                                <th class="col-md-1"><i>prixVente</i></th>
                                <th class="col-md-1"><i>Date</i></th>
                                <th></th>
                                <th class="col-md-1"><i>Action</i></th>
                              </tr>
                            </thead>
                            <tbody class="tableData">
                              <?php $this->ModelArticle->afficheDataArticle(); ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div> 

              </div>

            </div>

          </div>

        </section>
        
      </div>
      
      <?php include 'style/footer.php'; ?>
      <?php include 'style/js.php'; ?>

    </div>
      
    <script src="<?php echo base_url('style/dist/js/adminlte.js'); ?>"></script>
    <script src="<?php echo base_url('style/javascript/JsArticle.js'); ?>"></script> 
    
    <script>
      $(function () {

        $("#exportData").DataTable
        ({
          "searching": true,"autoPrint": true,dom: 'Bfrtip',
          buttons: 
          [
            { extend:'excelHtml5', autoFilter:true,sheetName:'Exported data',text:"<i class='fab fa-canadian-maple-leaf text-light'></i><b><i>EXCEL</i></b>",
              className: "btn btn-white btn-success btn-bold"
            },
            { extend: "print",text: "<i class='fas fa-archive bigger-110 text-light'></i> <b><i>PRINT</i>",
              className: "btn btn-white btn-danger btn-bold", autoPrint: true,message: 'DURELL :::: Article'
            }
          ]
        });
        $('#exportData1').DataTable;
      })
    </script>

  </body>
</html>
