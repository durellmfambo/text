
<?php 
  if($this->session->userdata('id_profil')!=null){
    redirect(base_url()."controller/home", 'refresh');
  }
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
      <?php 
        echo $title;  
      ?>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php include 'style/css.php'; ?>

  </head>

  <body class="login-page" style="background:url(<?php echo base_url('style/image/image13.jpg'); ?>) no-repeat; background-size: cover;">
    
    <div class="overlay-wrapper">

      <div id="barres" class="col-md-12" >
        <div id="progressions"></div>
      </div>

      <div class="overlay dark actualisation" style="display: none;" >
        <i class="fas fa-5x fas fa-spinner fa-spin"></i>
      </div>

      <br>

      <div class="login-box">
        
        <div class="card"    style="border-radius:50px; background-color:rgba(199, 199, 203, 0.07);">

          <div class="card-body login-card-body" style="border-radius:50px; background-color:rgba(199, 199, 203, 0.07);">
            <h6>
              <b>
                <p class="login-box-msg text-light">CONNEXION</p>
              </b>
            </h6>

            <form  method="post">

              <div class="input-group mb-3">
                <input type="email" class="form-control login"   style="border-radius:10px;"  placeholder="Username">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-user text-light"></span>
                  </div>
                </div>
              </div>

              <div class="input-group mb-3">
                <input type="password" class="form-control password"  style="border-radius:10px;"  placeholder="Password">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-eye-slash text-light"></span>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-4"></div>
                
                <div class="col-4">
                  <button class="btn btn-success btn-block"style="border-radius:50px;" onclick="connexion(event);">Log In</button>
                </div>
                
                <div class="col-4"></div>

              </div>

            </form>

          </div>
        </div>
      </div>

    </div>

    
    <?php include 'style/js.php'; ?>

    <script src="<?php echo base_url('style/dist/js/adminlte.min.js'); ?>"></script>
    <script src="<?php echo base_url('style/javascript/JsScript.js'); ?>"></script>


  </body>
</html>
