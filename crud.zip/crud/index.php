<?php

include "db_conn.php";

if (isset($_POST['submit'])) {


    
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];



    $sql = "INSERT INTO `crud`(`id`, `first_name`, `last_name`, `email`, `gender`) VALUES (NULL,'$first_name','$last_name','$email','$gender')";

    $result = mysqli_query($conn, $sql);

    if ($result) {
        header("Location : index.php?msg=New record created successfully ");
    } else {
        echo "failed: " . mysqli_error($conn);
    }
}

?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <!-- Font awesone -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>PHP CRUD Application</title>
</head>

<body>

    <nav class="navbar navbar-light justify-content-center fs-3 mb-5" style="background-color:#00ff5573; ">
        PHP Complete CRUD Application
    </nav>


    <div class="container">

    <a href="projet.php" class="btn btn-info">projet</a>
        <div class="text-center mb-4">
            <h3>Add New User</h3>
            <p class="text-muted">Complete the form below to add a new user</p>
        </div>
        <div class="container d-flex justify-content-center">
            <form action="" method="post" style="width: 50vw; min-width:300px;" id="myForm">
                <div class="row">
                    <div class="col">
                        <label for="first_name" class="form-label">First Name:</label>
                        <input type="text" class="form-control" name="first_name" id="first_name"
                            placeholder="Entrez votre nom">
                    </div>
                    <div class="col">
                        <label for="last_name" class="form-label">Last Name:</label>
                        <input type="text" class="form-control" name="last_name" id="last_name"
                            placeholder="Entrez votre prenom">
                    </div>
                    <div>
                        <label for="email" class="form-label">Email:</label>
                        <input type="email" class="form-control" name="email" id="email"
                            placeholder="Entrez votre email">
                    </div>
                </div>
                <div class="form-group mt-2">
                    <label for="gender">Gender :</label>&nbsp;
                    <input type="radio" class="form-check-input" name="gender" id="male" value="male">
                    <label for="male"> Male</label>
                    <input type="radio" class="form-check-input" name="gender" id="femele" value="femele">
                    <label for="femele"> femele</label>
                </div>
                <div class="mt-3">
                    <button type="submit" class="btn btn-success submit " id="submit" name="submit">add data</button>
                    <a href="index.php" class="btn btn-danger">Cancel</a>

                </div>
            </form>

            <div id="message" style="color: red;"></div> <!-- Pour afficher les messages d'erreur -->

        </div>

    </div>

    <hr>
    <div class="container">

        <a href="add_new.php" class="btn btn-dark">add New</a>



        <table class="table table-striped  table-bordered text-center mt-4">
            <thead class="table-success">
                <tr id="items">
                    <th scope="col">id</th>
                    <th scope="col">First Name</th>
                    <th scope="col">Last Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <?php
            $req = mysqli_query($conn, "SELECT * FROM crud ORDER BY id desc");
            if (mysqli_num_rows($req) == 0) {
                echo "Veuillez remplir vos informations ";
            } else {
                while ($row = mysqli_fetch_assoc($req)) {
            ?>
                    <tr id="data">
                        <td><?= $row['id'] ?></td>
                        <td><?= $row['first_name'] ?></td>
                        <td><?= $row['last_name'] ?></td>
                        <td><?= $row['email'] ?></td>
                        <td><?= $row['gender'] ?></td>
                        <td>
                            <div class="table-actions">
                                <a href="modi.php?id=<?= $row['id'] ?>" class="link-success"><i class="fa-solid fa-pen-to-square fs-5 me-3"></i></a>

                                <a href="supp.php?id=<?= $row['id'] ?>" class="link-danger"><i class="fa-solid fa-trash fs-5"></i></a>
                            </div>
                        </td>

                    </tr>
            <?php
                }
            }
            ?>

        </table>
    </div>


    <script>
       $(document).ready(function(){
        $("#myForm").submit(function(e){
            e.preventDefault();
            var name = $("#first_name").val();
            console.log(name);
            alert(name);
        })
       })
    </script>

    <!-- Bootstrap js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <script src="script.js"></script>

</body>

</html>