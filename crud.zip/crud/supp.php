<?php
    include_once "db_conn.php";
   
    $id= $_GET['id'];

    $req = mysqli_query($conn, "DELETE FROM crud WHERE id = $id");

    header("Location:index.php");   

?>