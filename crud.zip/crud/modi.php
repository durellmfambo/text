<?php

$id = $_GET['id'];

require "db_conn.php";

$req = mysqli_query($conn, "SELECT * FROM crud WHERE id = $id ");

$row = mysqli_fetch_assoc($req);  


if (isset($_POST['submit'])) {

    // extract($_POST);
    
     $first_name = $_POST['first_name'];
     $last_name = $_POST['last_name'];
     $email = $_POST['email'];
     $gender = $_POST['gender'];


    $sql = "UPDATE `crud` SET `first_name`='$first_name',`last_name`='$last_name',`email`='$email',`gender`='$gender' WHERE id = $id ";


    

    $result = mysqli_query($conn, $sql);

    if ($result) {
        header("Location : index.php?msg=Data update successfully");
    } else {
        echo "failed: " . mysqli_error($conn);
    }
}

?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <!-- Font awesone -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>PHP CRUD Application</title>
</head>

<body>

    <nav class="navbar navbar-light justify-content-center fs-3 mb-5" style="background-color:#00ff5573; ">
        PHP Complete CRUD Application
    </nav>


    <div class="container">
        <div class="text-center mb-4">
            <h3>Add New User</h3>
            <p class="text-muted">Complete the form below to add a new user</p>
        </div>
        <div class="container d-flex justify-content-center">
            <form action="" method="post" style="width: 50vw; min-width:300px;">
                <div class="row">
                    <div class="col">
                        <label class="form-label">First Name:</label>
                        <input type="text" class="form-control" name="first_name" id="first_name" value="<?=$row['first_name']?>"
                            placeholder="Entrez votre nom">
                    </div>
                    <div class="col">
                        <label class="form-label">Last Name:</label>
                        <input type="text" class="form-control" name="last_name" id="last_name" value="<?=$row['last_name']?>"
                            placeholder="Entrez votre prenom">
                    </div>
                    <div>
                        <label class="form-label">Email:</label>
                        <input type="email" class="form-control" name="email" id="email" value="<?=$row['email']?>"
                            placeholder="Enetre votre  email">
                    </div>
                </div>
                <div class="form-group mt-2">
                    <label>Gender :</label>&nbsp;
                    <input type="radio" class="form-check-input" name="gender" id="male" value="male" <?php echo ($row['gender']=='male')?"checked":"";?>>
                    <label for="male"> Male</label>
                    <input type="radio" class="form-check-input" name="gender" id="femele" value="femele" <?php echo ($row['gender']=='femele')?"checked":"";?>>
                    <label for="femele"> femele</label>
                </div>
                <div class="mt-3">
                    <button type="submit" class="btn btn-primary" id="Update" name="submit">Update</button>

                    <a href="index.php"class="btn btn-danger">Cancel</a>

                </div>
            </form>
        </div>

    </div>

    <hr>
    <div class="container">

        <a href="add_new.php" class="btn btn-dark">add New</a>



        <table class="table table-hover text-center mt-4">
            <thead class="table-success">
                <tr id="items">
                    <th scope="col">id</th>
                    <th scope="col">First Name</th>
                    <th scope="col">Last Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <?php
            $req = mysqli_query($conn, "SELECT * FROM crud ORDER BY id desc");
            if (mysqli_num_rows($req) == 0) {
                echo "Veuillez remplir vos informations ";
            } else {
                while ($row = mysqli_fetch_assoc($req)) {
            ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= $row['first_name'] ?></td>
                        <td><?= $row['last_name'] ?></td>
                        <td><?= $row['email'] ?></td>
                        <td><?= $row['gender'] ?></td>
                        <td>
                            <div class="table-actions">
                                <a href="modi.php?id=<?= $row['id'] ?>" class="link-success"><i class="fa-solid fa-pen-to-square fs-5 me-3"></i></a>

                                <a href="supp.php?id=<?= $row['id'] ?>" class="link-danger"><i class="fa-solid fa-trash fs-5"></i></a>
                            </div>
                        </td>

                    </tr>
            <?php
                }
            }
            ?>

        </table>
    </div>




    <!-- Bootstrap js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <script src="script.js"></script>

</body>

</html>